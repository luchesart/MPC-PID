# Exact matching of prescribed MPC by PID

Lean 4 companion to Latchezar P. Tomov, *Exact Matching of Prescribed Model Predictive Control by Generalized-Discretization PID*, revised 22 November 2026.

## Build and audit

From the directory containing this README, with elan, Lake and Git installed, run

```sh
lake exe cache get
lake build
lake env lean Audit.lean
```

The project pins Lean and mathlib to v4.19.0. The manifest also records the dependency revisions. The first command obtains the compiled mathlib dependencies. The default build checks the project umbrella `MPCPID.lean`, which imports the proof modules. The last command inspects the transitive kernel dependencies of every project theorem and fails on any axiom other than `propext`, `Classical.choice` or `Quot.sound`.

## Finding a proof

[PROOFS.md](PROOFS.md) maps all numbered statements in the manuscript and the supporting analytical calculations to named declarations. The axiom audit also resolves a named theorem for each of the 24 numbered statements. Corollary 5.2 builds the matching and stability tests from the physical parameters and clocks. Proposition 7.2 uses dynamics only through the selected horizon. Proposition 8.3 includes feasibility of the inactive rows. Theorems 5.5–5.8 resolve unrestricted clock synthesis for finite-dimensional linear targets. Theorem 8.8 determines the exact one-step MIACE rate, and Theorem 8.9 classifies supported memory corrections for a periodic implementation.

- `MPCPID.ClosedLoopOptimal.exists_realized_optimum` constructs a positive filtered PID, runs it on the plant and compares its realized MIACE against all competing command histories at the prescribed step. `MPCPID.EquilibriumShift.globally_optimal_between_equilibria` makes the translation to arbitrary old and new equilibria explicit.
- `MPCPID.ProjectedRun.applied_at_every_sample` runs the corrected positional PID through a causal projection on each sample and proves equality with the projected MPC command, including after changes of active bounds.
- `MPCPID.Conditioned.Box.maximal`, `MPCPID.Conditioned.Box.admissible_iff` and `MPCPID.Implementation.box_implementation_safe` identify the maximal controlled-invariant subset of the box, describe its viable commands and verify recursive feasibility of the controller.

`MPCPID.NonzeroRun.projected_from_compatible_restart` executes the projected PID at every sample starting from registers with a compatible two-sample history. It admits nonzero integral and filter memories.
