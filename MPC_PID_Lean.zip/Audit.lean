import MPCPID
import Lean.Util.CollectAxioms

/-! Inspect the transitive kernel dependencies of every
project theorem, including private lemmas. -/
open Lean in
run_cmd do
  let env ← getEnv
  let decls := env.constants.fold (fun (out : Array Name) name ci =>
    if ci.isTheorem && (name.toString.startsWith "MPCPID." || name.toString.startsWith "_private.MPCPID.")
    then out.push name else out) #[]
  if decls.isEmpty then throwError "No project declarations were found."
  let (_, state) := ((decls.forM CollectAxioms.collect).run env).run {}
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let unexpected := state.axioms.filter (!allowed.contains ·)
  unless unexpected.isEmpty do throwError "Unexpected proof dependencies: {unexpected}"
  logInfo m!"Audited {decls.size} kernel theorem declarations, including generated theorems. Transitive axioms: {state.axioms}"

/-! One theorem endpoint per numbered statement, in manuscript order.
Quoted identifiers are resolved by Lean's elaborator. -/
open Lean in
run_cmd do
  let entries : List (String × Name) := [
    ("3.1", ``MPCPID.Matching.positive_membership_iff),
    ("4.1", ``MPCPID.Matching.residual_identity),
    ("4.2", ``MPCPID.Matching.constructive_nominal_matching),
    ("5.1", ``MPCPID.Periodic.twoLiftEquality),
    ("5.2", ``MPCPID.PhysicalSchedule.nominal_physical_feasibility),
    ("5.3", ``MPCPID.Periodic.heldPhysicalCommand),
    ("5.4", ``MPCPID.Periodic.integralSamplingObstruction),
    ("5.5", ``MPCPID.UpdateOpt.minimum_physical_iff),
    ("5.6", ``MPCPID.GlobalExhaustion.exhaustive_global_search),
    ("5.7", ``MPCPID.RateFrontier.physical_clock_rigidity),
    ("5.8", ``MPCPID.PeriodicSynthesis.exhaustive_periodic_search),
    ("7.1", ``MPCPID.Predictive.weight_tradeoff),
    ("7.2", ``MPCPID.FiniteHorizon.rollout_sensitivity_on_horizon),
    ("8.1", ``MPCPID.OneStepBridge.one_step_matched_trajectories),
    ("8.2", ``MPCPID.Predictive.projection_metric_loss),
    ("8.3", ``MPCPID.FiniteHorizon.regular_kkt_full_feasible),
    ("8.4", ``MPCPID.Optimal.Model.monotone_iff),
    ("8.5", ``MPCPID.EquilibriumShift.globally_optimal_between_equilibria),
    ("8.6", ``MPCPID.ProjectedRun.applied_at_every_sample),
    ("8.7", ``MPCPID.Conditioned.Box.maximal),
    ("8.8", ``MPCPID.PhysicalMinimum.nominal_global_minimum),
    ("8.9", ``MPCPID.PhaseColumns.physical_projected_iff_columns),
    ("9.1", ``MPCPID.Terminal.optimal_trajectory),
    ("9.2", ``MPCPID.Terminal.accepted_trajectory)]
  let env ← getEnv
  for (label, name) in entries do
    unless (env.find? name).any (·.isTheorem) do
      throwError "Paper entry {label}: {name} is not a theorem."
  let companions := [``MPCPID.PhysicalSchedule.operator_physical_feasibility,
    ``MPCPID.SelectedChannels.selected_physical_feasibility,
    ``MPCPID.OperatorPhase.operator_periodic_blocks,
    ``MPCPID.TimeUnits.normalize_fixed_interval,
    ``MPCPID.History.all_compatible_samples,
    ``MPCPID.NonzeroRun.projected_from_nonzero_history,
    ``MPCPID.Appendices.inverse_is_unique_minimizer,
    ``MPCPID.Appendices.matched_seven_state,
    ``MPCPID.Periodic.withinFrameOutput,
    ``MPCPID.Appendices.pi_boundary,
    ``MPCPID.UpdateOpt.optimal_physical_iff,
    ``MPCPID.GainReserve.reserve_feasibility,
    ``MPCPID.GlobalExhaustion.exhaustive_all_minimizers,
    ``MPCPID.ClockCatalogue.count_first_lag_catalogue,
    ``MPCPID.NoZeroTarget.matched_step_output_nonzero,
    ``MPCPID.EquilibriumResponse.every_matched_phase,
    ``MPCPID.NominalBound.physical_first_sample_bound,
    ``MPCPID.PeriodicNominal.physical_periodic_cutoff,
    ``MPCPID.PeriodicExcitation.feasible_periodic_cutoff,
    ``MPCPID.PeriodicSynthesis.exhaustive_periodic_minimizers,
    ``MPCPID.PhysicalMinimum.nominal_miace_forces_base_rate,
    ``MPCPID.CommonRealized.unconditional_minimum,
    ``MPCPID.PhaseCausal.physical_causal_iff_columns,
    ``MPCPID.PhaseCorrection.applied_only_iff_free,
    ``MPCPID.PhaseSplit.recovers_common_rate,
    ``MPCPID.PhaseExample.alternating_obstruction,
    ``MPCPID.TargetProbe.phase_zero_suffices]
  for name in companions do
    unless (env.find? name).any (·.isTheorem) do
      throwError "Supporting entry {name} is not a theorem."
  logInfo m!"Resolved all {entries.length} numbered paper entries and {companions.length} supporting entries."
