import MPCPID.PhysicalMinimum
import MPCPID.OneStepBridge
import MPCPID.Integration

/-! Common-rate attainment on the same physical execution model used in the
unrestricted clock minimum. -/
namespace MPCPID.CommonRealized
open PhysicalMinimum Periodic NominalProbe TargetProbe Predictive Conditioned

noncomputable section

private theorem same_den {α : ℝ} {u v : Signal} (eqn : ∀ k, den α u k = den α v k) :
    ∀ k, u k=v k := by
  intro k
  suffices H : u k=v k ∧ lag u k=lag v k from H.1
  induction k with
  | zero =>
    have e := eqn 0
    simp [den,lag] at e
    exact ⟨e,rfl⟩
  | succ k ih =>
    have e := eqn (k+1)
    change u (k+1)-(1+α)*u k+α*lag u k=v (k+1)-(1+α)*v k+α*lag v k at e
    exact ⟨by rw [ih.1,ih.2] at e; linarith,ih.1⟩

/-- Equality of the numerator taps yields equality of the actual stored
PID's command with the target first move, for every causal reference. -/
theorem fitted_origin_match {a b₀ b₁ η f t ζ α K κ d g b c : ℝ}
    (ha : α≠1) (pole : α = -ζ*b₁) (sum : t+ζ*(b₀+b₁)=1)
    (fit : Matching.channels α (Matching.realization K κ d g b c) =
      Matching.target α a f ζ η) :
    originMatch (atPhase 1 0) (atPhase 1 0) (atPhase 1 0)
      K (κ*g) (κ*(1-g)) α d b c a b₀ b₁ η f t := by
  intro r
  let z := traj a b₀ b₁ η f t r
  let y := fun k => (z k).1
  let v := fun k => (z (k+1)).2
  let x := stores (atPhase 1 0) (atPhase 1 0) (atPhase 1 0)
    K (κ*g) (κ*(1-g)) α d b c r y 0
  let i := fun k => (x (k+1)).i
  let df := fun k => (x (k+1)).d
  let u := fun k => (x (k+1)).p+i k+df k
  have all (k : ℕ) : atPhase 1 0 k := Nat.mod_one _
  have oldi (k : ℕ) : (x k).i = lag i k := by cases k <;> rfl
  have oldd (k : ℕ) : (x k).d = lag df k := by cases k <;> rfl
  have eri (k : ℕ) : (x k).eI = lag r k-lag y k := by
    cases k <;> simp [x,stores,NominalProbe.advance,Periodic.rest,lag,all]
  have erd (k : ℕ) : (x k).eD = c*lag r k-lag y k := by
    cases k <;> simp [x,stores,NominalProbe.advance,Periodic.rest,lag,all]
  have hu (k : ℕ) : u k = K*(b*r k-y k)+i k+df k := by
    simp [u,x,stores,NominalProbe.advance,all]
  have hi (k : ℕ) : i k = lag i k+κ*g*(r k-y k)+κ*(1-g)*(lag r k-lag y k) := by
    rw [←oldi, ←eri]
    simp [i,x,stores,NominalProbe.advance,all]
  have hd (k : ℕ) : df k = α*lag df k+d*(c*r k-y k-c*lag r k+lag y k) := by
    have e : c*r k-y k-c*lag r k+lag y k = c*r k-y k-(c*lag r k-lag y k) := by ring
    rw [e,←oldd,←erd]
    simp [df,x,stores,NominalProbe.advance,all]
  have oldv (k : ℕ) : (z k).2=lag v k := by cases k <;> rfl
  have command (k : ℕ) : v k = η*r k-f*y k+t*lag v k := by rw [←oldv]; rfl
  have plant (k : ℕ) : y k = a*lag y k+b₀*lag v k+b₁*lag (lag v) k := by
    cases k with
    | zero => simp [y,z,traj,lag]
    | succ k =>
      change a*(z k).1+b₀*(z (k+1)).2+b₁*(z k).2 = _ + _ + b₁*lag v k
      rw [oldv k]; rfl
  have denom (k : ℕ) := corrected_physical_den α K b c (κ*g) (κ*(1-g)) d η f ζ a ha
    r y u i df (fun _ => 0) hu (by simpa using hi) (by simpa using hd)
    (fun k => (Integration.numerator_taps fit r y k).1)
    (fun k => (Integration.numerator_taps fit r y k).2) k
  apply same_den (α:=α) (u:=u) (v:=v)
  intro k
  rw [denom]
  simp only [den,add_zero,pole]
  linear_combination -(command k) - ζ*(plant k) - lag v k*sum

/-- The unit clock in each branch attains three updates per sample. -/
def unit : PhysicalSchedule.Clocks 1 :=
  ⟨by decide,1,1,1,0,0,0,by decide,by decide,by decide,by decide,by decide,by decide⟩

/-- An admissible physical controller realizes the unconstrained one-step MIACE
target at every reference, so the unrestricted, unreserved minimum is attained. -/
theorem unconditional_minimum {h a b₀ b₁ l : ℝ} (hh : 0<h)
    (ha : 0≤a) (ha1 : a<1) (hb : 0<b₀) (hc : 0<b₁) (hl : max 0 (b₁^2-b₀^2)<l) :
    IsLeast (costs a b₀ b₁ l h (fun _ _ _ => True)) (3/h) := by
  apply (nominal_global_minimum hh ha ha1 hb hc hl _).mp
  have hfit := OneStepBridge.one_step_matched_trajectories a b₀ b₁ l ha ha1 hb hc hl
  obtain ⟨haD,pos,_⟩ := hfit
  obtain ⟨K,κ,d,g,b,c,hK,hκ,hd,hg,hb',hc',fit⟩ := pos
  let α := -zeta b₀ b₁ l*b₁
  have αlt : α<1 := haD.2
  let TI := K*h/κ
  let TD := d*h/(K*(1-α))
  let TF := h*(1/(1-α)-0)
  have times := Matching.physical_parameters (K:=K) (k:=κ) (d:=d) (h:=h)
    (α:=α) (gD:=0) hK hκ hd hh αlt (one_div_pos.mpr (sub_pos.mpr αlt))
  obtain ⟨pI,pD,pF,eqI,eqA,eqD⟩ := times
  let q : GainGraph.Physical := ⟨K,TI,TD,TF,g,0,b,c⟩
  have ce : GainGraph.rational h h q = ⟨K,κ*g,κ*(1-g),α,d,b,c⟩ := by
    ext <;> simp only [GainGraph.rational,q,TI,TD,TF,eqI,eqA,eqD]
  have mem := (equilibrium_gains a b₀ b₁ l hb hc ((le_max_left _ _).trans_lt hl)).2
  have sum : memoryGain b₀ b₁ l+zeta b₀ b₁ l*(b₀+b₁)=1 := by
    rw [mem]; field_simp [ne_of_gt (add_pos hb hc)]
  refine ⟨UpdateOpt.rate h unit,1,unit,q,⟨hK,pI,pD,pF,hg,⟨le_rfl,zero_le_one⟩,hb',hc'⟩,trivial,?_,rfl⟩
  simpa only [unit,PhysicalSchedule.Clocks.TI,PhysicalSchedule.Clocks.TD,Nat.cast_one,
    one_mul,ce] using (fitted_origin_match αlt.ne (show α= -zeta b₀ b₁ l*b₁ from rfl) sum fit)

end
end MPCPID.CommonRealized
