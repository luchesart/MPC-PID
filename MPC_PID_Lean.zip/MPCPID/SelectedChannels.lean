import MPCPID.PhysicalSchedule
import Mathlib.Tactic.Abel

/-! Independent disturbances and selected output channels in Corollary 5.2.
The input dimension is arbitrary. The measured output may contain exogenous
noise and the plant can receive an additive state disturbance. -/
namespace MPCPID.SelectedChannels
open PhysicalLift PhysicalSchedule
noncomputable section

/-- An exogenous input vector generates a reference, sensor disturbance, and
plant-state disturbance. The output consists of a chosen linear combination of
the true output and applied input, with optional direct external feedthrough. -/
structure Ports (R : Type*) (n m o : ℕ) where
  ref : M R 1 m
  noise : M R 1 m
  force : M R n m
  select : M R o 2
  direct : M R o m

def Ports.map {R S : Type*} [Semiring R] [Semiring S] {n m o : ℕ}
    (w : Ports R n m o) (e : R →+* S) : Ports S n m o :=
  ⟨w.ref.map e,w.noise.map e,w.force.map e,w.select.map e,w.direct.map e⟩

def phase {R : Type*} [Ring R] {n m o : ℕ}
    (p : Plant R n) (g : GainGraph.Coeff R) (s : Flags) (w : Ports R n m o) :
    System R (n+5) m o :=
  let nom := physicalPhase p g s
  let ext := Gy g s * w.noise + Gr g s * w.ref
  let extraU := readBranches R * ext
  ⟨nom.A,rows (p.B*extraU+w.force) ext,
   w.select*nom.C, w.select*rows (0 : M R 1 m) extraU+w.direct⟩

set_option maxHeartbeats 650000 in
/-- This phase matrix operates on the actual plant and five branch states,
including the distinct true and noisy sensor channels. -/
theorem phase_action {R : Type*} [Ring R] {n m o : ℕ} (p : Plant R n)
    (g : GainGraph.Coeff R) (s : Flags) (w : Ports R n m o)
    (x : M R n 1) (ξ : M R 5 1) (v : M R m 1) :
    let y := p.C*x
    let ξnext := F g s*ξ + Gy g s*(y+w.noise*v) + Gr g s*(w.ref*v)
    let u := readBranches R * ξnext
    let ph := phase p g s w
    ph.A * rows x ξ + ph.B*v = rows (p.A*x + p.B*u + w.force*v) ξnext ∧
      ph.C * rows x ξ + ph.D*v = w.select * rows y u + w.direct*v := by
  dsimp only [phase,physicalPhase]
  constructor
  · rw [blocks_mul_rows,rows_mul,rows_add]
    simp only [Matrix.mul_add, Matrix.add_mul, Matrix.mul_assoc]
    abel_nf
  · simp only [Matrix.mul_assoc,Matrix.add_mul]
    rw [blocks_mul_rows,rows_mul]
    simp only [Matrix.zero_mul,add_zero]
    rw [← add_assoc, ← Matrix.mul_add, rows_add]
    congr 2
    simp only [Matrix.mul_add, Matrix.add_mul, Matrix.mul_assoc, add_zero]
    abel_nf

theorem map_phase {R S : Type*} [Ring R] [Ring S] {n m o : ℕ} (e : R →+* S)
    (p : Plant R n) (g : GainGraph.Coeff R) (s : Flags) (w : Ports R n m o) :
    (phase p g s w).map e = phase (p.map e) (GainGraph.Coeff.map e g) s (w.map e) := by
  simp [phase,physicalPhase,System.map,Plant.map,Ports.map,Matrix.map_mul,Matrix.map_add,
    map_blocks (i := 1) (j := 1) e,map_rows (i := 1) (j := 1) e]

def selectedFrame {R : Type*} [Ring R] {n m o : ℕ} (p : Plant R n)
    (g : GainGraph.Coeff R) (flags : ℕ → Flags) (w : Ports R n m o) (L : ℕ) :=
  frame (fun k => phase p g (flags k) w) L

/-- Added test inputs and selected outputs leave the autonomous transition
matrix of the physical plant–controller loop unchanged. -/
theorem same_monodromy {R : Type*} [Ring R] {n m o : ℕ} (p : Plant R n)
    (g : GainGraph.Coeff R) (flags : ℕ → Flags) (w : Ports R n m o) (L : ℕ) :
    (selectedFrame p g flags w L).A = (physicalFrame p g flags L).A := rfl

theorem map_selectedFrame {R S : Type*} [Ring R] [Ring S] {n m o : ℕ} (e : R →+* S)
    (p : Plant R n) (g : GainGraph.Coeff R) (s : ℕ → Flags) (w : Ports R n m o) (L : ℕ) :
    (selectedFrame p g s w L).map e =
      selectedFrame (p.map e) (GainGraph.Coeff.map e g) s (w.map e) L := by
  simp [selectedFrame,frame,map_frameWith,map_phase]

def compiledChannels {L n m o : ℕ} (P : Plant ℝ n) (h : ℝ) (s : Clocks L) (w : Ports ℝ n m o) :=
  selectedFrame (P.map constPoly) (GainGraph.symbolic (s.TI h) (s.TD h)) s.flags (w.map constPoly) L

theorem eval_ports {n m o : ℕ} (w : Ports ℝ n m o) (x : Fin 18 → ℝ) :
    (w.map constPoly).map (MvPolynomial.eval x) = w := by
  cases w
  simp only [Ports.map,eval_const_matrix]

/-- Corollary 5.2 with any fixed selection of exogenous and output channels,
including simultaneous independent reference, plant disturbance and sensor
noise inputs. Stability uses the full physical monodromy. -/
theorem selected_physical_feasibility {L S n t m o : ℕ} (P : Plant ℝ n)
    (w : Ports ℝ n m o) {h : ℝ} (hh : 0 < h) (sched : Fin S → Clocks L)
    (T : System ℝ t (L*m) (L*o)) :
    (∃ s, ∃ p : GainGraph.Physical, GainGraph.Admissible p ∧
      let g := GainGraph.rational ((sched s).TI h) ((sched s).TD h) p
      MatchSys (selectedFrame P g (sched s).flags w L) T ∧
        ScheduleCertificate.Stable (physicalFrame P g (sched s).flags L).A) ↔
    ∃ s, ∃ x : Fin 18 → ℝ,
      (∀ j, MvPolynomial.eval x (GainGraph.eqs ((sched s).TD h) j) = 0) ∧
      (∀ j, 0 < MvPolynomial.eval x (GainGraph.pos j)) ∧
      Certificate x (compiledChannels P h (sched s) w) T (closedPolys P h (sched s)).A := by
  apply family_search hh sched T
    (fun s g => selectedFrame P g (sched s).flags w L)
    (fun s g => (physicalFrame P g (sched s).flags L).A)
    (fun s => compiledChannels P h (sched s) w)
    (fun s => (closedPolys P h (sched s)).A)
  · intro s x
    rw [compiledChannels,map_selectedFrame,eval_ports,eval_const_plant]
  · intro s x
    exact congrArg System.A (eval_closedPolys P h (sched s) x)

end
end MPCPID.SelectedChannels
