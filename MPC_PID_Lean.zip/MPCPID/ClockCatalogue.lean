import MPCPID.UpdateOpt

/-! An explicit catalogue of all positive component periods and all legal phases.
Each schedule is compared at its least joint frame length. -/
namespace MPCPID.ClockCatalogue
open PhysicalSchedule
noncomputable section

/-- Period is the first coordinate plus one. The second coordinate is its phase. -/
abbrev Pattern := Fin 3 → (m : ℕ) × Fin (m+1)

abbrev Key (B : ℕ) := Fin 3 → (m : Fin B) × Fin (m.val+1)

def period (s : Pattern) (j : Fin 3) := (s j).1+1
def phase (s : Pattern) (j : Fin 3) := (s j).2.val
def frameLength (s : Pattern) := (period s 0).lcm ((period s 1).lcm (period s 2))

def clocks (s : Pattern) : Clocks (frameLength s) where
  frame_pos := Nat.lcm_pos (Nat.succ_pos _) (Nat.lcm_pos (Nat.succ_pos _) (Nat.succ_pos _))
  mP := period s 0
  mI := period s 1
  mD := period s 2
  φP := phase s 0
  φI := phase s 1
  φD := phase s 2
  phaseP := (s 0).2.isLt
  phaseI := (s 1).2.isLt
  phaseD := (s 2).2.isLt
  p_dvd := Nat.dvd_lcm_left _ _
  i_dvd := (Nat.dvd_lcm_left _ _).trans (Nat.dvd_lcm_right _ _)
  d_dvd := (Nat.dvd_lcm_right _ _).trans (Nat.dvd_lcm_right _ _)

/-- For the lag-one cutoff there are ten (period, phase) choices per branch,
hence exactly one thousand triples before timing or polynomial pruning. -/
theorem count_first_lag_catalogue : Fintype.card (Key 4) = 1000 := by
  simp [Key, Fintype.card_fun, Fintype.card_sigma, Fin.sum_univ_succ]

def forget {B : ℕ} (c : Key B) : Pattern := fun j => ⟨(c j).1.val,(c j).2⟩

def encode (s : Pattern) {B : ℕ} (bounded : ∀ j, period s j ≤ B) : Key B :=
  fun j => ⟨⟨(s j).1,bounded j⟩,(s j).2⟩

@[simp] theorem forget_encode (s : Pattern) {B : ℕ} (bounded : ∀ j, period s j ≤ B) :
    forget (encode s bounded) = s := by rfl

/-- The enumerator includes exactly the period-bounded schedules. -/
theorem catalogue_exact (s : Pattern) (B : ℕ) :
    (∃ k : Key B, forget k = s) ↔ ∀ j, period s j ≤ B := by
  constructor
  · rintro ⟨k,rfl⟩ j
    exact (k j).1.isLt
  · intro bounded
    exact ⟨encode s bounded,forget_encode s bounded⟩

theorem rate_optimal_iff {W : Type*} {h : ℝ} (hh : 0 < h)
    (feasible : Pattern → W → Prop) (test : Pattern → Prop)
    (exactTest : ∀ s, (∃ x, feasible s x) ↔ test s) {B : ℕ}
    (cutoff : ∀ s x, feasible s x → ∀ j, period s j ≤ B) (s : Pattern) (x : W) :
    UpdateOpt.Optimal clocks h feasible s x ↔
      feasible s x ∧ ∀ c : Key B,
        UpdateOpt.cheaper (clocks (forget c)) (clocks s) → ¬ test (forget c) := by
  rw [UpdateOpt.all_minimizers_iff clocks hh feasible test exactTest]
  constructor
  · rintro ⟨hx,hm⟩
    exact ⟨hx,fun c => hm (forget c)⟩
  · rintro ⟨hx,hm⟩
    refine ⟨hx,?_⟩
    intro v hv ht
    obtain ⟨y,hy⟩ := (exactTest v).2 ht
    have hb := cutoff v y hy
    exact hm (encode v hb) hv ht

theorem globally_attained_iff {W : Type*} (h : ℝ)
    (feasible : Pattern → W → Prop) (test : Pattern → Prop)
    (exactTest : ∀ s, (∃ x, feasible s x) ↔ test s) {B : ℕ}
    (cutoff : ∀ s x, feasible s x → ∀ j, period s j ≤ B) :
    (∃ c : Key B, test (forget c)) ↔
      ∃ s x, UpdateOpt.Optimal clocks h feasible s x := by
  constructor
  · rintro ⟨c,hc⟩
    have hf := (exactTest (forget c)).2 hc
    obtain ⟨c',x,hx,hmin⟩ :=
      UpdateOpt.minimum_attained (fun k : Key B => clocks (forget k)) h
        (fun k => feasible (forget k)) ⟨c,hf⟩
    refine ⟨forget c',x,hx,?_⟩
    intro t y hy
    exact hmin (encode t (cutoff t y hy)) y hy
  · rintro ⟨s,x,hx,_⟩
    exact ⟨encode s (cutoff s x hx),(exactTest s).1 ⟨x,hx⟩⟩

end
end MPCPID.ClockCatalogue
