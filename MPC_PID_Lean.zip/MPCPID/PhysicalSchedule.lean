import MPCPID.ScheduleCertificate
import MPCPID.PhysicalLift

/-! Concrete physical-parameter form of Corollary 5.2. The input is a finite
family of actual component clock schedules, a strictly proper SISO plant and
a prescribed linear target in its chronological lift. The right side is
constructed from these data and has only finitely many real unknowns and
polynomial tests; it does not require hand-supplied polynomial system data. -/
namespace MPCPID.PhysicalSchedule
open Matrix PhysicalLift ScheduleCertificate
noncomputable section

/-- All three component clocks divide the common frame length. An individual
schedule can use a proper divisor as its smallest period. -/
structure Clocks (L : ℕ) where
  frame_pos : 0 < L
  mP : ℕ
  mI : ℕ
  mD : ℕ
  φP : ℕ
  φI : ℕ
  φD : ℕ
  phaseP : φP < mP
  phaseI : φI < mI
  phaseD : φD < mD
  p_dvd : mP ∣ L
  i_dvd : mI ∣ L
  d_dvd : mD ∣ L

def Clocks.flags {L : ℕ} (s : Clocks L) (k : ℕ) : Flags :=
  ⟨decide (k % s.mP = s.φP),decide (k % s.mI = s.φI),decide (k % s.mD = s.φD)⟩

theorem Clocks.flags_periodic {L : ℕ} (s : Clocks L) (k : ℕ) : s.flags (k+L) = s.flags k := by
  have shift {m : ℕ} (d : m ∣ L) : (k+L)%m = k%m := by
    rw [Nat.add_mod, Nat.mod_eq_zero_of_dvd d, Nat.add_zero, Nat.mod_mod]
  simp only [Clocks.flags,shift s.p_dvd, shift s.i_dvd, shift s.d_dvd]

def Clocks.TI {L : ℕ} (s : Clocks L) (h : ℝ) : ℝ := (s.mI : ℝ)*h
def Clocks.TD {L : ℕ} (s : Clocks L) (h : ℝ) : ℝ := (s.mD : ℝ)*h

abbrev P18 := Poly 18
abbrev constPoly := (MvPolynomial.C : ℝ →+* P18)

def MatchSys {n t i o : ℕ} (F : System ℝ n i o) (T : System ℝ t i o) :=
  Same F.A F.B F.C F.D T.A T.B T.C T.D

/-- A finite polynomial feasibility test for two specified polynomial lifts
and the independent closed-loop stability requirement. -/
def Certificate {n t i o a : ℕ} (x : Fin 18 → ℝ) (F : System P18 n i o)
    (T : System ℝ t i o) (Φ : ScheduleCertificate.M P18 a a) :=
  let T' := T.map constPoly
  AtPoint x F.A F.B F.C F.D T'.A T'.B T'.C T'.D Φ

theorem eval_const_matrix {n m : ℕ} (x : Fin 18 → ℝ) (v : ScheduleCertificate.M ℝ n m) :
    (v.map constPoly).map (MvPolynomial.eval x) = v := by
  ext i j
  simp [Matrix.map_apply,constPoly]

theorem eval_const_plant {n : ℕ} (x : Fin 18 → ℝ) (p : Plant ℝ n) :
    (p.map constPoly).map (MvPolynomial.eval x) = p := by
  cases p
  simp only [Plant.map,eval_const_matrix]

theorem certify_evaluated_system {n t i o a : ℕ} (x : Fin 18 → ℝ)
    (F : System P18 n i o) (T : System ℝ t i o) (Φ : ScheduleCertificate.M P18 a a) :
    MatchSys (F.map (MvPolynomial.eval x)) T ∧ Stable (Φ.map (MvPolynomial.eval x)) ↔
    Certificate x F T Φ := by
  simpa only [MatchSys,Certificate,System.map,eval_const_matrix] using
    polynomial_match_stable x F.A F.B F.C F.D (T.map constPoly).A
      (T.map constPoly).B (T.map constPoly).C (T.map constPoly).D Φ

/-- Generic glue: physical positive parameters on the left, and explicit
polynomial gain equations and disk witnesses on the right. The two concrete
endpoints below construct the polynomial matrices internally. -/
theorem family_search {L S n t i o a : ℕ} {h : ℝ} (hh : 0 < h)
    (schedules : Fin S → Clocks L) (T : System ℝ t i o)
    (run : Fin S → GainGraph.Coeff ℝ → System ℝ n i o)
    (monodromy : Fin S → GainGraph.Coeff ℝ → ScheduleCertificate.M ℝ a a)
    (compiled : Fin S → System P18 n i o) (Φ : Fin S → ScheduleCertificate.M P18 a a)
    (hF : ∀ s x, (compiled s).map (MvPolynomial.eval x) =
      run s (GainGraph.Coeff.map (MvPolynomial.eval x)
        (GainGraph.symbolic ((schedules s).TI h) ((schedules s).TD h))))
    (hΦ : ∀ s x, (Φ s).map (MvPolynomial.eval x) =
      monodromy s (GainGraph.Coeff.map (MvPolynomial.eval x)
        (GainGraph.symbolic ((schedules s).TI h) ((schedules s).TD h)))) :
    (∃ (s : Fin S) (p : GainGraph.Physical), GainGraph.Admissible p ∧
      let g := GainGraph.rational ((schedules s).TI h) ((schedules s).TD h) p
      MatchSys (run s g) T ∧ Stable (monodromy s g)) ↔
    ∃ (s : Fin S) (x : Fin 18 → ℝ),
      (∀ j, MvPolynomial.eval x (GainGraph.eqs ((schedules s).TD h) j) = 0) ∧
      (∀ j, 0 < MvPolynomial.eval x (GainGraph.pos j)) ∧
      Certificate x (compiled s) T (Φ s) := by
  apply exists_congr
  intro s
  have hTD : 0 ≤ (schedules s).TD h := mul_nonneg (Nat.cast_nonneg _) hh.le
  apply (GainGraph.gain_feasibility ((schedules s).TI h) ((schedules s).TD h) hTD
     (fun g => MatchSys (run s g) T ∧ Stable (monodromy s g))).trans
  apply exists_congr
  intro x
  apply and_congr_right
  intro _
  apply and_congr_right
  intro _
  rw [← hF s x, ← hΦ s x]
  exact certify_evaluated_system x (compiled s) T (Φ s)

def closedPolys {L n : ℕ} (P : Plant ℝ n) (h : ℝ) (s : Clocks L) :=
  physicalFrame (P.map constPoly) (GainGraph.symbolic (s.TI h) (s.TD h)) s.flags L

theorem eval_closedPolys {L n : ℕ} (P : Plant ℝ n) (h : ℝ) (s : Clocks L)
    (x : Fin 18 → ℝ) :
    (closedPolys P h s).map (MvPolynomial.eval x) =
      physicalFrame P (GainGraph.Coeff.map (MvPolynomial.eval x)
        (GainGraph.symbolic (s.TI h) (s.TD h))) s.flags L := by
  rw [closedPolys,map_physicalFrame,eval_const_plant]

/-- Corollary 5.2 for nominal trajectory matching from the physical parameter
domain (4). Tests both y and u at every phase. Spectral stability is imposed
on the ACTUAL plant–PID monodromy; lifted target stability is not assumed. -/
theorem nominal_physical_feasibility {L S n t : ℕ} (P : Plant ℝ n) {h : ℝ}
    (hh : 0 < h) (schedules : Fin S → Clocks L) (T : System ℝ t L (L*2)) :
    (∃ (s : Fin S) (p : GainGraph.Physical), GainGraph.Admissible p ∧
      let g := GainGraph.rational ((schedules s).TI h) ((schedules s).TD h) p
      let F := physicalFrame P g (schedules s).flags L
      MatchSys F T ∧ Stable F.A) ↔
    ∃ (s : Fin S) (x : Fin 18 → ℝ),
      (∀ j, MvPolynomial.eval x (GainGraph.eqs ((schedules s).TD h) j) = 0) ∧
      (∀ j, 0 < MvPolynomial.eval x (GainGraph.pos j)) ∧
      Certificate x (closedPolys P h (schedules s)) T (closedPolys P h (schedules s)).A := by
  apply family_search hh schedules T
    (fun s g => physicalFrame P g (schedules s).flags L)
    (fun s g => (physicalFrame P g (schedules s).flags L).A)
    (fun s => closedPolys P h (schedules s))
    (fun s => (closedPolys P h (schedules s)).A)
  · exact fun s => eval_closedPolys P h (schedules s)
  · intro s x
    exact congrArg System.A (eval_closedPolys P h (schedules s) x)

def operatorPolys {L : ℕ} (h : ℝ) (s : Clocks L) :=
  operatorFrame (GainGraph.symbolic (s.TI h) (s.TD h)) s.flags L

/-- The same physical search for equality on independent reference and
measurement sequences. Internal stability is still tested in the plant–PID
interconnection. -/
theorem operator_physical_feasibility {L S n t : ℕ} (P : Plant ℝ n) {h : ℝ}
    (hh : 0 < h) (schedules : Fin S → Clocks L) (T : System ℝ t (L*2) (L*1)) :
    (∃ (s : Fin S) (p : GainGraph.Physical), GainGraph.Admissible p ∧
      let g := GainGraph.rational ((schedules s).TI h) ((schedules s).TD h) p
      let F := operatorFrame g (schedules s).flags L
      MatchSys F T ∧ Stable (physicalFrame P g (schedules s).flags L).A) ↔
    ∃ (s : Fin S) (x : Fin 18 → ℝ),
      (∀ j, MvPolynomial.eval x (GainGraph.eqs ((schedules s).TD h) j) = 0) ∧
      (∀ j, 0 < MvPolynomial.eval x (GainGraph.pos j)) ∧
      Certificate x (operatorPolys h (schedules s)) T (closedPolys P h (schedules s)).A := by
  apply family_search hh schedules T
    (fun s g => operatorFrame g (schedules s).flags L)
    (fun s g => (physicalFrame P g (schedules s).flags L).A)
    (fun s => operatorPolys h (schedules s))
    (fun s => (closedPolys P h (schedules s)).A)
  · intro s x
    exact map_operatorFrame (MvPolynomial.eval x) _ _ _
  · intro s x
    exact congrArg System.A (eval_closedPolys P h (schedules s) x)

end
end MPCPID.PhysicalSchedule
