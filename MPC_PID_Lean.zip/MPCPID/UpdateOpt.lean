import MPCPID.GainReserve
import Mathlib.Data.Int.CardIntervalMod

/-! Exact update cost and optimization over finite families of clocks.
The frame length can differ across candidates. Coincident updates on distinct
branches count separately. -/
namespace MPCPID.UpdateOpt

open PhysicalSchedule
noncomputable section

/-- Count one branch's genuine clock events at sample indices 0,...,L-1. -/
def hits (L m φ : ℕ) := L.count (fun k => k % m = φ)

theorem hits_eq_div {L m φ : ℕ} (phase : φ < m) (divides : m ∣ L) :
    hits L m φ = L / m := by
  have hm : 0 < m := by omega
  simpa [hits, Nat.ModEq, Nat.mod_eq_of_lt phase, Nat.mod_eq_zero_of_dvd divides]
    using Nat.count_modEq_card L hm φ

/-- Total number of executed branch updates, counting simultaneous ones individually. -/
def total {L : ℕ} (s : Clocks L) :=
  hits L s.mP s.φP + hits L s.mI s.φI + hits L s.mD s.φD

theorem total_eq {L : ℕ} (s : Clocks L) :
    total s = L/s.mP + L/s.mI + L/s.mD := by
  simp only [total, hits_eq_div s.phaseP s.p_dvd, hits_eq_div s.phaseI s.i_dvd,
    hits_eq_div s.phaseD s.d_dvd]

def rate {L : ℕ} (h : ℝ) (s : Clocks L) : ℝ := total s / ((L : ℝ)*h)

theorem update_rate {L : ℕ} (s : Clocks L) {h : ℝ} (hh : 0 < h) :
    rate h s = (1/(s.mP : ℝ) + 1/(s.mI : ℝ) + 1/(s.mD : ℝ))/h := by
  have hL : (0 : ℝ) < L := by exact_mod_cast s.frame_pos
  have pos {m φ : ℕ} (hf : φ < m) : (m : ℝ) ≠ 0 := by exact_mod_cast (show m ≠ 0 by omega)
  have aux {m : ℕ} (d : m ∣ L) (hm : (m : ℝ) ≠ 0) : ((L / m : ℕ) : ℝ) = (L : ℝ)/m :=
    Nat.cast_div d hm
  rw [rate, total_eq, Nat.cast_add, Nat.cast_add, aux s.p_dvd (pos s.phaseP),
    aux s.i_dvd (pos s.phaseI), aux s.d_dvd (pos s.phaseD)]
  field_simp [hL.ne', hh.ne', pos s.phaseP, pos s.phaseI, pos s.phaseD]
  ring

/-- Integer comparison of two exact update rates, including distinct frame lengths. -/
def cheaper {L M : ℕ} (s : Clocks L) (t : Clocks M) : Prop := total s * M < total t * L

theorem cheaper_iff {L M : ℕ} (s : Clocks L) (t : Clocks M) {h : ℝ} (hh : 0 < h) :
    cheaper s t ↔ rate h s < rate h t := by
  have hL : (0 : ℝ) < L := by exact_mod_cast s.frame_pos
  have hM : (0 : ℝ) < M := by exact_mod_cast t.frame_pos
  rw [rate,rate,div_lt_div_iff₀ (mul_pos hL hh) (mul_pos hM hh), ← mul_assoc, ← mul_assoc,
    mul_lt_mul_iff_of_pos_right hh]
  unfold cheaper
  norm_cast

/-- A jointly feasible schedule and choice of continuous parameters minimize
the update rate over every listed schedule and all its feasible parameter values. -/
def Optimal {ι W : Type*} {L : ι → ℕ} (clocks : (i : ι) → Clocks (L i))
    (h : ℝ) (feasible : ι → W → Prop) (i : ι) (x : W) : Prop :=
  feasible i x ∧ ∀ j y, feasible j y → rate h (clocks i) ≤ rate h (clocks j)

/-- Characterization of all minimizers, also covering ties. Only strictly
cheaper candidates must be excluded. A test can encode all continuous
parameters for each candidate jointly. -/
theorem all_minimizers_iff {ι W : Type*} {L : ι → ℕ} (clocks : (i : ι) → Clocks (L i))
    {h : ℝ} (hh : 0 < h) (feasible : ι → W → Prop) (test : ι → Prop)
    (exactTest : ∀ i, (∃ x, feasible i x) ↔ test i) (i : ι) (x : W) :
    Optimal clocks h feasible i x ↔
      feasible i x ∧ ∀ j, cheaper (clocks j) (clocks i) → ¬ test j := by
  constructor
  · rintro ⟨hx,minimum⟩
    refine ⟨hx,?_⟩
    intro j low hj
    obtain ⟨y,hy⟩ := (exactTest j).2 hj
    exact (not_lt_of_ge (minimum j y hy)) ((cheaper_iff _ _ hh).1 low)
  · rintro ⟨hx,except⟩
    refine ⟨hx,?_⟩
    intro j y hy
    apply le_of_not_gt
    intro lt
    exact except j ((cheaper_iff _ _ hh).2 lt) ((exactTest j).1 ⟨y,hy⟩)

/-- On a nonempty feasible finite catalogue the optimal update rate is attained,
even when the admissible continuous gain set is open. -/
theorem minimum_attained {ι W : Type*} [Fintype ι] {L : ι → ℕ}
    (clocks : (i : ι) → Clocks (L i)) (h : ℝ) (feasible : ι → W → Prop)
    (any : ∃ i x, feasible i x) : ∃ i x, Optimal clocks h feasible i x := by
  classical
  let cand := Finset.univ.filter (fun i => ∃ x, feasible i x)
  obtain ⟨j,x,hx⟩ := any
  have hc : cand.Nonempty := ⟨j, by simpa [cand] using (show ∃ x, feasible j x from ⟨x,hx⟩)⟩
  obtain ⟨i,hi,least⟩ := Finset.exists_min_image cand (fun i => rate h (clocks i)) hc
  obtain ⟨y,hy⟩ : ∃ y, feasible i y := by simpa [cand] using hi
  refine ⟨i,y,hy,?_⟩
  intro k z hz
  exact least k (by simpa [cand] using (show ∃ z, feasible k z from ⟨z,hz⟩))

open PhysicalLift GainReserve

/-- Complete list of optimal physical parameters: nominally implement the target
with the required gain reserve, and exclude polynomial feasibility at every
strictly cheaper rate. Chronological target lifts may use different frame lengths. -/
theorem optimal_physical_iff {ι : Type*} {L : ι → ℕ} {n t : ℕ}
    (P : Plant ℝ n) {h reserve : ℝ} (hh : 0 < h) (hr : 1 ≤ reserve)
    (s : (i : ι) → Clocks (L i)) (T : (i : ι) → System ℝ t (L i) (L i*2))
    (i : ι) (x : GainGraph.Physical) :
    Optimal s h (fun j => PhysicalAt P h reserve (s j) (T j)) i x ↔
    PhysicalAt P h reserve (s i) (T i) x ∧
      ∀ j, cheaper (s j) (s i) → ¬ PolynomialFeasible P h reserve (s j) (T j) := by
  exact all_minimizers_iff s hh _ _
    (fun j => reserve_feasibility P hh hr (s j) (T j)) i x

/-- Existence of one feasible polynomial test on a finite catalogue is exactly
existence of a globally cheapest physical schedule and parameter vector in that catalogue. -/
theorem minimum_physical_iff {ι : Type*} [Fintype ι] {L : ι → ℕ} {n t : ℕ}
    (P : Plant ℝ n) {h reserve : ℝ} (hh : 0 < h) (hr : 1 ≤ reserve)
    (s : (i : ι) → Clocks (L i)) (T : (i : ι) → System ℝ t (L i) (L i*2)) :
    (∃ i, PolynomialFeasible P h reserve (s i) (T i)) ↔
      ∃ i x, Optimal s h (fun j => PhysicalAt P h reserve (s j) (T j)) i x := by
  constructor
  · rintro ⟨i,hi⟩
    exact minimum_attained s h _ ⟨i,(reserve_feasibility P hh hr (s i) (T i)).2 hi⟩
  · rintro ⟨i,x,hx⟩
    exact ⟨i,(reserve_feasibility P hh hr (s i) (T i)).1 ⟨x,hx.1⟩⟩

end
end MPCPID.UpdateOpt
