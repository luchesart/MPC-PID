import MPCPID.TargetProbe

namespace MPCPID.TargetProbe
open NominalProbe
noncomputable section

/-- A base-rate reference delayed by s zero samples. -/
def delayed (s : ℕ) (r : ℕ → ℝ) (n : ℕ) : ℝ := if n < s then 0 else r (n-s)

@[simp] theorem delayed_tick (s : ℕ) (r : ℕ → ℝ) (k : ℕ) :
    delayed s r (s+k) = r k := by simp [delayed]

private theorem zero_advance (P I D : Prop) (K i0 i1 α β : ℝ) :
    advance P I D K i0 i1 α β 0 0 0 Periodic.rest = Periodic.rest := by
  classical
  simp [advance,Periodic.rest]

theorem traj_delayed (s : ℕ) (r : ℕ → ℝ) (a b c η f t : ℝ) :
    (∀ n ≤ s, traj a b c η f t (delayed s r) n = 0) ∧
    ∀ k, traj a b c η f t (delayed s r) (s+k) = traj a b c η f t r k := by
  have beforeStart (n : ℕ) (hn : n ≤ s) : traj a b c η f t (delayed s r) n = 0 := by
    induction n with
    | zero => rfl
    | succ n ih => simp [traj,ih (by omega),delayed, show n<s by omega]
  refine ⟨beforeStart,?_⟩
  intro k
  induction k with
  | zero => simpa [traj] using beforeStart s le_rfl
  | succ k ih =>
    rw [show s+(k+1)=(s+k)+1 from rfl]
    simp only [traj,ih,delayed_tick]

theorem stores_delayed (s : ℕ) (r : ℕ → ℝ) (P I D : ℕ → Prop)
    (K i0 i1 α β b c a b₀ b₁ η f t : ℝ) :
    let y := fun k => (traj a b₀ b₁ η f t r k).1
    let yy := fun k => (traj a b₀ b₁ η f t (delayed s r) k).1
    ∀ k, stores P I D K i0 i1 α β b c (delayed s r) yy 0 (s+k) =
      stores P I D K i0 i1 α β b c r y s k := by
  dsimp only
  obtain ⟨zt,mt⟩ := traj_delayed s r a b₀ b₁ η f t
  have beforeStart (n : ℕ) (hn : n ≤ s) :
      stores P I D K i0 i1 α β b c (delayed s r)
        (fun k => (traj a b₀ b₁ η f t (delayed s r) k).1) 0 n = Periodic.rest := by
    induction n with
    | zero => rfl
    | succ n ih =>
      simp only [stores,zt n (by omega),ih (by omega)]
      simp [delayed,show n<s by omega,zero_advance]
  intro k
  induction k with
  | zero => exact beforeStart s le_rfl
  | succ k ih =>
    rw [show s+(k+1)=(s+k)+1 from rfl]
    simp only [stores,Nat.zero_add,mt,delayed_tick,ih]

/-- Equality from a single fixed initial phase for every reference already
covers experiments starting at arbitrary clock phases. -/
theorem phase_zero_suffices (P I D : ℕ → Prop) (K i0 i1 α β b c a b₀ b₁ η f t : ℝ)
    (base : ∀ (r : ℕ → ℝ) k, let z := traj a b₀ b₁ η f t r
      let x := stores P I D K i0 i1 α β b c r (fun j => (z j).1) 0 (k+1)
      x.p+x.i+x.d=(z (k+1)).2) :
    NominalMatch P I D K i0 i1 α β b c a b₀ b₁ η f t := by
  intro r s k
  have H := base (delayed s r) (s+k)
  dsimp only at H ⊢
  simpa only [Nat.add_assoc, stores_delayed, (traj_delayed s r a b₀ b₁ η f t).2]
    using H
end
end MPCPID.TargetProbe
