import MPCPID.ClockCatalogue
import MPCPID.PeriodicExcitation

/-! Exact synthesis for a prescribed periodic target of known period H.
The common frame used by the Markov and gain-reserve tests includes H. -/
namespace MPCPID.PeriodicSynthesis
open ClockCatalogue GainGraph GainReserve PhysicalLift PhysicalSchedule
open NominalLiftBridge
noncomputable section

def joinedLength (H : ℕ) (s : Pattern) := H.lcm (frameLength s)

def joinedClocks {H : ℕ} (hH : 0<H) (s : Pattern) : Clocks (joinedLength H s) where
  frame_pos := Nat.lcm_pos hH (clocks s).frame_pos
  mP := (clocks s).mP
  mI := (clocks s).mI
  mD := (clocks s).mD
  φP := (clocks s).φP
  φI := (clocks s).φI
  φD := (clocks s).φD
  phaseP := (clocks s).phaseP
  phaseI := (clocks s).phaseI
  phaseD := (clocks s).phaseD
  p_dvd := (clocks s).p_dvd.trans (Nat.dvd_lcm_right _ _)
  i_dvd := (clocks s).i_dvd.trans (Nat.dvd_lcm_right _ _)
  d_dvd := (clocks s).d_dvd.trans (Nat.dvd_lcm_right _ _)

theorem joined_rate {H : ℕ} (hH : 0<H) (s : Pattern) {h : ℝ} (hh : 0<h) :
    UpdateOpt.rate h (joinedClocks hH s) = UpdateOpt.rate h (clocks s) := by
  exact (UpdateOpt.update_rate (joinedClocks hH s) hh).trans (UpdateOpt.update_rate (clocks s) hh).symm

@[simp] theorem joined_cheaper {H : ℕ} (hH : 0<H) (s v : Pattern) :
    UpdateOpt.cheaper (joinedClocks hH s) (joinedClocks hH v) ↔
      UpdateOpt.cheaper (clocks s) (clocks v) := by
  let hh : (0 : ℝ)<1 := zero_lt_one
  rw [UpdateOpt.cheaper_iff (joinedClocks hH s) (joinedClocks hH v) hh,
    UpdateOpt.cheaper_iff (clocks s) (clocks v) hh,
    joined_rate hH s hh,joined_rate hH v hh]

def Bound (H t : ℕ) := 2*H^2*(max (H*t) (3*H))^2

def PhysicalDesign {n t H : ℕ} (hH : 0<H) (P : Plant ℝ n)
    (X : ℕ → System ℝ t 1 2) (h R : ℝ) (s : Pattern) (p : Physical) :=
  PhysicalAt P h R (joinedClocks hH s) (liftScalar X (joinedLength H s)) p

def Test {n t H : ℕ} (hH : 0<H) (P : Plant ℝ n) (X : ℕ → System ℝ t 1 2)
    (h R : ℝ) (s : Pattern) :=
  PolynomialFeasible P h R (joinedClocks hH s) (liftScalar X (joinedLength H s))

theorem fixed_test {n t H : ℕ} (hH : 0<H) (P : Plant ℝ n) (X : ℕ → System ℝ t 1 2)
    {h R : ℝ} (hh : 0<h) (hr : 1≤R) (s : Pattern) :
    (∃ p, PhysicalDesign hH P X h R s p) ↔ Test hH P X h R s :=
  reserve_feasibility P hh hr (joinedClocks hH s) (liftScalar X (joinedLength H s))

/-- Every physically feasible schedule lies in one explicit finite catalogue,
even if no nonzero target Markov coefficients are supplied in advance. -/
theorem design_cutoff {n t H : ℕ} (hH : 0<H) (P : Plant ℝ n) (X : ℕ → System ℝ t 1 2)
    (hX : ∀ k, X (k+H)=X k) {h R : ℝ} (hh : 0<h) (hr : 1≤R)
    (s : Pattern) (p : Physical) (ok : PhysicalDesign hH P X h R s p) :
    ∀ j, period s j ≤ Bound H t := by
  have bd := PeriodicExcitation.feasible_periodic_cutoff hH (joinedClocks hH s)
    (Nat.dvd_lcm_left H (frameLength s)) P X hX p hh hr ok
  intro j
  fin_cases j
  · exact bd 0
  · exact bd 1
  · exact bd 2

/-- Full periodic synthesis and global optimality over unrestricted positive
integer periods, all legal phases and all continuously valued physical gains. -/
theorem exhaustive_periodic_search {n t H : ℕ} (hH : 0<H) (P : Plant ℝ n)
    (X : ℕ → System ℝ t 1 2) (hX : ∀ k, X (k+H)=X k) {h R : ℝ}
    (hh : 0<h) (hr : 1≤R) :
    (∃ k : Key (Bound H t), Test hH P X h R (forget k)) ↔
      ∃ s p, UpdateOpt.Optimal clocks h (PhysicalDesign hH P X h R) s p :=
  globally_attained_iff h _ _ (fixed_test hH P X hh hr) (design_cutoff hH P X hX hh hr)

/-- Ties are retained: for a specified design only strictly cheaper schedule
keys need to be excluded by the real polynomial gain-reserve tests. -/
theorem exhaustive_periodic_minimizers {n t H : ℕ} (hH : 0<H) (P : Plant ℝ n)
    (X : ℕ → System ℝ t 1 2) (hX : ∀ k, X (k+H)=X k) {h R : ℝ}
    (hh : 0<h) (hr : 1≤R) (s : Pattern) (p : Physical) :
    UpdateOpt.Optimal clocks h (PhysicalDesign hH P X h R) s p ↔
    PhysicalDesign hH P X h R s p ∧ ∀ k : Key (Bound H t),
      UpdateOpt.cheaper (clocks (forget k)) (clocks s) → ¬ Test hH P X h R (forget k) :=
  rate_optimal_iff hh _ _ (fixed_test hH P X hh hr) (design_cutoff hH P X hX hh hr) s p

end
end MPCPID.PeriodicSynthesis
