import MPCPID.NominalClock
import MPCPID.NominalProbe
import Mathlib.Tactic.LinearCombination

namespace MPCPID.NominalRigidity
open Periodic NominalProbe
noncomputable section

/-- When the I branch samples at each tick, matching just the finite
reference probe at every possible phase already forces P and D to do likewise. -/
theorem probe_pd_clocks {mP mD φP φD : ℕ} (hp : φP<mP) (hd : φD<mD)
    {I : ℕ → Prop} (fullI : ∀ n, I n)
    {K i0 i1 α β b c p B θ η a : ℝ}
    (hK : 0<K) (hβ : 0<β) (hi0 : 0≤ i0) (hi1 : 0≤ i1) (hi : 0< i0+i1)
    (hB : 0<B) (hθ : 0<θ) (hη : 0<η) (ha : 0≤a) (balance : p+B+θ=1)
    (hit : Matches (atPhase mP φP) I (atPhase mD φD) K i0 i1 α β b c p B θ η a) :
    mP=1 ∧ mD=1 := by
  let P := atPhase mP φP
  let D := atPhase mD φD
  let x := regs P I D K i0 i1 α β b c p B θ
  let X := fun k => b*refProbe p k - outProbe B θ k
  let Z := fun k => c*refProbe p k - outProbe B θ k
  let W := fun k => cmdProbe η a k - (x 0 (k+1)).i
  have ip (s k : ℕ) : (x s k).i = (x 0 k).i ∧ (x s k).eI = (x 0 k).eI := by
    induction k with
    | zero => exact ⟨rfl,rfl⟩
    | succ k ih =>
      simp only [x,regs,NominalProbe.advance,fullI,if_true] at ih ⊢
      simp [ih]
  have pd (s k : ℕ) : (x s k).p = propState P K X s k ∧
      ((x s k).d,(x s k).eD) = diffState D α β Z s k := by
    induction k with
    | zero => exact ⟨rfl,rfl⟩
    | succ k ih =>
      change ((NominalProbe.advance _ _ _ _ _ _ _ _ _ _ _ (x s k)).p = _ ∧
        ((NominalProbe.advance _ _ _ _ _ _ _ _ _ _ _ (x s k)).d,
         (NominalProbe.advance _ _ _ _ _ _ _ _ _ _ _ (x s k)).eD) = _)
      by_cases hP : P (s+k) <;> by_cases hD : D (s+k)
      all_goals simp only [propState,diffState,NominalProbe.advance,hP,hD,if_true,if_false,
        ← ih.1,← ih.2,X,Z,Prod.mk.injEq,and_self]
  apply finite_pd_rigidity hp hd hK hβ X Z W
  · simpa [X,refProbe,outProbe,pulse] using (neg_ne_zero.mpr hθ.ne')
  · norm_num [X,refProbe,outProbe,pulse]
  · intro cz
    have : c=0 := by simpa [Z,refProbe,outProbe,pulse] using cz
    simpa [Z,refProbe,outProbe,pulse,this] using (neg_ne_zero.mpr hB.ne')
  · have pos : 0< i0*θ+i1 := by
      by_cases zero : i0=0
      · simpa [zero] using hi
      · exact add_pos_of_pos_of_nonneg (mul_pos (lt_of_le_of_ne hi0 (Ne.symm zero)) hθ) hi1
    have form : W 1 = -a*η-(i0*θ+i1) := by
      norm_num [W,x,regs,NominalProbe.advance,fullI,cmdProbe,refProbe,outProbe,pulse,rest]
      linear_combination -i0*balance
    rw [form]
    linarith [mul_nonneg ha hη.le]
  · norm_num [W,x,regs,NominalProbe.advance,fullI,cmdProbe,refProbe,outProbe,pulse,rest]
    linear_combination (i0+i1)*balance
  · norm_num [W,x,regs,NominalProbe.advance,fullI,cmdProbe,refProbe,outProbe,pulse,rest]
    linear_combination (i0+i1)*balance
  · intro s k
    have e := hit s k
    change (x s (k+1)).p + (x s (k+1)).i + (x s (k+1)).d = _ at e
    have ed := congrArg Prod.fst (pd s (k+1)).2
    change (x s (k+1)).d = _ at ed
    rw [←(pd s (k+1)).1,←ed]
    dsimp only [W]
    linarith [(ip s (k+1)).1]

end
end MPCPID.NominalRigidity
