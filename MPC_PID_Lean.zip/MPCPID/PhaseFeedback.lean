import MPCPID.PhaseCorrection

/-! Shared actuator bounds may depend on causal common information. For
necessity one may observe applied commands alone and widen the last interval. -/
namespace MPCPID.PhaseCorrection
open Periodic

private theorem closed_prefix {n : ℕ} (S : Loop n) (x : Mat n 1)
    (a b : ℕ → ℝ → ℝ) (k : ℕ) (h : ∀ j < k, a j = b j) :
    S.closed x a k = S.closed x b k := by
  induction k with
  | zero => rfl
  | succ k ih =>
    simp only [Loop.closed,ih (fun j hj => h j (by omega)),h k (by omega)]

/-- Equality of applied commands alone for all nonempty intervals detects
equality of the complete free-defect maps. At the last step widen the
interval to contain both raw commands, keeping its entire past unchanged. -/
theorem applied_only_iff_free {n m : ℕ} (S : Loop n) (T : Loop m) (x : Mat n 1) (y : Mat m 1) :
    (∀ (lo hi : ℕ → ℝ), (∀ k, lo k ≤ hi k) →
      let act := fun k => Conditioned.clip (lo k) (hi k)
      ∀ k, act k (S.closedRaw x act k) = act k (T.closedRaw y act k)) ↔
    ∀ δ k, S.freeRaw x δ k = T.freeRaw y δ k := by
  constructor
  · intro h
    apply (free_iff_all_intervals S T x y).2
    intro lo hi ordered act k
    let v := S.closedRaw x act k
    let w := T.closedRaw y act k
    let lo' := fun j => if j=k then min v w else lo j
    let hi' := fun j => if j=k then max v w else hi j
    let test := fun j => Conditioned.clip (lo' j) (hi' j)
    have before (j : ℕ) (hj : j < k) : test j = act j := by
      simp [test,act,lo',hi',hj.ne]
    have hl (j : ℕ) : lo' j ≤ hi' j := by
      by_cases he : j = k
      · simp [lo',hi',he,(min_le_left v w).trans (le_max_left _ _)]
      · simp [lo',hi',he,ordered]
    have H : test k (S.closedRaw x test k) = test k (T.closedRaw y test k) := h lo' hi' hl k
    have hzS : S.closedRaw x test k = v :=
      congrArg (S.rawAt k) (closed_prefix S x test act k before)
    have hzT : T.closedRaw y test k = w :=
      congrArg (T.rawAt k) (closed_prefix T y test act k before)
    rw [hzS,hzT] at H
    have Hv : test k v = v := by
      simp [test,lo',hi',Conditioned.clip,max_eq_right (min_le_left v w),min_eq_right (le_max_left v w)]
    have Hw : test k w = w := by
      simp [test,lo',hi',Conditioned.clip,max_eq_right (min_le_right v w),min_eq_right (le_max_right v w)]
    rw [Hv,Hw] at H
    exact ⟨H,h lo hi ordered k⟩
  · intro h lo hi valid act k
    exact ((free_iff_all_intervals S T x y).1 h lo hi valid k).2

/-- Shared causal scheduling data may carry the full past, the known plant
state reconstructed from its applied input, a prior command, and the clock. -/
structure Actuator (σ : Type*) where
  apply : ℕ → σ → ℝ → ℝ
  step : ℕ → σ → ℝ → σ

def Loop.coupled {n : ℕ} {σ : Type*} (S : Loop n) (x : Mat n 1) (P : Actuator σ) (z : σ) :
    ℕ → Mat n 1 × σ
  | 0 => (x,z)
  | k+1 =>
    let q := S.coupled x P z k
    let v := S.rawAt k q.1
    let u := P.apply k q.2 v
    (S.A k*q.1 + S.drive k + (u-v) • S.E k, P.step k q.2 u)

/-- Endogenous nonempty intervals are obtained by taking P.apply to be
clipping to bounds computed from its causal state. The two closed
experiments then agree at each sample, including their actuator states. -/
theorem causal_actuator_matching {n m : ℕ} {σ : Type*}
    (S : Loop n) (T : Loop m) (x : Mat n 1) (y : Mat m 1) (P : Actuator σ) (z : σ)
    (matchRaw : ∀ δ k, S.freeRaw x δ k = T.freeRaw y δ k) (k : ℕ) :
    let p := S.coupled x P z k
    let q := T.coupled y P z k
    let v := S.rawAt k p.1
    let w := T.rawAt k q.1
    p.2 = q.2 ∧ v = w ∧ P.apply k p.2 v = P.apply k q.2 w := by
  let run := S.coupled x P z
  let raw := fun k => S.rawAt k (run k).1
  let δ := fun k => P.apply k (run k).2 (raw k) - raw k
  have hs (j : ℕ) : S.free x δ j = (run j).1 := by
    induction j with
    | zero => rfl
    | succ j ih =>
      change S.A j*S.free x δ j+S.drive j+δ j • S.E j = _
      rw [ih]
      rfl
  have hr (j : ℕ) : T.freeRaw y δ j = raw j :=
    (matchRaw δ j).symm.trans (congrArg (S.rawAt j) (hs j))
  have ht (j : ℕ) : T.coupled y P z j = (T.free y δ j,(run j).2) := by
    induction j with
    | zero => rfl
    | succ j ih =>
      change (let q := T.coupled y P z j
              let v := T.rawAt j q.1
              let u := P.apply j q.2 v
              (T.A j*q.1 + T.drive j + (u-v) • T.E j, P.step j q.2 u)) = _
      rw [ih]
      change (T.A j*T.free y δ j+T.drive j+
        (P.apply j (run j).2 (T.freeRaw y δ j) - T.freeRaw y δ j) • T.E j,
        P.step j (run j).2 (P.apply j (run j).2 (T.freeRaw y δ j))) = _
      rw [hr]
      rfl
  dsimp only
  rw [ht]
  change (run k).2 = (run k).2 ∧ raw k = T.freeRaw y δ k ∧
    P.apply k (run k).2 (raw k) = P.apply k (run k).2 (T.freeRaw y δ k)
  rw [hr]
  exact ⟨rfl,rfl,rfl⟩

end MPCPID.PhaseCorrection
