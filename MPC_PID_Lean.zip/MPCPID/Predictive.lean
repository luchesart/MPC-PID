import Mathlib.Tactic.Abel
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Analysis.Normed.Module.Basic
import Mathlib.Data.Real.Sqrt
import Mathlib.Topology.Order.Compact
import Mathlib.Topology.MetricSpace.HausdorffDistance
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.Topology.Algebra.Order.Field
import Mathlib.Algebra.Order.BigOperators.Group.Finset

/-! Real-valued finite-horizon MIACE, the prescribed one-step law and
regular KKT regions (Sections 7 and 8 of the paper). -/

namespace MPCPID.Predictive

noncomputable section

open Finset

/-- Squared MIACE in the two accumulated area coordinates. -/
def cost (l a b : ℝ) : ℝ := a ^ 2 + l * b ^ 2

def miace (l a b : ℝ) : ℝ := Real.sqrt (cost l a b)

theorem miace_sq {l : ℝ} (hl : 0 ≤ l) (a b : ℝ) :
    miace l a b ^ 2 = cost l a b :=
  Real.sq_sqrt (add_nonneg (sq_nonneg _) (mul_nonneg hl (sq_nonneg _)))

theorem pareto_exists {X : Type*} [TopologicalSpace X] {K : Set X}
    (hK : IsCompact K) (hne : K.Nonempty) {A B : X → ℝ}
    (hA : ContinuousOn A K) (hB : ContinuousOn B K) (l : ℝ) :
    ∃ x ∈ K, ∀ y ∈ K, cost l (A x) (B x) ≤ cost l (A y) (B y) := by
  exact hK.exists_isMinOn hne ((hA.pow 2).add (continuousOn_const.mul (hB.pow 2)))

theorem pareto_efficient {l a b c d : ℝ} (hl : 0 < l) (hc : 0 ≤ c) (hd : 0 ≤ d)
    (hca : c ≤ a) (hdb : d ≤ b) (hstrict : c < a ∨ d < b) :
    cost l c d < cost l a b := by
  have ha : c*c ≤ a*a := mul_self_le_mul_self hc hca
  have hb : d*d ≤ b*b := mul_self_le_mul_self hd hdb
  rcases hstrict with hac | hbd
  · have h := mul_self_lt_mul_self hc hac
    unfold cost
    nlinarith only [h, mul_le_mul_of_nonneg_left hb hl.le]
  · have h := mul_self_lt_mul_self hd hbd
    unfold cost
    nlinarith only [ha, mul_lt_mul_of_pos_left h hl]

theorem weight_tradeoff {l₁ l₂ a₁ a₂ b₁ b₂ : ℝ}
    (hl : 0 < l₁) (hw : l₁ < l₂) (ha : 0 ≤ a₂) (hb : 0 ≤ b₁)
    (h₁ : cost l₁ a₁ b₁ ≤ cost l₁ a₂ b₂)
    (h₂ : cost l₂ a₂ b₂ ≤ cost l₂ a₁ b₁) :
    b₂ ≤ b₁ ∧ a₁ ≤ a₂ := by
  unfold cost at *
  have hb' : b₂ ≤ b₁ := by
    by_contra! h
    have hs := mul_self_lt_mul_self hb h
    nlinarith only [h₁, h₂, mul_pos (sub_pos.mpr hw)
      (show 0 < b₂ ^ 2 - b₁ ^ 2 by nlinarith only [hs])]
  refine ⟨hb', ?_⟩
  by_contra! h
  have hs := mul_self_lt_mul_self ha h
  have hbs : b₂ ^ 2 ≤ b₁ ^ 2 := by
    by_contra! hn
    have hprod : 0 < (l₂-l₁)*(b₂^2-b₁^2) := mul_pos (sub_pos.mpr hw) (sub_pos.mpr hn)
    nlinarith only [hprod,h₁,h₂]
  nlinarith only [h₁,hs,mul_le_mul_of_nonneg_left hbs hl.le]

theorem weighted_triangle {l : ℝ} (hl : 0 ≤ l) (a b c d : ℝ) :
    miace l (a+c) (b+d) ≤ miace l a b + miace l c d := by
  have h₁ : 0 ≤ miace l a b := Real.sqrt_nonneg _
  have h₂ : 0 ≤ miace l c d := Real.sqrt_nonneg _
  have hdet : (miace l a b * miace l c d)^2 - (a*c+l*b*d)^2
      = l*(a*d-c*b)^2 := by
    rw [mul_pow,miace_sq hl,miace_sq hl]
    unfold cost
    ring
  have hdot : a*c+l*b*d ≤ miace l a b * miace l c d := by
    by_contra! h
    have hlt := mul_self_lt_mul_self (mul_nonneg h₁ h₂) h
    nlinarith only [hdet,hlt,mul_nonneg hl (sq_nonneg (a*d-c*b))]
  by_contra! h
  have hlt := mul_self_lt_mul_self (add_nonneg h₁ h₂) h
  have h3 := miace_sq hl (a+c) (b+d)
  have h4 := miace_sq hl a b
  have h5 := miace_sq hl c d
  unfold cost at h3 h4 h5
  nlinarith only [h3,h4,h5,hdot,hlt]

/-- Equality in Cauchy--Schwarz for the two nonnegative area coordinates. -/
theorem coordinate_defect {l : ℝ} (hl : 0 < l) {a b c d : ℝ}
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hc : 0 ≤ c) (hd : 0 ≤ d) :
    0 ≤ miace l a b*miace l c d-(a*c+l*b*d) ∧
    (miace l a b*miace l c d-(a*c+l*b*d)=0 ↔ a*d=c*b) := by
  let m := miace l a b*miace l c d
  let q := a*c+l*b*d
  have hm : 0 ≤ m := mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)
  have hq : 0 ≤ q := add_nonneg (mul_nonneg ha hc) (mul_nonneg (mul_nonneg hl.le hb) hd)
  have hdet : m^2-q^2 = l*(a*d-c*b)^2 := by
    dsimp [m,q]; rw [mul_pow,miace_sq hl.le,miace_sq hl.le]; unfold cost; ring
  change 0 ≤ m-q ∧ (m-q=0 ↔ a*d=c*b)
  constructor
  · by_contra! h
    nlinarith only [mul_self_lt_mul_self hm (show m<q by linarith),hdet,
      mul_nonneg hl.le (sq_nonneg (a*d-c*b))]
  · constructor
    · intro h
      have : m=q := sub_eq_zero.mp h
      rw [this,sub_self] at hdet
      by_contra hn
      exact (ne_of_gt (mul_pos hl (sq_pos_of_ne_zero (sub_ne_zero.mpr hn)))) hdet.symm
    · intro h
      have he : m^2=q^2 := by rw [h,sub_self] at hdet; simpa using sub_eq_zero.mp (show m^2-q^2=0 by simpa using hdet)
      exact sub_eq_zero.mpr ((sq_eq_sq₀ hm hq).mp he)

/-- Triangle inequality across the entire horizon, with the equality case of
(54). For vectors in the nonnegative quadrant, zero cross products mean
that every nonzero vector lies on the same ray. -/
theorem temporal_triangle {ι : Type*} [Fintype ι] (a b : ι → ℝ) {l : ℝ}
    (hl : 0 < l) (ha : ∀ i, 0 ≤ a i) (hb : ∀ i, 0 ≤ b i) :
    miace l (∑ i, a i) (∑ i, b i) ≤ ∑ i, miace l (a i) (b i) ∧
    (miace l (∑ i, a i) (∑ i, b i) = ∑ i, miace l (a i) (b i) ↔
      ∀ i j, a i*b j=a j*b i) := by
  classical
  let m := fun i => miace l (a i) (b i)
  let R := fun i j => m i*m j - (a i*a j+(l*b i)*b j)
  have pos (i j : ι) : 0 ≤ R i j := (coordinate_defect hl (ha i) (hb i) (ha j) (hb j)).1
  have row (i : ι) : 0 ≤ ∑ j, R i j := sum_nonneg fun j _ => pos i j
  have total : 0 ≤ ∑ i, ∑ j, R i j := sum_nonneg fun i _ => row i
  let S := ∑ i, m i
  let V := miace l (∑ i, a i) (∑ i, b i)
  have hv : 0 ≤ V := Real.sqrt_nonneg _
  have hs : 0 ≤ S := sum_nonneg fun i _ => Real.sqrt_nonneg _
  have identity : (∑ i, ∑ j, R i j)=S^2-V^2 := by
    dsimp only [V,S,R]
    rw [miace_sq hl.le]
    simp only [sum_sub_distrib,sum_add_distrib,← mul_sum,← sum_mul]
    unfold cost
    ring
  have le : V ≤ S := by
    by_contra! hh
    nlinarith only [identity,total,mul_self_lt_mul_self hs hh]
  refine ⟨le,?_,?_⟩
  · intro h i j
    change V=S at h
    have all0 : (∑ i, ∑ j, R i j)=0 := by rw [identity,h,sub_self]
    have hj : R i j ≤ ∑ j, R i j := single_le_sum (fun k _ => pos i k) (mem_univ j)
    have hi : (∑ j, R i j) ≤ ∑ k, ∑ j, R k j := single_le_sum (fun k _ => row k) (mem_univ i)
    apply (coordinate_defect hl (ha i) (hb i) (ha j) (hb j)).2.mp
    change R i j=0
    linarith only [all0,hj,hi,pos i j]
  · intro h
    have hz (i j : ι) : R i j=0 :=
      (coordinate_defect hl (ha i) (hb i) (ha j) (hb j)).2.mpr (h i j)
    have all0 : (∑ i, ∑ j, R i j)=0 := by simp [hz]
    change V=S
    by_contra hn
    have hstrict := lt_of_le_of_ne le hn
    nlinarith only [identity,all0,mul_self_lt_mul_self hv hstrict]

theorem miace_sign (l a b : ℝ) : miace l (-a) (-b) = miace l a b := by
  simp [miace,cost]

theorem sensitivity_coordinates {l A B A' B' e u : ℝ} (hl : 0 ≤ l)
    (he : |A-A'| ≤ e) (hu : |B-B'| ≤ u) :
    |miace l A B - miace l A' B'| ≤ Real.sqrt (e^2+l*u^2) := by
  have hbound : miace l (A-A') (B-B') ≤ Real.sqrt (e^2+l*u^2) := by
    apply Real.sqrt_le_sqrt
    have ha := mul_self_le_mul_self (abs_nonneg (A-A')) he
    have hb := mul_self_le_mul_self (abs_nonneg (B-B')) hu
    simp only [← sq, sq_abs] at ha hb
    unfold cost
    exact add_le_add ha (mul_le_mul_of_nonneg_left hb hl)
  have hback : miace l (A'-A) (B'-B) = miace l (A-A') (B-B') := by
    convert miace_sign l (A-A') (B-B') using 2 <;> ring
  have h1 := weighted_triangle hl A' B' (A-A') (B-B')
  have h2 := weighted_triangle hl A B (A'-A) (B'-B)
  rw [hback] at h2
  have ea : A'+(A-A')=A := by ring
  have eb : B'+(B-B')=B := by ring
  have ec : A+(A'-A)=A' := by ring
  have ed : B+(B'-B)=B' := by ring
  rw [ea,eb] at h1
  rw [ec,ed] at h2
  exact abs_le.mpr ⟨by linarith,by linarith⟩

/-- The convolution (56), written with powers in increasing order. -/
def delta (Lx Lu : ℝ) (d : ℕ → ℝ) : ℕ → ℝ
  | 0 => 0
  | n+1 => Lx * delta Lx Lu d n + Lu*d n

theorem delta_convolution (Lx Lu : ℝ) (d : ℕ → ℝ) (n : ℕ) :
    delta Lx Lu d n = Lu * ∑ i ∈ range n, Lx^(n-1-i)*d i := by
  induction n with
  | zero => simp [delta]
  | succ n ih =>
    rw [delta,ih,sum_range_succ]
    simp only [Nat.add_one_sub_one,Nat.sub_self,pow_zero,one_mul]
    have eq : (∑ i ∈ range n, Lx^(n-i)*d i) =
        Lx * ∑ i ∈ range n, Lx^(n-1-i)*d i := by
      rw [mul_sum]
      apply sum_congr rfl
      intro i hi
      have hi' := mem_range.mp hi
      rw [show n-i = n-1-i+1 by omega,pow_succ]
      ring
    rw [eq]
    ring

theorem propagate {Lx Lu : ℝ} (hLx : 0 ≤ Lx) (d e : ℕ → ℝ)
    (h₀ : e 0 ≤ 0) (hstep : ∀ k, e (k+1) ≤ Lx*e k+Lu*d k) (n : ℕ) :
    e n ≤ delta Lx Lu d n := by
  induction n with
  | zero => exact h₀
  | succ k ih =>
    exact (hstep k).trans (add_le_add_right (mul_le_mul_of_nonneg_left ih hLx) _)

theorem area_difference {n : ℕ} {a b bound : ℕ → ℝ} {t t' tail : ℝ}
    (hs : ∀ i < n, |a i-b i| ≤ bound i) (ht : |t-t'| ≤ tail) :
    |((∑ i ∈ range n, a i)+t)-((∑ i ∈ range n, b i)+t')| ≤
      (∑ i ∈ range n, bound i)+tail := by
  have boundSum : |∑ i ∈ range n, (a i-b i)| ≤ ∑ i ∈ range n, bound i := by
    calc
      _ ≤ ∑ i ∈ range n, |a i-b i| := Finset.abs_sum_le_sum_abs _ _
      _ ≤ _ := sum_le_sum fun i hi => hs i (mem_range.mp hi)
  rw [show (∑ i ∈ range n, a i)+t-((∑ i ∈ range n,b i)+t') =
      (∑ i ∈ range n,(a i-b i))+(t-t') by rw [sum_sub_distrib]; ring]
  exact (abs_add_le _ _).trans (add_le_add boundSum ht)

/-- Joint finite-horizon coordinate estimate with terminal terms (57)–(58). -/
theorem finite_horizon_sensitivity {n : ℕ} {l : ℝ} (hl : 0 ≤ l)
    (a b a' b' de du : ℕ → ℝ) (te tu te' tu' De Du : ℝ)
    (H₁ : ∀ i < n, |a i-a' i| ≤ de i) (H₂ : ∀ i < n, |b i-b' i| ≤ du i)
    (Ht₁ : |te-te'| ≤ De) (Ht₂ : |tu-tu'| ≤ Du) :
    |miace l ((∑ i ∈ range n, a i)+te) ((∑ i ∈ range n, b i)+tu) -
     miace l ((∑ i ∈ range n, a' i)+te') ((∑ i ∈ range n, b' i)+tu')| ≤
    Real.sqrt (((∑ i ∈ range n, de i)+De)^2+l*((∑ i ∈ range n, du i)+Du)^2) :=
  sensitivity_coordinates hl (area_difference H₁ Ht₁) (area_difference H₂ Ht₂)

/-- A complete specialization of Proposition 7.2 to any compatible metric on
states and to the output/command metrics used in the stage costs.  The
Lipschitz estimates only need to hold along the two feasible rollouts. -/
theorem rollout_sensitivity
    {X U Y : Type*} [PseudoMetricSpace X] [PseudoMetricSpace U] [PseudoMetricSpace Y]
    {n : ℕ} {l h Lx Lu Lg Le Lt : ℝ} (hl : 0 ≤ l) (hh : 0 ≤ h)
    (hLx : 0 ≤ Lx) (hLg : 0 ≤ Lg) (hLe : 0 ≤ Le) (hLt : 0 ≤ Lt)
    (F : X → U → X) (g : X → Y) (x x' : ℕ → X) (u u' : ℕ → U)
    (r : Y) (s : U) (φe φu : X → ℝ) (hx : x 0=x' 0)
    (hd : ∀ k, x (k+1)=F (x k) (u k)) (hd' : ∀ k, x' (k+1)=F (x' k) (u' k))
    (hF : ∀ k, dist (F (x k) (u k)) (F (x' k) (u' k)) ≤
      Lx*dist (x k) (x' k)+Lu*dist (u k) (u' k))
    (hg : ∀ k, dist (g (x k)) (g (x' k)) ≤ Lg*dist (x k) (x' k))
    (he : |φe (x n)-φe (x' n)| ≤ Le*dist (x n) (x' n))
    (ht : |φu (x n)-φu (x' n)| ≤ Lt*dist (x n) (x' n)) :
    let d := fun k => dist (u k) (u' k)
    let D := delta Lx Lu d
    let err := fun (t : ℕ → X) => (∑ k ∈ range n, h*dist (g (t (k+1))) r)+φe (t n)
    let effort := fun (t : ℕ → X) (v : ℕ → U) => (∑ k ∈ range n, h*dist (v k) s)+φu (t n)
    |miace l (err x) (effort x u) - miace l (err x') (effort x' u')| ≤
      Real.sqrt (((∑ k ∈ range n, h*(Lg*D (k+1)))+Le*D n)^2+
        l*((∑ k ∈ range n, h*d k)+Lt*D n)^2) := by
  let d := fun k => dist (u k) (u' k)
  let D := delta Lx Lu d
  have hstates (k : ℕ) : dist (x k) (x' k) ≤ D k := by
    apply propagate hLx d (fun k => dist (x k) (x' k))
    · simp [hx]
    · intro j; dsimp [d]; rw [hd,hd']; exact hF j
  have hae (k : ℕ) : |h*dist (g (x (k+1))) r - h*dist (g (x' (k+1))) r| ≤
      h*(Lg*D (k+1)) := by
    rw [← mul_sub,abs_mul,abs_of_nonneg hh]
    exact mul_le_mul_of_nonneg_left ((abs_dist_sub_le _ _ _).trans
      ((hg _).trans (mul_le_mul_of_nonneg_left (hstates _) hLg))) hh
  have hau (k : ℕ) : |h*dist (u k) s - h*dist (u' k) s| ≤ h*d k := by
    rw [← mul_sub,abs_mul,abs_of_nonneg hh]
    exact mul_le_mul_of_nonneg_left (abs_dist_sub_le _ _ _) hh
  exact finite_horizon_sensitivity hl _ _ _ _ _ _ _ _ _ _ _ _
    (fun i _ => hae i) (fun i _ => hau i)
    (he.trans (mul_le_mul_of_nonneg_left (hstates _) hLe))
    (ht.trans (mul_le_mul_of_nonneg_left (hstates _) hLt))

/-- Two affine first-move laws agreeing on a region with nonempty interior
have identical coefficients, as used in Section 8.1. -/
theorem affine_region_coefficients {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (A B : E →ₗ[ℝ] ℝ) (a b : ℝ) {S : Set E} (hs : (interior S).Nonempty)
    (eq : ∀ x ∈ S, a+A x=b+B x) : a=b ∧ A=B := by
  obtain ⟨c,hc⟩ := hs
  obtain ⟨ε,hε,hball⟩ := Metric.isOpen_iff.mp isOpen_interior c hc
  have hc' := eq c (interior_subset hc)
  have hab : A=B := by
    ext d
    let t : ℝ := ε/(2*(1+‖d‖))
    have ht : 0 < t := by dsimp [t]; positivity
    have hbnd : t*‖d‖ < ε := by
      dsimp [t]
      rw [div_mul_eq_mul_div]
      apply (div_lt_iff₀ (by positivity)).2
      nlinarith only [hε,mul_nonneg hε.le (norm_nonneg d)]
    have hi : c+t • d ∈ Metric.ball c ε := by
      rw [Metric.mem_ball,dist_eq_norm,add_sub_cancel_left,norm_smul,Real.norm_eq_abs,
        abs_of_pos ht]
      exact hbnd
    have hp := eq _ (interior_subset (hball hi))
    simp only [map_add,map_smul,smul_eq_mul] at hp
    apply (mul_left_cancel₀ (ne_of_gt ht))
    linarith only [hp,hc']
  exact ⟨by rw [hab] at hc'; linarith,hab⟩

theorem fixed_law_obstruction {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (A B C : E →ₗ[ℝ] ℝ) (a b c : ℝ) {S T : Set E}
    (hs : (interior S).Nonempty) (ht : (interior T).Nonempty)
    (hAB : a≠b ∨ A≠B) (hS : ∀ x ∈ S, c+C x=a+A x) :
    ¬∀ x ∈ T, c+C x=b+B x := by
  intro hT
  obtain ⟨h₁,h₂⟩ := affine_region_coefficients C A c a hs hS
  obtain ⟨h₃,h₄⟩ := affine_region_coefficients C B c b ht hT
  rcases hAB with h | h
  · exact h (h₁.symm.trans h₃)
  · exact h (h₂.symm.trans h₄)

theorem compact_pareto_minimizer {X : Type*} [TopologicalSpace X] {K : Set X}
    (hK : IsCompact K) (hn : K.Nonempty) {A B : X → ℝ}
    (hA : ContinuousOn A K) (hB : ContinuousOn B K)
    (hA₀ : ∀ x ∈ K, 0 ≤ A x) (hB₀ : ∀ x ∈ K, 0 ≤ B x)
    {l : ℝ} (hl : 0 < l) :
    ∃ x ∈ K, (∀ y ∈ K, cost l (A x) (B x) ≤ cost l (A y) (B y)) ∧
      ∀ y ∈ K, A y ≤ A x → B y ≤ B x → ¬(A y < A x ∨ B y < B x) := by
  obtain ⟨x,hx,hmin⟩ := pareto_exists hK hn hA hB l
  exact ⟨x,hx,hmin,fun y hy ha hb h =>
    (not_lt_of_ge (hmin y hy)) (pareto_efficient hl (hA₀ y hy) (hB₀ y hy) ha hb h)⟩

def objective (b l s q u : ℝ) : ℝ := (q-b*u)^2+l*(u-s)^2
def minimizer (b l s q : ℝ) : ℝ := (b*q+l*s)/(b^2+l)

theorem square_completion (b l s q u : ℝ) (hl : 0 < l) :
    objective b l s q u - objective b l s q (minimizer b l s q) =
    (b^2+l)*(u-minimizer b l s q)^2 := by
  have hD : b^2+l ≠ 0 := ne_of_gt (add_pos_of_nonneg_of_pos (sq_nonneg _) hl)
  unfold objective minimizer
  field_simp
  ring

theorem unique_one_step (b l s q u : ℝ) (hl : 0 < l) (hu : u ≠ minimizer b l s q) :
    objective b l s q (minimizer b l s q) < objective b l s q u := by
  apply sub_pos.mp
  rw [square_completion _ _ _ _ _ hl]
  exact mul_pos (add_pos_of_nonneg_of_pos (sq_nonneg _) hl) (sq_pos_of_ne_zero (sub_ne_zero.mpr hu))

/-- The sampled one-step MIACE criterion (61), with its sampling period. -/
def oneStepMIACE (h b l s q u : ℝ) := h*miace l |q-b*u| |u-s|

theorem one_step_objective_squared {l : ℝ} (hl : 0 ≤ l) (h b s q u : ℝ) :
    oneStepMIACE h b l s q u ^ 2 = h^2*objective b l s q u := by
  unfold oneStepMIACE
  rw [mul_pow,miace_sq hl]
  simp [cost,objective]

theorem unique_sampled_miace (h b l s q u : ℝ) (hh : 0 < h) (hl : 0 < l)
    (hu : u ≠ minimizer b l s q) :
    oneStepMIACE h b l s q (minimizer b l s q) < oneStepMIACE h b l s q u := by
  have nonneg (v : ℝ) : 0 ≤ oneStepMIACE h b l s q v :=
    mul_nonneg hh.le (Real.sqrt_nonneg _)
  apply (sq_lt_sq₀ (nonneg _) (nonneg _)).mp
  rw [one_step_objective_squared hl.le,one_step_objective_squared hl.le]
  exact mul_lt_mul_of_pos_left (unique_one_step b l s q u hl hu) (sq_pos_of_pos hh)

def eta (a b c l : ℝ) : ℝ := (b+l*(1-a)/(b+c))/(b^2+l)
def fy (a b l : ℝ) : ℝ := a*b/(b^2+l)
def memoryGain (b c l : ℝ) : ℝ := -(b*c)/(b^2+l)
def zeta (b c l : ℝ) : ℝ := (b*(b+c)+l)/((b^2+l)*(b+c))
def pole (a b c l : ℝ) : ℝ := (a*l-b*c)/(b^2+l)

theorem one_step_rational_parameters :
    let a : ℝ := 1/2
    let b : ℝ := 1
    let c : ℝ := 1/2
    let l : ℝ := 1
    let z := zeta b c l
    let α := -z*c
    let η := eta a b c l
    let f := fy a b l
    let κ := η/(1-α)
    let d := (α^2*(f+z)-α*a*z)/(1-α)^2
    let K := f+z-d-κ/2
    η=2/3 ∧ f=1/4 ∧ memoryGain b c l = -1/4 ∧ α= -5/12 ∧
    K=193/289 ∧ K/κ=193/136 ∧ d/(K*(1-α))=625/3281 ∧
    1/(1-α)-1/2=7/34 ∧ 1-a*z/((1-α)*K)=108/193 ∧
    1+α*a*z/((1-α)*d)=8/25 := by norm_num [eta,fy,memoryGain,zeta]

theorem first_move (a b c l r y v : ℝ) (hb : 0 < b) (hc : 0 < c) (hl : 0 < l) :
    minimizer b l ((1-a)*r/(b+c)) (r-a*y-c*v) =
    eta a b c l*r - fy a b l*y + memoryGain b c l*v := by
  have hs := ne_of_gt (add_pos hb hc)
  have hD := ne_of_gt (add_pos_of_nonneg_of_pos (sq_nonneg b) hl)
  unfold minimizer eta fy memoryGain
  field_simp
  ring

theorem equilibrium_gains (a b c l : ℝ) (hb : 0 < b) (hc : 0 < c) (hl : 0 < l) :
    eta a b c l = fy a b l + zeta b c l*(1-a) ∧
    zeta b c l = (1-memoryGain b c l)/(b+c) := by
  have hs := ne_of_gt (add_pos hb hc)
  have hD := ne_of_gt (add_pos_of_nonneg_of_pos (sq_nonneg b) hl)
  unfold eta fy zeta memoryGain
  constructor <;> field_simp <;> ring

theorem realization_threshold (b c l : ℝ) (hb : 0 < b) (hc : 0 < c) (hl : 0 < l) :
    zeta b c l*c < 1 ↔ c^2-b^2 < l := by
  have hD := add_pos_of_nonneg_of_pos (sq_nonneg b) hl
  have hs := add_pos hb hc
  unfold zeta
  rw [div_mul_eq_mul_div,div_lt_iff₀ (mul_pos hD hs)]
  constructor
  · intro h
    by_contra! h'
    nlinarith only [h,mul_le_mul_of_nonneg_left h' hb.le]
  · intro h
    nlinarith only [mul_lt_mul_of_pos_left h hb]

theorem realization_hypotheses (a b c l : ℝ) (ha : a < 1)
    (hb : 0 < b) (hc : 0 < c) (hl : max 0 (c^2-b^2) < l) :
    0 < eta a b c l ∧ 0 < zeta b c l ∧ zeta b c l*c < 1 := by
  have hl' : 0 < l := (le_max_left _ _).trans_lt hl
  refine ⟨?_,?_,(realization_threshold b c l hb hc hl').2 ((le_max_right _ _).trans_lt hl)⟩
  · unfold eta
    exact div_pos (add_pos hb (div_pos (mul_pos hl' (sub_pos.mpr ha)) (add_pos hb hc)))
      (add_pos_of_nonneg_of_pos (sq_nonneg _) hl')
  · unfold zeta
    positivity

theorem schur_pole (a b c l : ℝ) (ha₀ : 0 ≤ a) (ha : a < 1)
    (hb : 0 < b) (hc : 0 < c) (hl : max 0 (c^2-b^2) < l) :
    -1 < pole a b c l ∧ pole a b c l < 1 := by
  have hl' : 0 < l := (le_max_left _ _).trans_lt hl
  have hbc : c^2-b^2 < l := (le_max_right _ _).trans_lt hl
  have hD := add_pos_of_nonneg_of_pos (sq_nonneg b) hl'
  unfold pole
  constructor
  · apply (lt_div_iff₀ hD).2
    by_cases hb' : c ≤ b
    · nlinarith only [mul_le_mul_of_nonneg_left hb' hb.le,hl',mul_nonneg ha₀ hl'.le]
    · nlinarith only [mul_nonneg (sub_nonneg.mpr (le_of_not_ge hb')) hc.le,hbc,mul_nonneg ha₀ hl'.le]
  · apply (div_lt_iff₀ hD).2
    nlinarith only [mul_lt_mul_of_pos_right ha hl',mul_pos hb hc,sq_nonneg b]

theorem char_factor (a b c l z : ℝ) (hl : 0 < l) :
    (z-a*l/(b^2+l))*(z+b*c/(b^2+l)) - (c*l/(b^2+l))*(-a*b/(b^2+l)) =
    z*(z-pole a b c l) := by
  have hD := ne_of_gt (add_pos_of_nonneg_of_pos (sq_nonneg b) hl)
  unfold pole
  field_simp
  ring

def clip (L H u : ℝ) : ℝ := min H (max L u)

theorem interval_iff (a b c y v u ul uh yl yh : ℝ) (hb : 0 < b) :
    (ul ≤ u ∧ u ≤ uh ∧ yl ≤ a*y+b*u+c*v ∧ a*y+b*u+c*v ≤ yh) ↔
    (max ul ((yl-a*y-c*v)/b) ≤ u ∧ u ≤ min uh ((yh-a*y-c*v)/b)) := by
  rw [max_le_iff,le_min_iff,div_le_iff₀ hb,le_div_iff₀ hb]
  constructor
  · rintro ⟨h₁,h₂,h₃,h₄⟩
    exact ⟨⟨h₁,by nlinarith only [h₃]⟩,⟨h₂,by nlinarith only [h₄]⟩⟩
  · rintro ⟨⟨h₁,h₃⟩,h₂,h₄⟩
    exact ⟨h₁,h₂,by nlinarith only [h₃],by nlinarith only [h₄]⟩

theorem clip_feasible {L H : ℝ} (h : L ≤ H) (v : ℝ) :
    L ≤ clip L H v ∧ clip L H v ≤ H := by
  exact ⟨le_min h (le_max_left _ _),min_le_left _ _⟩

theorem clip_strict {L H v u : ℝ} (h : L ≤ H) (hL : L ≤ u) (hH : u ≤ H)
    (hne : u ≠ clip L H v) :
    (clip L H v-v)^2 < (u-v)^2 := by
  unfold clip at *
  by_cases h₁ : v ≤ L
  · rw [max_eq_left h₁,min_eq_right h] at *
    have hu := lt_of_le_of_ne hL (Ne.symm hne)
    nlinarith only [mul_self_lt_mul_self (sub_nonneg.mpr h₁) (sub_lt_sub_right hu v)]
  · have h₁' := le_of_not_ge h₁
    rw [max_eq_right h₁'] at *
    by_cases h₂ : v ≤ H
    · rw [min_eq_right h₂] at *
      simpa using sq_pos_of_ne_zero (sub_ne_zero.mpr hne)
    · have h₂' := le_of_not_ge h₂
      rw [min_eq_left h₂'] at *
      have hu := lt_of_le_of_ne hH hne
      nlinarith only [mul_self_lt_mul_self (sub_nonneg.mpr h₂') (sub_lt_sub_left hu v)]

theorem projected_unique (b l s q L H u : ℝ) (hl : 0 < l)
    (h : L ≤ H) (hL : L ≤ u) (hH : u ≤ H)
    (hne : u ≠ clip L H (minimizer b l s q)) :
    objective b l s q (clip L H (minimizer b l s q)) < objective b l s q u := by
  have hlt := mul_lt_mul_of_pos_left (clip_strict h hL hH hne)
    (add_pos_of_nonneg_of_pos (sq_nonneg b) hl)
  linarith only [hlt,square_completion b l s q u hl,
    square_completion b l s q (clip L H (minimizer b l s q)) hl]

theorem projection_loss (h b l s q L H : ℝ) (hl : 0 < l) :
    h^2*(objective b l s q (clip L H (minimizer b l s q)) -
       objective b l s q (minimizer b l s q)) =
      h^2*(b^2+l)*|clip L H (minimizer b l s q)-minimizer b l s q|^2 := by
  rw [square_completion _ _ _ _ _ hl,sq_abs]
  ring

theorem interval_empty_iff (L H : ℝ) : Set.Icc L H = ∅ ↔ H<L := by
  rw [Set.Icc_eq_empty_iff,not_le]

theorem projection_distance {L H : ℝ} (h : L ≤ H) (v : ℝ) :
    Metric.infDist v (Set.Icc L H) = |clip L H v-v| := by
  have hc : clip L H v ∈ Set.Icc L H := clip_feasible h v
  apply le_antisymm
  · have he := Metric.infDist_le_dist_of_mem (x := v) hc
    simpa only [Real.dist_eq,abs_sub_comm v] using he
  · apply (Metric.le_infDist ⟨clip L H v,hc⟩).2
    intro y hy
    rw [Real.dist_eq,abs_sub_comm v y]
    by_cases he : y=clip L H v
    · rw [he]
    · apply (sq_le_sq₀ (abs_nonneg _) (abs_nonneg _)).mp
      simpa only [sq_abs] using (clip_strict h hy.1 hy.2 he).le

theorem projection_metric_loss (h b l s q L H : ℝ) (hl : 0 < l) (hh : L ≤ H) :
    h^2*(objective b l s q (clip L H (minimizer b l s q)) -
       objective b l s q (minimizer b l s q)) =
      h^2*(b^2+l)*(Metric.infDist (minimizer b l s q) (Set.Icc L H))^2 := by
  rw [projection_distance hh]
  exact projection_loss _ _ _ _ _ _ _ hl

section RegularRegion

variable {E : Type*} [AddCommGroup E] [Module ℝ E]
variable {ι : Type*} [Fintype ι]

/-- Quadratic form evaluated with its symmetric bilinear Hessian. -/
def qp (H : E →ₗ[ℝ] E →ₗ[ℝ] ℝ) (q : E →ₗ[ℝ] ℝ) (z : E) : ℝ :=
  (1/2:ℝ)*H z z + q z

theorem psd_zero {H : E →ₗ[ℝ] E →ₗ[ℝ] ℝ}
    (hsym : ∀ x y, H x y = H y x) (hpsd : ∀ x, 0 ≤ H x x)
    {v : E} (hv : H v v = 0) (w : E) : H v w = 0 := by
  by_contra h
  let t : ℝ := -(H w w+1)/(2*H v w)
  have ht : 2*H v w*t = -(H w w+1) := by
    dsimp [t]
    field_simp
  have htst := hpsd (w+t • v)
  simp only [map_add,map_smul,LinearMap.add_apply,LinearMap.smul_apply,smul_eq_mul,
    hv,hsym w v] at htst
  linarith

theorem qp_gap {H : E →ₗ[ℝ] E →ₗ[ℝ] ℝ} {q : E →ₗ[ℝ] ℝ}
    {G : ι → E →ₗ[ℝ] ℝ} {μ : ι → ℝ} {z : E}
    (hsym : ∀ x y, H x y = H y x)
    (stat : ∀ w, H z w + q w + ∑ i, μ i * G i w = 0) (v : E) :
    qp H q (z+v)-qp H q z = (1/2:ℝ)*H v v + ∑ i, μ i * (-G i v) := by
  have negsum : (∑ i, μ i * (-G i v)) = -(∑ i, μ i*G i v) := by
    simp only [mul_neg,Finset.sum_neg_distrib]
  unfold qp
  simp only [map_add,LinearMap.add_apply,hsym v z]
  rw [negsum]
  linarith only [stat v]

theorem qp_optimal {H : E →ₗ[ℝ] E →ₗ[ℝ] ℝ} {q : E →ₗ[ℝ] ℝ}
    {G : ι → E →ₗ[ℝ] ℝ} {μ : ι → ℝ} {z : E}
    (hsym : ∀ x y, H x y = H y x) (hpsd : ∀ x, 0 ≤ H x x)
    (stat : ∀ w, H z w + q w + ∑ i, μ i*G i w = 0)
    (hμ : ∀ i, 0 ≤ μ i) {x : E} (hfeas : ∀ i, G i x ≤ G i z) :
    qp H q z ≤ qp H q x := by
  have hv (i : ι) : 0 ≤ -(G i (x-z)) := by rw [map_sub]; linarith only [hfeas i]
  have hs := sum_nonneg (s := (univ : Finset ι))
    (fun i _ => mul_nonneg (hμ i) (hv i))
  have h := qp_gap hsym stat (x-z)
  rw [show z+(x-z)=x by abel] at h
  linarith only [h,hpsd (x-z),hs]

/-- Injectivity of the regular KKT block on primal displacements.
This follows below from the given inverse of the whole block. -/
theorem qp_unique {H : E →ₗ[ℝ] E →ₗ[ℝ] ℝ} {q : E →ₗ[ℝ] ℝ}
    {G : ι → E →ₗ[ℝ] ℝ} {μ : ι → ℝ} {z : E}
    (hsym : ∀ x y, H x y = H y x) (hpsd : ∀ x, 0 ≤ H x x)
    (stat : ∀ w, H z w + q w + ∑ i, μ i*G i w = 0)
    (hμ : ∀ i, 0 < μ i)
    (kernel : ∀ d, (∀ w, H d w=0) → (∀ i, G i d=0) → d=0)
    {x : E} (hfeas : ∀ i, G i x ≤ G i z) (hcost : qp H q x ≤ qp H q z) : x=z := by
  let d := x-z
  have hd (i : ι) : 0 ≤ -(G i d) := by
    dsimp [d]; rw [map_sub]; linarith only [hfeas i]
  have hp (i : ι) : 0 ≤ μ i * (-G i d) := mul_nonneg (hμ i).le (hd i)
  have hs := sum_nonneg (s := (univ : Finset ι)) (fun i _ => hp i)
  have hgap := qp_gap hsym stat d
  have hxd : z+d=x := by dsimp [d]; abel
  rw [hxd] at hgap
  have hH : H d d = 0 := by linarith only [hgap,hs,hcost,hpsd d]
  have hS : (∑ i, μ i*(-G i d)) ≤ 0 := by linarith only [hgap,hcost,hpsd d]
  have hG (i : ι) : G i d = 0 := by
    have hle : μ i*(-G i d) ≤ ∑ j, μ j*(-G j d) :=
      single_le_sum (fun j _ => hp j) (mem_univ i)
    by_contra hh
    have hneg : 0 < -(G i d) := lt_of_le_of_ne (hd i) (by intro eq; apply hh; linarith)
    linarith only [hle,hS,mul_pos (hμ i) hneg]
  exact sub_eq_zero.mp (kernel d (psd_zero hsym hpsd hH) hG)

/-- Equation (76). With the usual identification of Euclidean primal and dual
coordinates, the invertible KKT matrix acts between these two product spaces. -/
def kktCandidate (K : (E × (ι → ℝ)) ≃ₗ[ℝ] ((E →ₗ[ℝ] ℝ) × (ι → ℝ)))
    (q : E →ₗ[ℝ] ℝ) (b : ι → ℝ) : E × (ι → ℝ) := K.symm (-q,b)

theorem regular_kkt (K : (E × (ι → ℝ)) ≃ₗ[ℝ] ((E →ₗ[ℝ] ℝ) × (ι → ℝ)))
    (H : E →ₗ[ℝ] E →ₗ[ℝ] ℝ) (G : ι → E →ₗ[ℝ] ℝ)
    (upper : ∀ (d : E) (v : ι → ℝ) (w : E), (K (d,v)).1 w =
      H d w + ∑ i, v i * G i w)
    (lower : ∀ (d : E) (v : ι → ℝ) (i : ι), (K (d,v)).2 i = G i d)
    (hsym : ∀ x y, H x y = H y x) (hpsd : ∀ x, 0 ≤ H x x)
    (q : E →ₗ[ℝ] ℝ) (b : ι → ℝ) :
    let c := kktCandidate K q b
    (∀ i, G i c.1 = b i) ∧
      ((∀ i, 0 ≤ c.2 i) → ∀ x, (∀ i, G i x ≤ b i) → qp H q c.1 ≤ qp H q x) ∧
      ((∀ i, 0 < c.2 i) → ∀ x, (∀ i, G i x ≤ b i) → qp H q x ≤ qp H q c.1 → x=c.1) := by
  let c := kktCandidate K q b
  change (∀ i, G i c.1 = b i) ∧ _
  have hk : K c = (-q,b) := K.apply_symm_apply _
  have hstat (w : E) : H c.1 w+q w+∑ i, c.2 i*G i w=0 := by
    have eq := congrArg (fun pair : (E →ₗ[ℝ] ℝ) × (ι → ℝ) => pair.1 w) hk
    change (K (c.1,c.2)).1 w = -q w at eq
    rw [upper] at eq
    linarith
  have hb (i : ι) : G i c.1=b i := by
    have eq := congrArg (fun pair : (E →ₗ[ℝ] ℝ) × (ι → ℝ) => pair.2 i) hk
    change (K (c.1,c.2)).2 i=b i at eq
    rwa [lower] at eq
  have hker (v : E) (hv : ∀ w, H v w=0) (hg : ∀ i, G i v=0) : v=0 := by
    have hk0 : K (v,0) = 0 := by
      apply Prod.ext
      · ext w
        change (K (v,0)).1 w=0
        simp [upper,hv]
      · funext i
        change (K (v,0)).2 i=0
        rw [lower,hg]
    have eq := K.injective (hk0.trans K.map_zero.symm)
    exact congrArg Prod.fst eq
  refine ⟨hb,?_,?_⟩
  · intro hm x hx
    exact qp_optimal hsym hpsd hstat hm (fun i => (hx i).trans_eq (hb i).symm)
  · intro hm x hx hh
    exact qp_unique hsym hpsd hstat hm hker (fun i => (hx i).trans_eq (hb i).symm) hh

omit [Fintype ι] in
theorem kkt_affine {P : Type*} [AddCommGroup P] [Module ℝ P]
    (K : (E × (ι → ℝ)) ≃ₗ[ℝ] ((E →ₗ[ℝ] ℝ) × (ι → ℝ)))
    (r₀ : (E →ₗ[ℝ] ℝ) × (ι → ℝ)) (R : P →ₗ[ℝ] ((E →ₗ[ℝ] ℝ) × (ι → ℝ))) (x : P) :
    K.symm (r₀+R x) = K.symm r₀ + (K.symm.toLinearMap.comp R) x := by
  simp

end RegularRegion

/-- The unit-step example following (72), including the empty next feasible interval. -/
theorem overshoot_and_infeasibility :
    let u₀ := minimizer 1 (1/10) (1/4) 1
    let u₁ := minimizer 1 (1/10) (1/4) (1-(1/2)*u₀-u₀)
    u₀=41/44 ∧ u₁ = -41/121 ∧ (1/2)*u₀+u₁+u₀=1025/968 ∧
    (1:ℝ)<1025/968 ∧ ∀ u : ℝ, 0 ≤ u → 1 < (1/2)*u₀+u+u₀ := by
  norm_num [minimizer]
  intro u hu
  linarith

/-- Equivalence of the absolute-value epigraph inequalities. -/
theorem epigraph_abs (s p : ℝ) : s ≤ p ∧ -s ≤ p ↔ |s| ≤ p := by
  rw [abs_le]; constructor <;> rintro ⟨h₁,h₂⟩ <;> exact ⟨by linarith,by linarith⟩

theorem epigraph_no_slack {ι : Type*} [Fintype ι] (p v : ι → ℝ)
    (h : ∀ i, |v i| ≤ p i) (eq : ∑ i, p i = ∑ i, |v i|) :
    ∀ i, p i = |v i| := by
  classical
  intro i
  have pos (j : ι) : 0 ≤ p j-|v j| := sub_nonneg.mpr (h j)
  have lt := single_le_sum (s := (univ : Finset ι)) (fun j _ => pos j) (mem_univ i)
  rw [sum_sub_distrib,eq,sub_self] at lt
  linarith only [lt,h i]

/-- Tightening both families of epigraph variables preserves feasibility and
improves every spurious optimum. The two finite index sets can differ. -/
theorem exact_epigraph {I J : Type*} [Fintype I] [Fintype J]
    (a p : I → ℝ) (b q : J → ℝ) {l : ℝ} (hl : 0 < l)
    (hp : ∀ i, |a i| ≤ p i) (hq : ∀ j, |b j| ≤ q j) :
    (cost l (∑ i, p i) (∑ j, q j) ≤ cost l (∑ i, |a i|) (∑ j, |b j|)) ↔
       (∀ i, p i=|a i|) ∧ (∀ j, q j=|b j|) := by
  constructor
  · intro h
    have ha : ∑ i, |a i| ≤ ∑ i, p i := sum_le_sum fun i _ => hp i
    have hb : ∑ j, |b j| ≤ ∑ j, q j := sum_le_sum fun j _ => hq j
    have hn : ¬ ((∑ i, |a i|)<∑ i, p i ∨ (∑ j, |b j|)<∑ j, q j) := by
      intro hbad
      exact (not_lt_of_ge h) (pareto_efficient hl
        (sum_nonneg fun i _ => abs_nonneg (a i)) (sum_nonneg fun j _ => abs_nonneg (b j)) ha hb hbad)
    have he : (∑ i, p i)=∑ i, |a i| := le_antisymm (le_of_not_gt fun hh => hn (.inl hh)) ha
    have hf : (∑ j, q j)=∑ j, |b j| := le_antisymm (le_of_not_gt fun hh => hn (.inr hh)) hb
    exact ⟨epigraph_no_slack _ _ hp he,epigraph_no_slack _ _ hq hf⟩
  · rintro ⟨heu,hev⟩
    simp only [heu,hev,le_refl]

/-- The Hessian of two squared linear areas has image in the span of their
two coefficient vectors, including when the vectors are dependent. -/
theorem two_area_rank {E : Type*} [AddCommGroup E] [Module ℝ E]
    (A B : E →ₗ[ℝ] ℝ) (l : ℝ) (H : E →ₗ[ℝ] (E →ₗ[ℝ] ℝ))
    (h : ∀ x, H x = (2*A x) • A + (2*l*B x) • B) :
    Module.finrank ℝ (LinearMap.range H) ≤ 2 := by
  classical
  let s : Finset (E →ₗ[ℝ] ℝ) := {A,B}
  have hmem (x : E) : H x ∈ Submodule.span ℝ (↑s : Set (E →ₗ[ℝ] ℝ)) := by
    rw [h]
    apply Submodule.add_mem
    · apply Submodule.smul_mem; apply Submodule.subset_span; simp [s]
    · apply Submodule.smul_mem; apply Submodule.subset_span; simp [s]
  have hr : LinearMap.range H ≤ Submodule.span ℝ (↑s : Set (E →ₗ[ℝ] ℝ)) := by
    rintro v ⟨x,rfl⟩; exact hmem x
  refine (Submodule.finrank_mono hr).trans ((finrank_span_finset_le_card s).trans ?_)
  dsimp [s]
  exact (Finset.card_insert_le A {B}).trans (by simp)

theorem convex_area_cost {l t : ℝ} (hl : 0 ≤ l) (ht : 0 ≤ t) (ht' : t ≤ 1)
    (a b c d : ℝ) :
    cost l (t*a+(1-t)*c) (t*b+(1-t)*d) ≤ t*cost l a b+(1-t)*cost l c d := by
  have hdiff : t*cost l a b+(1-t)*cost l c d -
      cost l (t*a+(1-t)*c) (t*b+(1-t)*d) = t*(1-t)*cost l (a-c) (b-d) := by
    unfold cost; ring
  have hpos := mul_nonneg (mul_nonneg ht (sub_nonneg.mpr ht'))
    (add_nonneg (sq_nonneg (a-c)) (mul_nonneg hl (sq_nonneg (b-d))))
  exact sub_nonneg.mp (hdiff ▸ hpos)

def areaHessian {E : Type*} [AddCommGroup E] [Module ℝ E]
    (A B : E →ₗ[ℝ] ℝ) (l : ℝ) : E →ₗ[ℝ] (E →ₗ[ℝ] ℝ) :=
  2 • A.smulRight A + (2*l) • B.smulRight B

theorem area_hessian_coefficients {E : Type*} [AddCommGroup E] [Module ℝ E]
    (A B : E →ₗ[ℝ] ℝ) (l : ℝ) (x : E) :
    areaHessian A B l x = (2*A x) • A+(2*l*B x) • B := by
  ext y
  simp [areaHessian,smul_eq_mul]
  ring

theorem second_difference {E : Type*} [AddCommGroup E] [Module ℝ E]
    (A B : E →ₗ[ℝ] ℝ) (l u v : ℝ) (x y z : E) :
    let F := fun w => cost l (u+A w) (v+B w)
    F (z+x+y)-F (z+x)-F (z+y)+F z = areaHessian A B l x y := by
  rw [area_hessian_coefficients]
  simp [cost,smul_eq_mul]
  ring

theorem area_hessian_rank {E : Type*} [AddCommGroup E] [Module ℝ E]
    (A B : E →ₗ[ℝ] ℝ) (l : ℝ) :
    Module.finrank ℝ (LinearMap.range (areaHessian A B l)) ≤ 2 :=
  two_area_rank A B l _ (area_hessian_coefficients A B l)

end
end MPCPID.Predictive
