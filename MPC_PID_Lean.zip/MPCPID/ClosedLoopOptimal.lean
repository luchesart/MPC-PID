import MPCPID.Integration
import MPCPID.PhysicalOptimal
import MPCPID.OneStepBridge

/-! A computationally specified positional controller attains the global
bound. Its closed loop is built by recursion, including its initial memory. -/
namespace MPCPID.ClosedLoopOptimal
noncomputable section
open Conditioned PhysicalOptimal

structure Gains where
  K : ℝ
  κ : ℝ
  d : ℝ
  g : ℝ
  b : ℝ
  c : ℝ
  α : ℝ

structure State where
  y : ℝ
  oldY : ℝ
  oldU : ℝ
  oldR : ℝ
  integral : ℝ
  diff : ℝ

def rest : State := ⟨0,0,0,0,0,0⟩

namespace Gains
variable (G : Gains)

def I (s : State) (r : ℝ) := s.integral + G.κ*G.g*(r-s.y) + G.κ*(1-G.g)*(s.oldR-s.oldY)
def D (s : State) (r : ℝ) := G.α*s.diff + G.d*(G.c*r-s.y-G.c*s.oldR+s.oldY)
def U (s : State) (r : ℝ) := G.K*(G.b*r-s.y)+G.I s r+G.D s r
def tick (P : Optimal.Model) (r : ℝ) (s : State) : State :=
  ⟨P.a*s.y+P.b*G.U s r+P.c*s.oldU,s.y,G.U s r,r,G.I s r,G.D s r⟩
def run (P : Optimal.Model) (r : ℝ) : ℕ → State
  | 0 => rest
  | k+1 => G.tick P r (run P r k)

def y (P : Optimal.Model) (r : ℝ) (k : ℕ) := (G.run P r k).y
def u (P : Optimal.Model) (r : ℝ) (k : ℕ) := G.U (G.run P r k) r

theorem oldU_eq (P : Optimal.Model) (r : ℝ) (k : ℕ) :
    (G.run P r k).oldU = lag (G.u P r) k := by
  cases k <;> rfl

theorem plant_eq (P : Optimal.Model) (r : ℝ) (k : ℕ) :
    G.y P r (k+1) = P.a*G.y P r k+P.b*G.u P r k+P.c*lag (G.u P r) k := by
  change P.a*(G.run P r k).y+P.b*G.u P r k+P.c*(G.run P r k).oldU = _
  rw [G.oldU_eq]; rfl

theorem first_move (P : Optimal.Model) (r : ℝ)
    (hα : G.α ≠ 1)
    (hpole : G.α= -Predictive.zeta P.b P.c P.l*P.c)
    (ht : Predictive.memoryGain P.b P.c P.l+Predictive.zeta P.b P.c P.l*(P.b+P.c)=1)
    (hfit : Matching.channels G.α (Matching.realization G.K G.κ G.d G.g G.b G.c) =
      Matching.target G.α P.a (Predictive.fy P.a P.b P.l)
      (Predictive.zeta P.b P.c P.l) (Predictive.eta P.a P.b P.c P.l)) (j : ℕ) :
    G.u P r j = Predictive.eta P.a P.b P.c P.l*r-Predictive.fy P.a P.b P.l*G.y P r j+
      Predictive.memoryGain P.b P.c P.l*lag (G.u P r) j := by
  let i : Signal := fun k => G.I (G.run P r k) r
  let df : Signal := fun k => G.D (G.run P r k) r
  apply Integration.nominal_physical_mpc hα hpole ht hfit (fun _ => r) (G.y P r)
    (G.u P r) i df _ _ _ _ j
  · intro k
    cases k with
    | zero => simp [y,run,rest,lag]
    | succ k => exact G.plant_eq P r k
  · intro k; rfl
  · intro k; cases k <;> rfl
  · intro k; cases k <;> rfl

end Gains

/-- Positive physical gains and time constants, plus the realized value and the
comparison against every infinite command sequence satisfying the plant. -/
theorem exists_realized_optimum (P : Optimal.Model) {h μ : ℝ} (hh : 0 < h) (hμ : 0 < μ)
    (hpos : max 0 (P.c^2-P.b^2) < P.l)
    (htune : P.l=P.b*μ*(1-P.a)/P.s) (hmono : P.b*P.c ≤ P.a*P.l) :
    ∃ G : Gains, 0 < G.K ∧ 0 < G.κ ∧ 0 < G.d ∧ G.g ∈ Set.Icc 0 1 ∧
      G.b ∈ Set.Icc 0 1 ∧ G.c ∈ Set.Icc 0 1 ∧ -1 < G.α ∧ G.α < 1 ∧
      (∃ Ti Td Tf : ℝ, 0<Ti ∧ 0<Td ∧ 0<Tf ∧
        G.K*h/Ti=G.κ ∧ 1-h/Tf=G.α ∧ G.K*Td/Tf=G.d) ∧
      ∀ step : ℝ,
        (Optimal.Model.cost h μ (actualError step (G.y P step)) (actualExcess P step (G.u P step)) =
          P.barrier h step / Real.sqrt ((1-P.a)^2+P.s^2/μ)) ∧
        ∀ (otherU otherY : Signal), otherY 0=0 →
          (∀ k, otherY (k+1)=P.a*otherY k+P.b*otherU k+P.c*lag otherU k) →
          Optimal.Model.extendedCost h μ (actualError step (G.y P step)) (actualExcess P step (G.u P step)) ≤
            Optimal.Model.extendedCost h μ (actualError step otherY) (actualExcess P step otherU) := by
  obtain ⟨hα,fit,_⟩ := OneStepBridge.one_step_matched_trajectories
    P.a P.b P.c P.l P.ha P.ha1 P.hb P.hc hpos
  obtain ⟨K,κ,d,g,b,c,hK,hκ,hd,hg,hb,hc,hfit⟩ := fit
  let α := -Predictive.zeta P.b P.c P.l*P.c
  let G : Gains := ⟨K,κ,d,g,b,c,α⟩
  have hα' : α < 1 := hα.2
  have hT := Matching.physical_parameters (K := K) (k := κ) (d := d) (h := h)
    (α := α) (gD := 0) hK hκ hd hh hα' (one_div_pos.mpr (sub_pos.mpr hα'))
  refine ⟨G,hK,hκ,hd,hg,hb,hc,hα.1,hα.2,?_,?_⟩
  · refine ⟨K*h/κ,d*h/(K*(1-α)),h*(1/(1-α)-0),?_⟩
    simpa [G] using hT
  · intro step
    have ht := (Predictive.equilibrium_gains P.a P.b P.c P.l P.hb P.hc P.hl).2
    have hsum : Predictive.memoryGain P.b P.c P.l+Predictive.zeta P.b P.c P.l*(P.b+P.c)=1 := by
      rw [ht]
      field_simp [ne_of_gt (add_pos P.hb P.hc)]
    have law := G.first_move P step (ne_of_lt hα') rfl hsum hfit
    have init : G.y P step 0 = 0 := rfl
    refine ⟨applied_exact_value P hh.le hμ htune hmono _ _ init (G.plant_eq P step) law,?_⟩
    intro otherU otherY otherInitial otherPlant
    exact applied_global_optimal P hh.le hμ htune hmono _ _ init (G.plant_eq P step) law
      otherU otherY otherInitial otherPlant

end
end MPCPID.ClosedLoopOptimal
