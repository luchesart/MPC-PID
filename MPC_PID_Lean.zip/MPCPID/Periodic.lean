import Mathlib.Data.Matrix.Notation
import Mathlib.Tactic.FinCases
import Mathlib.Data.Matrix.ColumnRowPartitioned
import Mathlib.LinearAlgebra.Matrix.Charpoly.Coeff
import Mathlib.Analysis.SpecificLimits.Normed
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.Algebra.MvPolynomial.Eval
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp

/-! # Periodic realization and matching
The matrices in the finite test are the matrices of the lifted difference system (47).
Its vector input consists of all chronological within-frame samples. Finite pasts are
stored newest first in `advance`. A single experiment has one column.
-/

namespace MPCPID.Periodic

open Filter
open scoped BigOperators Topology Polynomial

abbrev Mat (r c : ℕ) := Matrix (Fin r) (Fin c) ℝ

/-- Cayley--Hamilton removes all Markov indices from the test except the first
state-dimension-many indices, also when the state space has dimension zero. -/
theorem finiteMarkov {n m o : ℕ} (A : Mat n n) (B : Mat n m) (C : Mat o n)
    (h : ∀ j < n, C * A ^ j * B = 0) (k : ℕ) : C * A ^ k * B = 0 := by
  classical
  cases n with
  | zero =>
    ext i j
    simp [Matrix.mul_apply]
  | succ n =>
    have hne : A.charpoly ≠ 1 := by
      intro he
      have he' := congrArg Polynomial.natDegree he
      simp at he'
    let r := (Polynomial.X ^ k : Polynomial ℝ) %ₘ A.charpoly
    have hdeg : r.natDegree < n + 1 := by
      simpa [r] using Polynomial.natDegree_modByMonic_lt
        (Polynomial.X ^ k : Polynomial ℝ) A.charpoly_monic hne
    have hpow : A ^ k = ∑ j ∈ Finset.range (n + 1), r.coeff j • A ^ j := by
      calc
        A ^ k = Polynomial.aeval A r := A.pow_eq_aeval_mod_charpoly k
        _ = _ := Polynomial.aeval_eq_sum_range' hdeg A
    rw [hpow, Matrix.mul_sum, Matrix.sum_mul]
    apply Finset.sum_eq_zero
    intro j hj
    rw [Matrix.mul_smul, Matrix.smul_mul, h j (Finset.mem_range.mp hj), smul_zero]

/-- State after applying the inputs from the tail of the list towards the head. -/
def advance {n m : ℕ} (A : Mat n n) (B : Mat n m) (x : Mat n 1) :
    List (Mat m 1) → Mat n 1
  | [] => x
  | u :: us => A * advance A B x us + B * u

private def column {n : ℕ} (j : Fin n) : Mat n 1 := fun i _ => if j = i then 1 else 0

private theorem zero_of_columns {n m : ℕ} (M : Mat n m)
    (h : ∀ j : Fin m, M * column j = (0 : Mat n 1)) : M = 0 := by
  classical
  funext i j
  have h' := congrFun (congrFun (h j) i) (0 : Fin 1)
  simpa [Matrix.mul_apply, column] using h'

private theorem after_zeros {n m : ℕ} (A : Mat n n) (B : Mat n m) (x : Mat n 1)
    (us : List (Mat m 1)) (k : ℕ) :
    advance A B x (List.replicate k 0 ++ us) = A ^ k * advance A B x us := by
  induction k with
  | zero => simp
  | succ k ih =>
    simp [List.replicate_succ, advance, ih, pow_succ', Matrix.mul_assoc]

/-- Theorem 5.1. Equations (48) and (49) are necessary and sufficient for zero
output for every actual vector input history and every permitted initial state.
Take G=0 for the zero-state version. -/
theorem finitePeriodicEquality {n m o p : ℕ}
    (A : Mat n n) (B : Mat n m) (C : Mat o n) (D : Mat o m) (G : Mat n p) :
    (∀ (q : Mat p 1) (v : Mat m 1) (us : List (Mat m 1)),
      C * advance A B (G*q) us + D*v = 0) ↔
    D = 0 ∧ (∀ j < n, C * A ^ j * B = 0) ∧ (∀ j < n, C * A ^ j * G = 0) := by
  classical
  constructor
  · intro hall
    refine ⟨?_, ?_, ?_⟩
    · apply zero_of_columns
      intro j
      simpa [advance] using hall 0 (column j) []
    · intro j _
      apply zero_of_columns
      intro b
      have he := hall 0 0 (List.replicate j 0 ++ [column b])
      rw [after_zeros] at he
      simpa [advance, Matrix.mul_assoc] using he
    · intro j _
      apply zero_of_columns
      intro b
      have he := hall (column b) 0 (List.replicate j 0 ++ [])
      rw [after_zeros] at he
      simpa [advance, Matrix.mul_assoc] using he
  · rintro ⟨rfl, hb, hg⟩ q v us
    have hzero (j : ℕ) : C * A^j * advance A B (G*q) us = 0 := by
      induction us generalizing j with
      | nil =>
        change C * A ^ j * (G*q) = 0
        rw [← Matrix.mul_assoc, finiteMarkov A G C hg j, Matrix.zero_mul]
      | cons u us ih =>
        change C * A^j * (A * advance A B (G*q) us + B*u) = 0
        rw [Matrix.mul_add, ← Matrix.mul_assoc _ B u, finiteMarkov A B C hb j,
          Matrix.zero_mul, add_zero, ← Matrix.mul_assoc, Matrix.mul_assoc C,
          ← pow_succ]
        exact ih (j+1)
    simpa using hzero 0

/-- No branch update means the same held command for every new reference.
The target coefficient is the actual feedthrough in the same phase (Prop. 5.3). -/
theorem noUpdateObstruction (p i d offset gain : ℝ) (h : gain ≠ 0) :
    ¬ ∀ r : ℝ, p + i + d = offset + gain * r := by
  intro he
  have hz := he 0
  have ho := he 1
  apply h
  linarith

/-- A schedule samples exactly one residue per period. -/
def atPhase (period phase k : ℕ) : Prop := k % period = phase

theorem phaseCofinal {m φ : ℕ} (hφ : φ < m) (k : ℕ) :
    ∃ j, k ≤ j ∧ atPhase m φ j := by
  refine ⟨k*m+φ, ?_, ?_⟩
  · have hm : 1 ≤ m := by omega
    nlinarith [Nat.mul_le_mul_left k hm]
  · simp [atPhase, Nat.add_mod, Nat.mod_eq_of_lt hφ]

theorem integralHasSkip {m φ : ℕ} (hm : 1 < m) :
    ∃ k, ¬atPhase m φ k := by
  by_cases hh : φ = 0
  · subst φ
    exact ⟨1, by simp [atPhase, Nat.mod_eq_of_lt hm]⟩
  · exact ⟨0, by simpa [atPhase] using Ne.symm hh⟩

/-- Number of events in the next k samples, starting at T. -/
noncomputable def eventCount (fire : ℕ → Prop) (T : ℕ) : ℕ → ℕ
  | 0 => 0
  | k+1 => by classical exact eventCount fire T k + if fire (T+k) then 1 else 0

theorem eventCount_mono (fire : ℕ → Prop) (T : ℕ) : Monotone (eventCount fire T) := by
  classical
  apply monotone_nat_of_le_succ
  intro k
  simp only [eventCount]
  omega

theorem eventCount_tendsto (fire : ℕ → Prop) (T : ℕ)
    (hf : ∀ k, ∃ j, k ≤ j ∧ fire j) :
    Tendsto (eventCount fire T) atTop atTop := by
  classical
  have unbounded (b : ℕ) : ∃ n, b ≤ eventCount fire T n := by
    induction b with
    | zero => exact ⟨0, Nat.zero_le _⟩
    | succ b ih =>
      obtain ⟨n, hn⟩ := ih
      obtain ⟨j, hj, hit⟩ := hf (T+n)
      have he : T + (j-T) = j := by omega
      have hmono := eventCount_mono fire T (show n ≤ j-T by omega)
      exact ⟨j-T+1, by simp only [eventCount, he, if_pos hit]; omega⟩
  apply tendsto_atTop.2
  intro b
  obtain ⟨n, hn⟩ := unbounded b
  filter_upwards [eventually_ge_atTop n] with k hk
  exact hn.trans (eventCount_mono fire T hk)

structure Memory where
  p : ℝ
  i : ℝ
  d : ℝ
  eI : ℝ
  eD : ℝ

def rest : Memory := ⟨0,0,0,0,0⟩

/-- Physical equation (2) at zero reference. e is minus the measurement. -/
noncomputable def update (P I D : Prop) (K b₀ b₁ α β e : ℝ) (x : Memory) : Memory := by
  classical
  exact ⟨if P then K*e else x.p,
    if I then x.i+b₀*e+b₁*x.eI else x.i,
    if D then α*x.d+β*(e-x.eD) else x.d,
    if I then e else x.eI, if D then e else x.eD⟩

noncomputable def memory (P I D : ℕ → Prop) (K b₀ b₁ α β : ℝ) (e : ℕ → ℝ) : ℕ → Memory
  | 0 => rest
  | k+1 => update (P k) (I k) (D k) K b₀ b₁ α β (e k) (memory P I D K b₀ b₁ α β e k)

/-- The unit output-measurement impulse seen as a negative error. -/
def impulse (s k : ℕ) : ℝ := if k = s then -1 else 0

/-- Proposition 5.4, in the stronger form where P and D may have arbitrary
unbounded event streams. The output is taken just after update k. -/
theorem skippedImpulseTendsToZero (P I D : ℕ → Prop) (K b₀ b₁ α β : ℝ) (s : ℕ)
    (hs : ¬ I s) (hα : |α| < 1) (hp : ∀ k, ∃ j, k ≤ j ∧ P j)
    (hd : ∀ k, ∃ j, k ≤ j ∧ D j) :
    let x := memory P I D K b₀ b₁ α β (impulse s)
    Tendsto (fun k => (x (k+1)).p + (x (k+1)).i + (x (k+1)).d) atTop (𝓝 0) := by
  classical
  let x := memory P I D K b₀ b₁ α β (impulse s)
  change Tendsto (fun k => (x (k+1)).p + (x (k+1)).i + (x (k+1)).d) atTop (𝓝 0)
  have hI (k : ℕ) : (x k).i = 0 ∧ (x k).eI = 0 := by
    induction k with
    | zero => exact ⟨rfl,rfl⟩
    | succ k ih =>
      change (update _ _ _ _ _ _ _ _ _ (x k)).i = 0 ∧
        (update _ _ _ _ _ _ _ _ _ (x k)).eI = 0
      by_cases hi : I k
      · have hks : k ≠ s := fun h => hs (h ▸ hi)
        simp [update, hi, impulse, hks, ih]
      · simp [update, hi, ih]
  obtain ⟨j, hj, hpj⟩ := hp (s+1)
  obtain ⟨l, hl, hdl⟩ := hd (s+1)
  have hP (k : ℕ) (hk : j+1 ≤ k) : (x k).p = 0 := by
    induction k, hk using Nat.le_induction with
    | base => simp [x, memory, update, hpj, impulse, show j ≠ s by omega]
    | succ n hn ih =>
      change (update _ _ _ _ _ _ _ _ _ (x n)).p = 0
      simp [update, impulse, show n ≠ s by omega, ih]
  have hD (k : ℕ) (hk : l+1 ≤ k) : (x k).eD = 0 := by
    induction k, hk using Nat.le_induction with
    | base => simp [x, memory, update, hdl, impulse, show l ≠ s by omega]
    | succ n hn ih =>
      change (update _ _ _ _ _ _ _ _ _ (x n)).eD = 0
      simp [update, impulse, show n ≠ s by omega, ih]
  let T := max (j+1) (l+1)
  have htj : j+1 ≤ T := le_max_left _ _
  have htl : l+1 ≤ T := le_max_right _ _
  have closed (k : ℕ) : (x (T+k)).d = α ^ eventCount D T k * (x T).d := by
    induction k with
    | zero => simp [eventCount]
    | succ k ih =>
      change (update _ _ _ _ _ _ _ _ _ (x (T+k))).d = _
      have hmem := hD (T+k) (by omega)
      by_cases hit : D (T+k)
      · simp [update, hit, impulse, show T+k ≠ s by omega, hmem, ih, eventCount,
          pow_succ]; ring
      · simp [update, hit, ih, eventCount]
  have hlim := (tendsto_pow_atTop_nhds_zero_of_abs_lt_one hα).comp
    (eventCount_tendsto D T hd)
  have hdlim : Tendsto (fun n => α ^ eventCount D T n * (x T).d) atTop (𝓝 0) := by
    simpa using hlim.mul_const (x T).d
  have hshift : Tendsto (fun n : ℕ => n+1-T) atTop atTop := by
    apply tendsto_atTop.2
    intro b
    filter_upwards [eventually_ge_atTop (T+b)] with n hn
    omega
  apply (hdlim.comp hshift).congr'
  filter_upwards [eventually_ge_atTop T] with n hn
  have he : T+(n+1-T) = n+1 := by omega
  have hcl := closed (n+1-T)
  rw [he] at hcl
  simp [Function.comp_def, hP (n+1) (by omega), (hI (n+1)).1, hcl]

/-- Specialization of Proposition 5.4 to actual phase schedules and a common-rate
target with a nonzero limiting impulse response. -/
theorem integralSamplingObstruction {mP mI mD φP φI φD : ℕ} (K b₀ b₁ α β : ℝ)
    (hP : φP < mP) (hD : φD < mD) (hI : 1 < mI) (hα : |α| < 1)
    (target : ℕ → ℕ → ℝ) (L : ℝ) (hL : L ≠ 0)
    (ht : ∀ s, Tendsto (target s) atTop (𝓝 L)) :
    ¬ ∀ s k, let x := memory (atPhase mP φP) (atPhase mI φI) (atPhase mD φD)
                            K b₀ b₁ α β (impulse s) (k+1)
             x.p+x.i+x.d = target s k := by
  intro he
  obtain ⟨s, hs⟩ := integralHasSkip (φ := φI) hI
  have h := skippedImpulseTendsToZero (atPhase mP φP) (atPhase mI φI) (atPhase mD φD)
    K b₀ b₁ α β s hs hα (phaseCofinal hP) (phaseCofinal hD)
  have hzero : Tendsto (target s) atTop (𝓝 0) :=
    h.congr (fun k => he s k)
  exact hL (tendsto_nhds_unique (ht s) hzero)


/-- All within-frame samples are retained by the bijection between ordinary
sequences and L-vectors of sequences. -/
def frames {V : Type*} (L : ℕ) (hL : 0 < L) : (ℕ → V) ≃ (ℕ → Fin L → V) where
  toFun f k i := f (k*L+i.val)
  invFun f n := f (n/L) ⟨n%L, Nat.mod_lt n hL⟩
  left_inv f := by
    funext n
    change f (n / L * L + n % L) = f n
    rw [Nat.div_add_mod']
  right_inv f := by
    funext k i
    dsimp
    have hd : (k*L+i.val)/L = k := by
      rw [Nat.add_comm, Nat.add_mul_div_right _ _ hL, Nat.div_eq_of_lt i.isLt, Nat.zero_add]
    simp [hd, Nat.add_mod, Nat.mod_eq_of_lt i.isLt]

/-- The physical time-varying state and the two block coefficients in Appendix C.
The forced response is represented as the action on a fixed, arbitrary frame. -/
def frameState {n m : ℕ} (A : ℕ → Mat n n) (B : ℕ → Mat n m)
    (u : ℕ → Mat m 1) (x : Mat n 1) : ℕ → Mat n 1
  | 0 => x
  | k+1 => A k * frameState A B u x k + B k * u k

def transition {n : ℕ} (A : ℕ → Mat n n) : ℕ → Mat n n
  | 0 => 1
  | k+1 => A k * transition A k

theorem frameState_split {n m : ℕ} (A : ℕ → Mat n n) (B : ℕ → Mat n m)
    (u : ℕ → Mat m 1) (x : Mat n 1) (k : ℕ) :
    frameState A B u x k = transition A k * x + frameState A B u 0 k := by
  induction k with
  | zero => simp [frameState, transition]
  | succ k ih =>
    simp only [frameState, transition, ih, Matrix.mul_add, Matrix.mul_assoc, add_assoc]

private theorem norm_lt_one_iff (z : ℂ) : ‖z‖ < 1 ↔ z.re^2 + z.im^2 < 1 := by
  have he := Complex.sq_norm_sub_sq_re z
  have hz := norm_nonneg z
  constructor <;> intro h <;> nlinarith

/-- A finite, existential real-algebraic stability test for a monic polynomial.
The n roots are pairs of real unknowns. Equality of monic products is equality
of the finitely many coefficients, and the disk tests are strict quadratic
inequalities. This alternative avoids introducing periodic Lyapunov matrices. -/
theorem schurRootCertificate (P : Polynomial ℂ) (hP : P.Monic) :
    (∀ z, P.IsRoot z → ‖z‖ < 1) ↔
    ∃ roots : Multiset ℂ, roots.card = P.natDegree ∧
      P = (roots.map (fun z => Polynomial.X - Polynomial.C z)).prod ∧
      ∀ z ∈ roots, z.re^2+z.im^2 < 1 := by
  classical
  constructor
  · intro h
    refine ⟨P.roots, ?_, Polynomial.eq_prod_roots_of_monic_of_splits_id hP
      (IsAlgClosed.splits P), ?_⟩
    · simpa using (Polynomial.natDegree_eq_card_roots (IsAlgClosed.splits P)).symm
    · intro z hz
      exact (norm_lt_one_iff z).mp (h z ((Polynomial.mem_roots hP.ne_zero).mp hz))
  · rintro ⟨roots, _, hp, hin⟩ z hz
    have hm := (Polynomial.mem_roots hP.ne_zero).mpr hz
    rw [hp, Polynomial.roots_multiset_prod_X_sub_C] at hm
    exact (norm_lt_one_iff z).mpr (hin z hm)

/-- The finite Markov checks and the finite root certificate for the monodromy
of the candidate (which may differ from the difference realization) are
conjoined. All conditions on the coefficients can be cleared of denominators
by `rationalFeasibility`. -/
theorem stablePeriodicEquality {n m o p a : ℕ}
    (A : Mat n n) (B : Mat n m) (C : Mat o n) (D : Mat o m) (G : Mat n p)
    (Φ : Matrix (Fin a) (Fin a) ℂ) :
    ((∀ (q : Mat p 1) (v : Mat m 1) (us : List (Mat m 1)),
      C * advance A B (G*q) us + D*v = 0) ∧
      (∀ z, Φ.charpoly.IsRoot z → ‖z‖ < 1)) ↔
    (D = 0 ∧ (∀ j < n, C * A ^ j * B = 0) ∧ (∀ j < n, C * A ^ j * G = 0)) ∧
    ∃ roots : Multiset ℂ, roots.card = a ∧
      Φ.charpoly = (roots.map (fun z => Polynomial.X - Polynomial.C z)).prod ∧
      ∀ z ∈ roots, z.re^2+z.im^2 < 1 := by
  rw [finitePeriodicEquality, schurRootCertificate Φ.charpoly Φ.charpoly_monic]
  simp

/-- A rational entry, in a finite real parameter space; `den` is required to
be nonzero at the parameter under test, including the physical time constants. -/
structure RationalEntry (d : ℕ) where
  num : MvPolynomial (Fin d) ℝ
  den : MvPolynomial (Fin d) ℝ

private theorem clearPositive {a b : ℝ} (_hb : b ≠ 0) : 0 < a/b ↔ 0 < a*b := by
  rw [div_pos_iff, mul_pos_iff]

/-- Finite union over schedules of finite conjunctions of rational equations
and strict inequalities, rewritten as polynomial equations and inequalities.
Nonzero denominators themselves are enforced using strictly positive squares. -/
theorem rationalFeasibility {d S E I : ℕ} (eqs : Fin S → Fin E → RationalEntry d)
    (ineqs : Fin S → Fin I → RationalEntry d) :
    (∃ s x, (∀ i, MvPolynomial.eval x (eqs s i).den ≠ 0 ∧
        MvPolynomial.eval x (eqs s i).num / MvPolynomial.eval x (eqs s i).den = 0) ∧
      ∀ i, MvPolynomial.eval x (ineqs s i).den ≠ 0 ∧
        0 < MvPolynomial.eval x (ineqs s i).num / MvPolynomial.eval x (ineqs s i).den) ↔
    (∃ s x, (∀ i, 0 < MvPolynomial.eval x ((eqs s i).den^2) ∧
        MvPolynomial.eval x (eqs s i).num = 0) ∧
      ∀ i, 0 < MvPolynomial.eval x ((ineqs s i).den^2) ∧
        0 < MvPolynomial.eval x ((ineqs s i).num * (ineqs s i).den)) := by
  simp only [map_pow, map_mul, sq_pos_iff]
  constructor
  · rintro ⟨s,x,he,hi⟩
    refine ⟨s,x,fun i => ⟨(he i).1, ?_⟩, fun i => ⟨(hi i).1, ?_⟩⟩
    · exact (div_eq_zero_iff.mp (he i).2).resolve_right (he i).1
    · exact (clearPositive (hi i).1).mp (hi i).2
  · rintro ⟨s,x,he,hi⟩
    refine ⟨s,x,fun i => ⟨(he i).1, ?_⟩, fun i => ⟨(hi i).1, ?_⟩⟩
    · rw [(he i).2, zero_div]
    · exact (clearPositive (hi i).1).mpr (hi i).2


/-- Introduce just two reciprocal coordinates to make every physical branch
coefficient polynomial in the parameters, on the domain of (4).
The reference weights and the event flags occur only polynomially in (40)--(44). -/
theorem physicalCoefficientGraph
    (K Ti Td Tf TI TD γI γD b₀ b₁ α β : ℝ)
    (hI : Ti ≠ 0) (hD : Tf+γD*TD ≠ 0) :
    (b₀ = K*TI/Ti*γI ∧ b₁ = K*TI/Ti*(1-γI) ∧
      α = 1-TD/(Tf+γD*TD) ∧ β = K*Td/(Tf+γD*TD)) ↔
    ∃ qI qD : ℝ, Ti*qI = 1 ∧ (Tf+γD*TD)*qD = 1 ∧
      b₀ = K*TI*qI*γI ∧ b₁ = K*TI*qI*(1-γI) ∧
      α = 1-TD*qD ∧ β=K*Td*qD := by
  constructor
  · rintro ⟨rfl,rfl,rfl,rfl⟩
    exact ⟨Ti⁻¹,(Tf+γD*TD)⁻¹,by simp [hI], by simp [hD], by simp [div_eq_mul_inv],
      by simp [div_eq_mul_inv], by simp [div_eq_mul_inv], by simp [div_eq_mul_inv]⟩
  · rintro ⟨qI,qD,hi,hd,rfl,rfl,rfl,rfl⟩
    have qi : qI = Ti⁻¹ := by
      field_simp [hI]
      linarith [mul_comm Ti qI]
    have qd : qD = (Tf+γD*TD)⁻¹ := by
      field_simp [hD]
      linarith [mul_comm (Tf+γD*TD) qD]
    simp [qi, qd, div_eq_mul_inv]

/-- Markov products of matrices of polynomials in the augmented physical
parameters are calculated symbolically once; substitution commutes with (48). -/
theorem evaluateMarkov {d n m o : ℕ} (x : Fin d → ℝ)
    (A : Matrix (Fin n) (Fin n) (MvPolynomial (Fin d) ℝ))
    (B : Matrix (Fin n) (Fin m) (MvPolynomial (Fin d) ℝ))
    (C : Matrix (Fin o) (Fin n) (MvPolynomial (Fin d) ℝ)) (j : ℕ) :
    (C*A^j*B).map (MvPolynomial.eval x) =
      C.map (MvPolynomial.eval x) * (A.map (MvPolynomial.eval x))^j *
      B.map (MvPolynomial.eval x) := by
  let e := MvPolynomial.eval x
  have hp : (A^j).map e = (A.map e)^j :=
    map_pow (e.mapMatrix : Matrix (Fin n) (Fin n) _ →+* _) A j
  simp only [Matrix.map_mul]
  rw [hp]

/-- Zero output for the evaluated symbolic periodic system is *equivalent*
to vanishing of a fixed, finite family of evaluated polynomial matrices. -/
theorem polynomialPeriodicEquality {d n m o p : ℕ} (x : Fin d → ℝ)
    (A : Matrix (Fin n) (Fin n) (MvPolynomial (Fin d) ℝ))
    (B : Matrix (Fin n) (Fin m) (MvPolynomial (Fin d) ℝ))
    (C : Matrix (Fin o) (Fin n) (MvPolynomial (Fin d) ℝ))
    (D : Matrix (Fin o) (Fin m) (MvPolynomial (Fin d) ℝ))
    (G : Matrix (Fin n) (Fin p) (MvPolynomial (Fin d) ℝ)) :
    let e := MvPolynomial.eval x
    (∀ (q : Mat p 1) (v : Mat m 1) (us : List (Mat m 1)),
      C.map e * advance (A.map e) (B.map e) (G.map e*q) us + D.map e*v = 0) ↔
    D.map e = 0 ∧ (∀ j < n, (C*A^j*B).map e = 0) ∧
      (∀ j < n, (C*A^j*G).map e = 0) := by
  dsimp only
  simp only [evaluateMarkov]
  exact finitePeriodicEquality _ _ _ _ _


/-- The physical PID at a held phase, with independently varied P/I/D error
arguments; even that freedom leaves its command unchanged. -/
theorem heldPhysicalCommand (x : Memory) (K b₀ b₁ α β e : ℝ) :
    let y := update False False False K b₀ b₁ α β e x
    y.p+y.i+y.d = x.p+x.i+x.d := by
  simp [update]

/-- For the common-rate controller the measurement impulse leaves the
integral residue -(b₀+b₁), independently of the phase of the impulse. -/
theorem commonImpulseLimit (K b₀ b₁ α β : ℝ) (hα : |α| < 1) (s : ℕ) :
    let x := memory (fun _ => True) (fun _ => True) (fun _ => True)
       K b₀ b₁ α β (impulse s)
    Tendsto (fun k => (x (k+1)).p+(x (k+1)).i+(x (k+1)).d) atTop (𝓝 (-(b₀+b₁))) := by
  classical
  let x := memory (fun _ => True) (fun _ => True) (fun _ => True)
       K b₀ b₁ α β (impulse s)
  change Tendsto (fun k => (x (k+1)).p+(x (k+1)).i+(x (k+1)).d) atTop (𝓝 (-(b₀+b₁)))
  have hx (k : ℕ) : x (k+1) = update True True True K b₀ b₁ α β (impulse s k) (x k) := rfl
  have hrest (k : ℕ) (hk : k ≤ s) : x k = rest := by
    induction k with
    | zero => rfl
    | succ k ih =>
      rw [hx, ih (by omega)]
      simp [update, impulse, show k ≠ s by omega, rest]
  have gone : x (s+1) = ⟨-K,-b₀,-β,-1,-1⟩ := by
    rw [hx, hrest s le_rfl]
    simp [update, impulse, rest]
  have tail (k : ℕ) :
      x (s+2+k) = ⟨0,-(b₀+b₁),α^k*((1-α)*β),0,0⟩ := by
    induction k with
    | zero =>
      rw [Nat.add_zero, show s+2 = (s+1)+1 by omega, hx, gone]
      simp [update, impulse, show s+1 ≠ s by omega]; constructor <;> ring
    | succ k ih =>
      rw [show s+2+(k+1) = (s+2+k)+1 by omega, hx, ih]
      simp [update, impulse, show s+2+k ≠ s by omega, pow_succ]; ring
  have hshift : Tendsto (fun k : ℕ => k-(s+1)) atTop atTop := by
    apply tendsto_atTop.2
    intro b
    filter_upwards [eventually_ge_atTop (s+1+b)] with k hk
    omega
  have hlim : Tendsto (fun k => -(b₀+b₁)+α^k*((1-α)*β)) atTop (𝓝 (-(b₀+b₁))) := by
    have h0 := (tendsto_pow_atTop_nhds_zero_of_abs_lt_one hα).mul_const ((1-α)*β)
    simpa using tendsto_const_nhds.add h0
  apply (hlim.comp hshift).congr'
  filter_upwards [eventually_ge_atTop (s+1)] with k hk
  have he : s+2+(k-(s+1)) = k+1 := by omega
  have ht := tail (k-(s+1))
  rw [he] at ht
  simp [ht]


private theorem enumerateRoots {a : ℕ} (r : Multiset ℂ) (hc : r.card = a) :
    ∃ ρ : Fin a → ℂ, Finset.univ.val.map ρ = r := by
  classical
  have hl : a = r.toList.length := by simpa using hc.symm
  clear hc
  subst a
  refine ⟨r.toList.get, ?_⟩
  rw [Fin.univ_val_map, List.ofFn_get, Multiset.coe_toList]

/-- The coefficients of the polynomial with formal roots X_0,...,X_(a-1).
They are universal polynomials used by the stability part of the test. -/
noncomputable def rootPolynomial (a : ℕ) : Polynomial (MvPolynomial (Fin a) ℂ) :=
  ∏ i : Fin a, (Polynomial.X - Polynomial.C (MvPolynomial.X i))

private theorem evaluateRoots (a : ℕ) (ρ : Fin a → ℂ) :
    (rootPolynomial a).map (MvPolynomial.eval ρ) = ∏ i : Fin a, (Polynomial.X - Polynomial.C (ρ i)) := by
  simp [rootPolynomial, Polynomial.map_prod]

/-- The stability certificate uses exactly a pairs of real root coordinates
and a+1 polynomial coefficient equations. No condition on all complex z
or on all polynomial coefficients is left on the right-hand side. -/
theorem polynomialSchur {a d : ℕ} (x : Fin d → ℝ)
    (Φ : Matrix (Fin a) (Fin a) (MvPolynomial (Fin d) ℝ)) :
    let e := Complex.ofRealHom.comp (MvPolynomial.eval x)
    (∀ z, (Φ.map e).charpoly.IsRoot z → ‖z‖ < 1) ↔
    ∃ ρ : Fin a → ℂ,
      (∀ j ≤ a, ((MvPolynomial.eval x (Φ.charpoly.coeff j) : ℝ) : ℂ) =
        MvPolynomial.eval ρ ((rootPolynomial a).coeff j)) ∧
      ∀ i, (ρ i).re^2 + (ρ i).im^2 < 1 := by
  classical
  let e := Complex.ofRealHom.comp (MvPolynomial.eval x)
  let P := (Φ.map e).charpoly
  change (∀ z, P.IsRoot z → ‖z‖ < 1) ↔ _
  have hdeg : P.natDegree = a := by simp [P]
  have hcoeff (j : ℕ) : P.coeff j = ((MvPolynomial.eval x (Φ.charpoly.coeff j) : ℝ) : ℂ) := by
    simp [P, Matrix.charpoly_map, e]
  have hroot (ρ : Fin a → ℂ) (j : ℕ) :
      MvPolynomial.eval ρ ((rootPolynomial a).coeff j) =
        (∏ i : Fin a, (Polynomial.X - Polynomial.C (ρ i))).coeff j := by
    rw [← evaluateRoots, Polynomial.coeff_map]
  constructor
  · intro h
    obtain ⟨r,hc,hp,hd⟩ := (schurRootCertificate P (Φ.map e).charpoly_monic).mp h
    rw [hdeg] at hc
    obtain ⟨ρ,hen⟩ := enumerateRoots r hc
    refine ⟨ρ, ?_, ?_⟩
    · have heq : P = ∏ i : Fin a, (Polynomial.X - Polynomial.C (ρ i)) := by
        rw [hp, ← hen, Multiset.map_map]
        rfl
      intro j _
      rw [← hcoeff, hroot, heq]
    · intro i
      apply hd
      rw [← hen]
      exact Multiset.mem_map.mpr ⟨i, Finset.mem_univ i, rfl⟩
  · rintro ⟨ρ,hj,hd⟩
    have heq : P = ∏ i : Fin a, (Polynomial.X - Polynomial.C (ρ i)) := by
      apply Polynomial.ext
      intro j
      by_cases hj' : j ≤ a
      · rw [hcoeff, hj j hj', hroot]
      · have hQ : (∏ i : Fin a, (Polynomial.X - Polynomial.C (ρ i))).natDegree = a := by simp
        rw [Polynomial.coeff_eq_zero_of_natDegree_lt (hdeg.trans_lt (lt_of_not_ge hj')),
          Polynomial.coeff_eq_zero_of_natDegree_lt (hQ.trans_lt (lt_of_not_ge hj'))]
    intro z hz
    rw [heq, Polynomial.isRoot_prod] at hz
    obtain ⟨i,_,hr⟩ := hz
    have hei : z = ρ i := by simpa [Polynomial.IsRoot, sub_eq_zero] using hr
    exact (norm_lt_one_iff z).mpr (hei ▸ hd i)

/-- Corollary 5.2 for a finite schedule family. The symbolic lift (including
any initially compatible states G) and candidate monodromy may have different
dimensions. `positive` encodes strict physical bounds and the additional
reciprocal-coordinate equations of `physicalCoefficientGraph` are included
in `equal`. Weak inequalities may use square witnesses. Root coordinates are
real pairs, so complex polynomial equality is two real polynomial equations. -/
theorem fixedScheduleFeasibility {S d n m o p a ne ni : ℕ}
    (A : Fin S → Matrix (Fin n) (Fin n) (MvPolynomial (Fin d) ℝ))
    (B : Fin S → Matrix (Fin n) (Fin m) (MvPolynomial (Fin d) ℝ))
    (C : Fin S → Matrix (Fin o) (Fin n) (MvPolynomial (Fin d) ℝ))
    (D : Fin S → Matrix (Fin o) (Fin m) (MvPolynomial (Fin d) ℝ))
    (G : Fin S → Matrix (Fin n) (Fin p) (MvPolynomial (Fin d) ℝ))
    (Φ : Fin S → Matrix (Fin a) (Fin a) (MvPolynomial (Fin d) ℝ))
    (equal : Fin S → Fin ne → MvPolynomial (Fin d) ℝ)
    (positive : Fin S → Fin ni → MvPolynomial (Fin d) ℝ) :
    (∃ s x, let e := MvPolynomial.eval x
      (∀ i, e (equal s i) = 0) ∧ (∀ i, 0 < e (positive s i)) ∧
      (∀ (q : Mat p 1) (v : Mat m 1) (us : List (Mat m 1)),
        (C s).map e * advance ((A s).map e) ((B s).map e) ((G s).map e*q) us +
          (D s).map e*v = 0) ∧
      (∀ z, ((Φ s).map (Complex.ofRealHom.comp e)).charpoly.IsRoot z → ‖z‖ < 1)) ↔
    (∃ s x, let e := MvPolynomial.eval x
      (∀ i, e (equal s i) = 0) ∧ (∀ i, 0 < e (positive s i)) ∧
      ((D s).map e = 0 ∧ (∀ j < n, (C s * A s^j * B s).map e = 0) ∧
        (∀ j < n, (C s * A s^j * G s).map e = 0)) ∧
      ∃ ρ : Fin a → ℂ, (∀ j ≤ a, ((e ((Φ s).charpoly.coeff j) : ℝ) : ℂ) =
          MvPolynomial.eval ρ ((rootPolynomial a).coeff j)) ∧
        ∀ i, (ρ i).re^2+(ρ i).im^2 < 1) := by
  apply exists_congr
  intro s
  apply exists_congr
  intro x
  dsimp only
  exact and_congr Iff.rfl (and_congr Iff.rfl (and_congr
    (polynomialPeriodicEquality x (A s) (B s) (C s) (D s) (G s))
    (polynomialSchur x (Φ s))))


/-- Polynomial matrix recursions for all lifted coefficients (Appendix C).
S picks the input at the current phase from a block of inputs; the formulas
work for arbitrary linear selectors, including restrictions on reference data. -/
def liftedPhi {R : Type*} [Semiring R] {n : ℕ}
    (A : ℕ → Matrix (Fin n) (Fin n) R) : ℕ → Matrix (Fin n) (Fin n) R
  | 0 => 1
  | k+1 => A k * liftedPhi A k

def liftedB {R : Type*} [Semiring R] {n m w : ℕ}
    (A : ℕ → Matrix (Fin n) (Fin n) R) (B : ℕ → Matrix (Fin n) (Fin m) R)
    (S : ℕ → Matrix (Fin m) (Fin w) R) : ℕ → Matrix (Fin n) (Fin w) R
  | 0 => 0
  | k+1 => A k * liftedB A B S k + B k * S k

theorem frameState_lift {n m w : ℕ}
    (A : ℕ → Mat n n) (B : ℕ → Mat n m) (S : ℕ → Mat m w) (v : Mat w 1)
    (x : Mat n 1) (k : ℕ) :
    frameState A B (fun j => S j*v) x k = liftedPhi A k*x + liftedB A B S k*v := by
  induction k with
  | zero => simp [frameState,liftedPhi,liftedB]
  | succ k ih =>
    simp only [frameState, liftedPhi, liftedB, ih, Matrix.mul_add, Matrix.add_mul,
      Matrix.mul_assoc, add_assoc]

theorem withinFrameOutput {n m o w : ℕ}
    (A : ℕ → Mat n n) (B : ℕ → Mat n m) (C : ℕ → Mat o n) (D : ℕ → Mat o m)
    (S : ℕ → Mat m w) (v : Mat w 1) (x : Mat n 1) (k : ℕ) :
    C k * frameState A B (fun j => S j*v) x k + D k*(S k*v) =
      (C k * liftedPhi A k) * x + (C k * liftedB A B S k + D k * S k) * v := by
  rw [frameState_lift]
  simp only [Matrix.add_mul, Matrix.mul_add, Matrix.mul_assoc, add_assoc]

theorem map_liftedPhi {R R' : Type*} [Semiring R] [Semiring R'] {n : ℕ}
    (e : R →+* R') (A : ℕ → Matrix (Fin n) (Fin n) R) (k : ℕ) :
    (liftedPhi A k).map e = liftedPhi (fun j => (A j).map e) k := by
  induction k with
  | zero => simp [liftedPhi]
  | succ k ih => simp [liftedPhi, Matrix.map_mul, ih]

theorem map_liftedB {R R' : Type*} [Semiring R] [Semiring R'] {n m w : ℕ}
    (e : R →+* R') (A : ℕ → Matrix (Fin n) (Fin n) R)
    (B : ℕ → Matrix (Fin n) (Fin m) R) (S : ℕ → Matrix (Fin m) (Fin w) R) (k : ℕ) :
    (liftedB A B S k).map e =
      liftedB (fun j => (A j).map e) (fun j => (B j).map e) (fun j => (S j).map e) k := by
  induction k with
  | zero => simp [liftedB]
  | succ k ih => simp [liftedB, Matrix.map_mul, Matrix.map_add, ih]


/-- Coordinate identification for the direct sum in the difference realization (47). -/
def pairStack {n₁ n₂ m : ℕ} (X : Mat n₁ m) (Y : Mat n₂ m) : Mat (n₁+n₂) m :=
  (Matrix.fromRows X Y).submatrix finSumFinEquiv.symm id

def pairDynamics {n₁ n₂ : ℕ} (A : Mat n₁ n₁) (B : Mat n₂ n₂) : Mat (n₁+n₂) (n₁+n₂) :=
  (Matrix.fromBlocks A 0 0 B).submatrix finSumFinEquiv.symm finSumFinEquiv.symm

def differenceReadout {n₁ n₂ o : ℕ} (C : Mat o n₁) (F : Mat o n₂) : Mat o (n₁+n₂) :=
  (Matrix.fromCols C (-F)).submatrix id finSumFinEquiv.symm

private theorem pairDynamics_mul {n₁ n₂ m : ℕ} (A : Mat n₁ n₁) (B : Mat n₂ n₂)
    (X : Mat n₁ m) (Y : Mat n₂ m) :
    pairDynamics A B * pairStack X Y = pairStack (A*X) (B*Y) := by
  simp [pairDynamics, pairStack, Matrix.submatrix_mul_equiv, Matrix.fromBlocks_mul_fromRows]

private theorem pairStack_mul {n₁ n₂ m w : ℕ} (X : Mat n₁ m) (Y : Mat n₂ m) (v : Mat m w) :
    pairStack X Y * v = pairStack (X*v) (Y*v) := by
  unfold pairStack
  rw [← Matrix.fromRows_mul, Matrix.submatrix_mul _ _ _ id id Function.bijective_id]
  rfl

private theorem pairStack_add {n₁ n₂ m : ℕ} (X X' : Mat n₁ m) (Y Y' : Mat n₂ m) :
    pairStack X Y + pairStack X' Y' = pairStack (X+X') (Y+Y') := by
  funext i j
  unfold pairStack
  change Matrix.fromRows X Y (finSumFinEquiv.symm i) j +
    Matrix.fromRows X' Y' (finSumFinEquiv.symm i) j =
    Matrix.fromRows (X+X') (Y+Y') (finSumFinEquiv.symm i) j
  cases finSumFinEquiv.symm i <;> rfl

private theorem differenceReadout_mul {n₁ n₂ m o : ℕ} (C : Mat o n₁) (F : Mat o n₂)
    (X : Mat n₁ m) (Y : Mat n₂ m) :
    differenceReadout C F * pairStack X Y = C*X-F*Y := by
  simp [differenceReadout, pairStack, Matrix.submatrix_mul_equiv, Matrix.fromCols_mul_fromRows,
    Matrix.neg_mul, sub_eq_add_neg]

private theorem advance_pair {n₁ n₂ m : ℕ} (A₁ : Mat n₁ n₁) (A₂ : Mat n₂ n₂)
    (B₁ : Mat n₁ m) (B₂ : Mat n₂ m) (x : Mat n₁ 1) (y : Mat n₂ 1) (us : List (Mat m 1)) :
    advance (pairDynamics A₁ A₂) (pairStack B₁ B₂) (pairStack x y) us =
      pairStack (advance A₁ B₁ x us) (advance A₂ B₂ y us) := by
  induction us with
  | nil => rfl
  | cons u us ih => simp only [advance, ih, pairDynamics_mul, pairStack_mul, pairStack_add]

/-- The finite test spelled out for two separate systems with different state
dimensions, including every pair of initial states parameterized by (G₁q,G₂q). -/
theorem twoLiftEquality {n₁ n₂ m o p : ℕ}
    (A₁ : Mat n₁ n₁) (A₂ : Mat n₂ n₂) (B₁ : Mat n₁ m) (B₂ : Mat n₂ m)
    (C₁ : Mat o n₁) (C₂ : Mat o n₂) (D₁ D₂ : Mat o m) (G₁ : Mat n₁ p) (G₂ : Mat n₂ p) :
    (∀ (q : Mat p 1) (v : Mat m 1) (us : List (Mat m 1)),
      C₁ * advance A₁ B₁ (G₁*q) us + D₁*v = C₂ * advance A₂ B₂ (G₂*q) us + D₂*v) ↔
      (D₁ - D₂ = 0 ∧
       (∀ j < n₁+n₂, differenceReadout C₁ C₂ * (pairDynamics A₁ A₂)^j * pairStack B₁ B₂ = 0) ∧
       (∀ j < n₁+n₂, differenceReadout C₁ C₂ * (pairDynamics A₁ A₂)^j * pairStack G₁ G₂ = 0)) := by
  rw [← finitePeriodicEquality]
  apply forall_congr'
  intro q
  apply forall_congr'
  intro v
  apply forall_congr'
  intro us
  rw [pairStack_mul, advance_pair, differenceReadout_mul, Matrix.sub_mul]
  rw [sub_add_sub_comm, sub_eq_zero]


/-- Treat each complex root as two independently quantified real unknowns. -/
def complexPoint {σ : Type*} (u : σ × Bool → ℝ) (i : σ) : ℂ :=
  ⟨u (i,false),u (i,true)⟩

private def realCoordinates {σ : Type*} (ρ : σ → ℂ) (i : σ × Bool) : ℝ :=
  if i.2 then (ρ i.1).im else (ρ i.1).re

@[simp] private theorem complexPoint_coordinates {σ : Type*} (ρ : σ → ℂ) :
    complexPoint (realCoordinates ρ) = ρ := by
  funext i
  apply Complex.ext <;> simp [complexPoint,realCoordinates]

/-- Realification of an arbitrary complex polynomial (not just root products):
both parts are polynomials over ℝ in the real and imaginary coordinates. -/
theorem realImagPolynomials {σ : Type*} (P : MvPolynomial σ ℂ) :
    ∃ Q : MvPolynomial (σ × Bool) ℝ × MvPolynomial (σ × Bool) ℝ,
    ∀ u : σ × Bool → ℝ,
      (MvPolynomial.eval (complexPoint u) P).re = MvPolynomial.eval u Q.1 ∧
      (MvPolynomial.eval (complexPoint u) P).im = MvPolynomial.eval u Q.2 := by
  induction P using MvPolynomial.induction_on with
  | C c => exact ⟨(MvPolynomial.C c.re, MvPolynomial.C c.im),fun u => by simp⟩
  | add p q hp hq =>
    obtain ⟨a,ha⟩ := hp
    obtain ⟨b,hb⟩ := hq
    exact ⟨(a.1+b.1,a.2+b.2),fun u => by simp [Complex.add_re,Complex.add_im,ha u,hb u]⟩
  | mul_X p i hp =>
    obtain ⟨a,ha⟩ := hp
    let r : MvPolynomial (σ × Bool) ℝ := MvPolynomial.X (i,false)
    let t : MvPolynomial (σ × Bool) ℝ := MvPolynomial.X (i,true)
    refine ⟨(a.1*r-a.2*t,a.1*t+a.2*r),fun u => ?_⟩
    simp [Complex.mul_re,Complex.mul_im, ha u, r, t, complexPoint]

noncomputable def realImag {σ : Type*} (P : MvPolynomial σ ℂ) :=
  Classical.choose (realImagPolynomials P)

theorem realImag_spec {σ : Type*} (P : MvPolynomial σ ℂ) (u : σ × Bool → ℝ) :
    (MvPolynomial.eval (complexPoint u) P).re = MvPolynomial.eval u (realImag P).1 ∧
    (MvPolynomial.eval (complexPoint u) P).im = MvPolynomial.eval u (realImag P).2 :=
  Classical.choose_spec (realImagPolynomials P) u

theorem realRootWitness {a : ℕ} (c : ℕ → ℝ) :
    (∃ ρ : Fin a → ℂ, (∀ j ≤ a, (c j : ℂ) =
        MvPolynomial.eval ρ ((rootPolynomial a).coeff j)) ∧
      ∀ i, (ρ i).re^2+(ρ i).im^2 < 1) ↔
    (∃ u : Fin a × Bool → ℝ, (∀ j ≤ a,
      c j = MvPolynomial.eval u (realImag ((rootPolynomial a).coeff j)).1 ∧
      0 = MvPolynomial.eval u (realImag ((rootPolynomial a).coeff j)).2) ∧
      ∀ i, (u (i,false))^2+(u (i,true))^2 < 1) := by
  constructor
  · rintro ⟨ρ,hc,hd⟩
    refine ⟨realCoordinates ρ, ?_, by simpa [realCoordinates] using hd⟩
    intro j hj
    have hs := realImag_spec ((rootPolynomial a).coeff j) (realCoordinates ρ)
    rw [complexPoint_coordinates] at hs
    rw [← hs.1, ← hs.2, ← hc j hj]
    simp
  · rintro ⟨u,hc,hd⟩
    refine ⟨complexPoint u, ?_, hd⟩
    intro j hj
    have hs := realImag_spec ((rootPolynomial a).coeff j) u
    apply Complex.ext
    · rw [Complex.ofReal_re,hs.1]
      exact (hc j hj).1
    · rw [Complex.ofReal_im,hs.2]
      exact (hc j hj).2

/-- Entire fixed-schedule search, including stability, in real variables.
The right side has only existence over a finite schedule set and finitely many
real unknowns, polynomial equalities, and strict polynomial inequalities. -/
theorem fixedScheduleRealFeasibility {S d n m o p a ne ni : ℕ}
    (A : Fin S → Matrix (Fin n) (Fin n) (MvPolynomial (Fin d) ℝ))
    (B : Fin S → Matrix (Fin n) (Fin m) (MvPolynomial (Fin d) ℝ))
    (C : Fin S → Matrix (Fin o) (Fin n) (MvPolynomial (Fin d) ℝ))
    (D : Fin S → Matrix (Fin o) (Fin m) (MvPolynomial (Fin d) ℝ))
    (G : Fin S → Matrix (Fin n) (Fin p) (MvPolynomial (Fin d) ℝ))
    (Φ : Fin S → Matrix (Fin a) (Fin a) (MvPolynomial (Fin d) ℝ))
    (equal : Fin S → Fin ne → MvPolynomial (Fin d) ℝ)
    (positive : Fin S → Fin ni → MvPolynomial (Fin d) ℝ) :
    (∃ s x, let e := MvPolynomial.eval x
      (∀ i, e (equal s i) = 0) ∧ (∀ i, 0 < e (positive s i)) ∧
      (∀ (q : Mat p 1) (v : Mat m 1) (us : List (Mat m 1)),
        (C s).map e * advance ((A s).map e) ((B s).map e) ((G s).map e*q) us +
          (D s).map e*v = 0) ∧
      (∀ z, ((Φ s).map (Complex.ofRealHom.comp e)).charpoly.IsRoot z → ‖z‖ < 1)) ↔
    (∃ s x, let e := MvPolynomial.eval x
      (∀ i, e (equal s i) = 0) ∧ (∀ i, 0 < e (positive s i)) ∧
      ((D s).map e = 0 ∧ (∀ j < n, (C s * A s^j * B s).map e = 0) ∧
        (∀ j < n, (C s * A s^j * G s).map e = 0)) ∧
      ∃ u : Fin a × Bool → ℝ, (∀ j ≤ a,
        e ((Φ s).charpoly.coeff j) = MvPolynomial.eval u (realImag ((rootPolynomial a).coeff j)).1 ∧
        0 = MvPolynomial.eval u (realImag ((rootPolynomial a).coeff j)).2) ∧
        ∀ i, (u (i,false))^2+(u (i,true))^2 < 1) := by
  apply (fixedScheduleFeasibility A B C D G Φ equal positive).trans
  apply exists_congr
  intro s
  apply exists_congr
  intro x
  exact and_congr Iff.rfl (and_congr Iff.rfl (and_congr Iff.rfl
    (realRootWitness (fun j => MvPolynomial.eval x ((Φ s).charpoly.coeff j)))))

theorem nonnegativePolynomialWitness (r : ℝ) : 0 ≤ r ↔ ∃ w : ℝ, r=w^2 :=
  ⟨fun h => ⟨Real.sqrt r, (Real.sq_sqrt h).symm⟩, fun ⟨w, h⟩ => h ▸ sq_nonneg w⟩


/-- Symbolic matrices of (40) and (41) over any coefficient ring, including
the polynomial ring of the augmented physical parameters. -/
def phaseF {R : Type*} [Ring R] (p i d b₁ α β : R) : Matrix (Fin 5) (Fin 5) R :=
  !![1-p,0,0,0,0; 0,1,0,i*b₁,0; 0,0,1-d*(1-α),0,-(d*β);
     0,0,0,1-i,0; 0,0,0,0,1-d]

def phaseGy {R : Type*} [Ring R] (p i d K b₀ β : R) : Fin 5 → R :=
  ![-(p*K),-(i*b₀),-(d*β),-i,-d]

def phaseGr {R : Type*} [Ring R] (p i d K b₀ β b c : R) : Fin 5 → R :=
  ![p*K*b,i*b₀,d*β*c,i,d*c]

/-- Physical branch update (2) in algebraic form. For 0/1 event flags the
two terms in each line respectively retain the old sample or update it. -/
def drivenBranches (p i d K b₀ b₁ α β b c r y : ℝ) (x : Fin 5 → ℝ) : Fin 5 → ℝ :=
  ![(1-p)*x 0+p*K*(b*r-y),
    x 1+i*(b₀*(r-y)+b₁*x 3),
    (1-d*(1-α))*x 2+d*β*(c*r-y-x 4),
    (1-i)*x 3+i*(r-y), (1-d)*x 4+d*(c*r-y)]

theorem physicalPhaseMatrices (p i d K b₀ b₁ α β b c r y : ℝ) (x : Fin 5 → ℝ) :
    drivenBranches p i d K b₀ b₁ α β b c r y x =
    (phaseF p i d b₁ α β).mulVec x +
      y • phaseGy p i d K b₀ β + r • phaseGr p i d K b₀ β b c := by
  funext j
  fin_cases j <;> simp [drivenBranches, phaseF, phaseGy, phaseGr, Matrix.mulVec,
    dotProduct, Fin.sum_univ_succ] <;> ring

end MPCPID.Periodic
