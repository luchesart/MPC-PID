import MPCPID.GainGraph

/-! Normalize a common sampling interval before applying the algebraic
feasibility reduction. All three physical times in (4) are free positive
parameters. The discrete plant, event indices and reference weights are fixed. -/
namespace MPCPID.TimeUnits
open GainGraph
noncomputable section

def rescale (h : ℝ) (p : Physical) : Physical :=
  {p with Ti := h*p.Ti, Td := h*p.Td, Tf := h*p.Tf}

theorem admissible_rescale (p : Physical) {h : ℝ} (hh : 0 < h) :
    Admissible (rescale h p) ↔ Admissible p := by
  simp only [Admissible, rescale, mul_pos_iff_of_pos_left hh]

theorem coefficients_rescale (TI TD : ℝ) {h : ℝ} (hh : 0 < h) (p : Physical) :
    rational (h*TI) (h*TD) (rescale h p) = rational TI TD p := by
  have den : h*p.Tf+p.γD*(h*TD) = h*(p.Tf+p.γD*TD) := by ring
  have cancel (v w : ℝ) : h*v/(h*w) = v/w := mul_div_mul_left v w hh.ne'
  have move (v : ℝ) : p.K*(h*v) = h*(p.K*v) := by ring
  ext <;> simp only [rational, rescale, den, move, cancel]

theorem normalize_fixed_interval (TI TD : ℝ) {h : ℝ} (hh : 0 < h) (P : Coeff ℝ → Prop) :
    (∃ g, Admissible g ∧ P (rational (h*TI) (h*TD) g)) ↔
      ∃ g, Admissible g ∧ P (rational TI TD g) := by
  constructor
  · rintro ⟨g,hg,hs⟩
    let p := rescale h⁻¹ g
    have hind : rescale h p = g := by
      cases g
      simp [p,rescale,← mul_assoc,hh.ne']
    use p
    refine ⟨(admissible_rescale g (inv_pos.mpr hh)).2 hg,?_⟩
    rw [← coefficients_rescale TI TD hh p,hind]
    exact hs
  · rintro ⟨g,hg,hs⟩
    exact ⟨rescale h g,(admissible_rescale g hh).2 hg,by rwa [coefficients_rescale TI TD hh g]⟩

end
end MPCPID.TimeUnits
