import MPCPID.Optimal
import MPCPID.Conditioned
import MPCPID.Predictive

/-!
# Global MIACE optimality for the applied signal

The old equilibrium supplies the coordinate origin, including the one-sample
input history. The new equilibrium may be positive, zero or negative.
Competitors are specified by their actual input and output signals.
-/
noncomputable section
namespace MPCPID.PhysicalOptimal

open Optimal.Model
variable (P : Optimal.Model)

def equilibriumInput (step : ℝ) := (1-P.a)*step/P.s
def actualError (step : ℝ) (y : ℕ → ℝ) (k : ℕ) := step-y (k+1)
def actualExcess (step : ℝ) (u : ℕ → ℝ) (k : ℕ) := u k-equilibriumInput P step

theorem equilibrium_identity (step : ℝ) :
    (1-P.a)*step=(P.b+P.c)*equilibriumInput P step := by
  unfold equilibriumInput
  change (1-P.a)*step=P.s*((1-P.a)*step/P.s)
  field_simp [ne_of_gt P.s_pos]

theorem applied_advance (step : ℝ) (u y : ℕ → ℝ)
    (plant : ∀ k, y (k+1)=P.a*y k+P.b*u k+P.c*Conditioned.lag u k)
    (law : ∀ k, u k=Predictive.eta P.a P.b P.c P.l*step-Predictive.fy P.a P.b P.l*y k+
      Predictive.memoryGain P.b P.c P.l*Conditioned.lag u k) (k : ℕ) :
    (actualError step y k,actualExcess P step u k) =
      P.advance (step-y k,Conditioned.lag u k-equilibriumInput P step) := by
  let x := (step-y k,Conditioned.lag u k-equilibriumInput P step)
  have hc : equilibriumInput P step + (P.advance x).2 = u k := calc
    _ = ((P.b+P.l*(1-P.a)/P.s)/P.den)*step - (P.a*P.b/P.den)*y k -
        (P.b*P.c/P.den)*Conditioned.lag u k := P.advance_first_move step (y k) (Conditioned.lag u k)
    _ = u k := by
      rw [law k]
      simp only [Predictive.eta,Predictive.fy,Predictive.memoryGain,s,den]
      ring
  have hv : actualExcess P step u k = (P.advance x).2 := by
    unfold actualExcess
    linarith
  change (_,_) = P.advance x
  apply Prod.ext
  · change step-y (k+1) = (P.advance x).1
    rw [P.advance_plant x, ← hv, plant k]
    dsimp only [x,actualExcess]
    linear_combination equilibrium_identity P step
  · exact hv

theorem applied_trajectory (step : ℝ) (u y : ℕ → ℝ) (initial : y 0=0)
    (plant : ∀ k, y (k+1)=P.a*y k+P.b*u k+P.c*Conditioned.lag u k)
    (law : ∀ k, u k=Predictive.eta P.a P.b P.c P.l*step-Predictive.fy P.a P.b P.l*y k+
      Predictive.memoryGain P.b P.c P.l*Conditioned.lag u k) (k : ℕ) :
    (actualError step y k,actualExcess P step u k) = P.trajectory step k := by
  induction k with
  | zero =>
    rw [applied_advance P step u y plant law 0,trajectory,initial]
    simp [Conditioned.lag, equilibriumInput,before]
    congr 2
    ring
  | succ k ih =>
    rw [applied_advance P step u y plant law (k+1),trajectory]
    exact congrArg P.advance ih

theorem any_applied_plant (step : ℝ) (u y : ℕ → ℝ) (initial : y 0=0)
    (plant : ∀ k, y (k+1)=P.a*y k+P.b*u k+P.c*Conditioned.lag u k) :
    P.Plant step (actualError step y) (actualExcess P step u) := by
  have hprevE (k : ℕ) : prev step (actualError step y) k = step-y k := by
    cases k <;> simp [prev,actualError,initial]
  have hprevU (k : ℕ) : prev (P.before step) (actualExcess P step u) k =
      Conditioned.lag u k-equilibriumInput P step := by
    cases k <;> simp [prev,before,Conditioned.lag,actualExcess,equilibriumInput]
    ring
  intro k
  rw [hprevE,hprevU]
  simp only [actualError,actualExcess,plant]
  linear_combination equilibrium_identity P step

theorem applied_signals (step : ℝ) (u y : ℕ → ℝ) (initial : y 0=0)
    (plant : ∀ k, y (k+1)=P.a*y k+P.b*u k+P.c*Conditioned.lag u k)
    (law : ∀ k, u k=Predictive.eta P.a P.b P.c P.l*step-Predictive.fy P.a P.b P.l*y k+
      Predictive.memoryGain P.b P.c P.l*Conditioned.lag u k) :
    actualError step y = P.err step ∧ actualExcess P step u = P.cmd step := by
  have H (k : ℕ) := (applied_trajectory P step u y initial plant law k).trans (P.trajectory_eq step k)
  exact ⟨funext fun k => congrArg Prod.fst (H k), funext fun k => congrArg Prod.snd (H k)⟩

/-- Both sides use the commands actually applied and the next measured
outputs. The competitor may have infinite area. -/
theorem applied_global_optimal {step h μ : ℝ} (hh : 0 ≤ h) (hμ : 0 < μ)
    (htune : P.l=P.b*μ*(1-P.a)/P.s) (hmono : P.b*P.c ≤ P.a*P.l)
    (u y : ℕ → ℝ) (initial : y 0=0)
    (plant : ∀ k, y (k+1)=P.a*y k+P.b*u k+P.c*Conditioned.lag u k)
    (law : ∀ k, u k=Predictive.eta P.a P.b P.c P.l*step-Predictive.fy P.a P.b P.l*y k+
      Predictive.memoryGain P.b P.c P.l*Conditioned.lag u k)
    (otherU otherY : ℕ → ℝ) (otherInitial : otherY 0=0)
    (otherPlant : ∀ k, otherY (k+1)=P.a*otherY k+P.b*otherU k+P.c*Conditioned.lag otherU k) :
    extendedCost h μ (actualError step y) (actualExcess P step u) ≤
      extendedCost h μ (actualError step otherY) (actualExcess P step otherU) := by
  obtain ⟨hE,hV⟩ := applied_signals P step u y initial plant law
  rw [hE,hV]
  exact P.all_sequences_optimal hh hμ htune hmono
    (any_applied_plant P step otherU otherY otherInitial otherPlant)

theorem applied_exact_value {step h μ : ℝ} (hh : 0 ≤ h) (hμ : 0 < μ)
    (htune : P.l=P.b*μ*(1-P.a)/P.s) (hmono : P.b*P.c ≤ P.a*P.l)
    (u y : ℕ → ℝ) (initial : y 0=0)
    (plant : ∀ k, y (k+1)=P.a*y k+P.b*u k+P.c*Conditioned.lag u k)
    (law : ∀ k, u k=Predictive.eta P.a P.b P.c P.l*step-Predictive.fy P.a P.b P.l*y k+
      Predictive.memoryGain P.b P.c P.l*Conditioned.lag u k) :
    cost h μ (actualError step y) (actualExcess P step u) =
      P.barrier h step / Real.sqrt ((1-P.a)^2+P.s^2/μ) := by
  obtain ⟨hE,hV⟩ := applied_signals P step u y initial plant law
  rw [hE,hV]
  exact P.attained_miace hh hμ htune hmono

end MPCPID.PhysicalOptimal
