import MPCPID.Periodic

/-! Rigidity of the P and D clocks for the finite reference probe. A
phase-independent sum with nonzero first lag and a finite tail cannot be
synthesized by slower clocks in the physical PID. -/
namespace MPCPID.NominalRigidity
open Periodic
noncomputable section
attribute [local instance] Classical.propDecidable

def propState (P : ℕ → Prop) (K : ℝ) (X : ℕ → ℝ) (s : ℕ) : ℕ → ℝ
  | 0 => 0
  | k+1 => if P (s+k) then K*X k else propState P K X s k

def diffState (D : ℕ → Prop) (α β : ℝ) (Z : ℕ → ℝ) (s : ℕ) : ℕ → ℝ × ℝ
  | 0 => (0,0)
  | k+1 => let v := diffState D α β Z s k
           if D (s+k) then (α*v.1 + β*(Z k-v.2), Z k) else v

private theorem no_neighbor {m φ k : ℕ} (hm : 1<m) (hf : φ<m)
    (hit : atPhase m φ k) : ¬ atPhase m φ (k+1) := by
  change (k+1)%m ≠ φ
  change k%m = φ at hit
  rw [Nat.add_mod,hit,Nat.mod_eq_of_lt hm]
  by_cases h : φ+1=m
  · rw [h,Nat.mod_self]; omega
  · rw [Nat.mod_eq_of_lt (by omega : φ+1<m)]; omega

private theorem misses {m φ : ℕ} (hm : 1<m) (hf : φ<m) (n : ℕ) :
    ∃ s, ¬atPhase m φ (s+n) := by
  obtain ⟨j,hj,hit⟩ := phaseCofinal hf n
  refine ⟨j+1-n,?_⟩
  rw [show j+1-n+n=j+1 by omega]
  exact no_neighbor hm hf hit

private theorem stationary_held {F : ℕ → Prop} {x : ℕ → ℕ → ℝ}
    (skip : ∀ k, ∃ s, ¬F (s+k)) (zero : ∀ s, x s 0=0)
    (equ : ∀ s t k, x s k=x t k)
    (hold : ∀ s k, ¬F (s+k) → x s (k+1)=x s k) :
    ∀ s k, x s k=0 := by
  intro s k
  induction k with
  | zero => exact zero s
  | succ k ih =>
    obtain ⟨t,miss⟩ := skip k
    rw [equ s t (k+1),hold t k miss,equ t s k,ih]

/-- No slow P/D schedule can produce this same short command response at
every impulse phase. X and Z are the reference-weighted branch errors. -/
theorem finite_pd_rigidity {mP mD φP φD : ℕ} (hp : φP<mP) (hd : φD<mD)
    {K α β : ℝ} (hK : 0<K) (hβ : 0<β)
    (X Z W : ℕ → ℝ) (hx2 : X 2 ≠ 0) (hx4 : X 4=0)
    (hz : Z 0 = 0 → Z 1 ≠ 0) (w1 : W 1 ≠ 0) (w3 : W 3=0) (w4 : W 4=0)
    (equ : ∀ s k, propState (atPhase mP φP) K X s (k+1) +
      (diffState (atPhase mD φD) α β Z s (k+1)).1 = W k) :
    mP=1 ∧ mD=1 := by
  classical
  let P := atPhase mP φP
  let D := atPhase mD φD
  let p := propState P K X
  let d := diffState D α β Z
  change ∀ s k, p s (k+1)+(d s (k+1)).1 = W k at equ
  have pr (s k : ℕ) : p s (k+1) = if P (s+k) then K*X k else p s k := rfl
  have dr (s k : ℕ) : d s (k+1) = if D (s+k) then
    (α*(d s k).1+β*(Z k-(d s k).2),Z k) else d s k := rfl
  by_cases oneP : mP=1
  · refine ⟨oneP,?_⟩
    by_contra bad
    have mD' : 1<mD := by omega
    have fullP (n : ℕ) : P n := by simp [P,atPhase,oneP,show φP=0 by omega,Nat.mod_one]
    have deq (s t k : ℕ) : (d s k).1 = (d t k).1 := by
      cases k with
      | zero => rfl
      | succ k =>
        have f := equ s k
        have g := equ t k
        rw [pr,if_pos (fullP _)] at f g
        linarith
    have dz : ∀ s k, (d s k).1=0 := stationary_held (F:=D) (x:=fun s k => (d s k).1)
      (misses mD' hd) (fun _ => rfl) deq (fun s k h => by
        change (d s (k+1)).1 = (d s k).1
        rw [dr s k,if_neg h])
    obtain ⟨q,hq,dq⟩ := phaseCofinal hd 1
    change D q at dq
    have at₀ := dz q 1
    rw [dr q 0, Nat.add_zero,if_pos dq] at at₀
    change α*0 + β*(Z 0 - 0) = 0 at at₀
    have z₀ : Z 0=0 := (mul_eq_zero.mp (by simpa using at₀ : β*Z 0=0)).resolve_left hβ.ne'
    let t := q-1
    have tq : t+1=q := by dsimp [t]; omega
    have prev : (d t 1).2=0 := by
      rw [dr t 0]
      split
      · exact z₀
      · rfl
    have at₁ := dz t 2
    rw [dr t 1,tq,if_pos dq] at at₁
    change α*(d t 1).1 + β*(Z 1 - (d t 1).2)=0 at at₁
    rw [dz t 1,prev] at at₁
    exact hz z₀ ((mul_eq_zero.mp (by simpa using at₁ : β*Z 1=0)).resolve_left hβ.ne')
  have mP' : 1<mP := by omega
  by_cases oneD : mD=1
  · have fullD (n : ℕ) : D n := by simp [D,atPhase,oneD,show φD=0 by omega,Nat.mod_one]
    have deq (s t k : ℕ) : d s k = d t k := by
      induction k with
      | zero => rfl
      | succ k ih => rw [dr,dr,if_pos (fullD _),if_pos (fullD _),ih]
    have peq (s t k : ℕ) : p s k = p t k := by
      cases k with
      | zero => rfl
      | succ k =>
        have f := equ s k
        have g := equ t k
        rw [deq s t _] at f
        linarith
    have pz := stationary_held (F:=P) (x:=p) (misses mP' hp) (fun _ => rfl) peq
      (fun s k h => by rw [pr,if_neg h])
    obtain ⟨q,hq,pq⟩ := phaseCofinal hp 2
    have pq' : P (q-2+2) := by rwa [show q-2+2=q by omega]
    have at₂ := pz (q-2) 3
    rw [pr (q-2) 2,if_pos pq'] at at₂
    exact False.elim ((mul_ne_zero hK.ne' hx2) at₂)
  have mD' : 1<mD := by omega
  have cover (q : ℕ) (hq : 0<q) (notP : ¬P q) : D q := by
    apply Classical.byContradiction
    intro notD
    have zero := equ q 0
    rw [pr,dr,Nat.add_zero,if_neg notP,if_neg notD] at zero
    change 0+0=W 0 at zero
    let t := q-1
    have tq : t+1=q := by dsimp [t]; omega
    have first := equ t 1
    rw [pr,dr,tq,if_neg notP,if_neg notD] at first
    exact w1 (by linarith [equ t 0])
  obtain ⟨q,hq,pq⟩ := phaseCofinal hp 2
  change P q at pq
  let t := q-2
  have t₂ : t+2=q := by dsimp [t]; omega
  have p₂ : P (t+2) := by rwa [t₂]
  have noP₃ : ¬P (t+3) := no_neighbor mP' hp p₂
  have d₃ := cover (t+3) (by omega) noP₃
  have noD₄ : ¬D (t+4) := no_neighbor mD' hd d₃
  have p₄ : P (t+4) := Classical.byContradiction (fun e => noD₄ (cover _ (by omega) e))
  have h₂ : p t 3=K*X 2 := by rw [pr t 2,if_pos p₂]
  have h₃ : p t 4=K*X 2 := by rw [pr t 3,if_neg noP₃,h₂]
  have h₄ : p t 5=0 := by rw [pr t 4,if_pos p₄,hx4,mul_zero]
  have dh₄ : d t 5=d t 4 := by rw [dr t 4,if_neg noD₄]
  have f := equ t 3
  have g := equ t 4
  rw [h₃,w3] at f
  rw [h₄,dh₄,w4] at g
  exact False.elim ((mul_ne_zero hK.ne' hx2) (by linarith))

end
end MPCPID.NominalRigidity
