import Mathlib.Data.Complex.Norm
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-! # Positive filtered PID membership and nominal matching

All coefficients and branch parameters are real. Time-domain residuals below are
evaluated on actual present and delayed samples. No transform injectivity or
implicit cancellation of a controller mode is assumed. -/
namespace MPCPID.Matching
noncomputable section

@[ext] structure Coeff where
  c0 : ℝ
  c1 : ℝ
  c2 : ℝ

@[ext] structure Channels where
  y : Coeff
  r : Coeff

@[ext] structure Digital where
  k : ℝ
  d : ℝ
  A : ℝ
  B : ℝ
  V : ℝ

def Coeff.atOne (q : Coeff) : ℝ := q.c0 + q.c1 + q.c2

/-- Coefficients of (13) and (14), in delay order. -/
def channels (α : ℝ) (v : Digital) : Channels :=
  let y : Coeff := ⟨v.A + v.d, v.k - (1 + α)*v.A - 2*v.d,
                    α*(v.A - v.k) + v.d⟩
  ⟨y, ⟨y.c0 + v.B + v.V, y.c1 - (1+α)*v.B - 2*v.V,
        y.c2 + α*v.B + v.V⟩⟩

/-- Equation (9). The reference slope is recovered from the common DC value. -/
def decode (α : ℝ) (q : Channels) : Digital :=
  let d := (α^2*q.y.c0 + α*q.y.c1 + q.y.c2) / (1-α)^2
  let Δ0 := q.r.c0-q.y.c0
  let Δ2 := q.r.c2-q.y.c2
  ⟨q.y.atOne / (1-α), d, q.y.c0-d, (Δ0-Δ2)/(1-α), (Δ2-α*Δ0)/(1-α)⟩

theorem dc_equal (α : ℝ) (v : Digital) :
    (channels α v).r.atOne = (channels α v).y.atOne := by
  simp only [channels, Coeff.atOne]
  ring

theorem decode_channels (α : ℝ) (hα : α < 1) (v : Digital) :
    decode α (channels α v) = v := by
  have h : 1-α ≠ 0 := by linarith
  apply Digital.ext <;> simp only [decode, channels, Coeff.atOne] <;>
    field_simp [h] <;> ring

theorem channels_decode (α : ℝ) (hα : α < 1) (q : Channels)
    (he : q.r.atOne = q.y.atOne) : channels α (decode α q) = q := by
  have h : 1-α ≠ 0 := by linarith
  let u := channels α (decode α q)
  have hy : u.y = q.y := by
    apply Coeff.ext <;> dsimp [u, channels, decode, Coeff.atOne] <;>
      field_simp [h] <;> ring
  have h0 : u.r.c0 = q.r.c0 := by
    dsimp [u, channels, decode, Coeff.atOne]
    field_simp [h]
    ring
  have h2 : u.r.c2 = q.r.c2 := by
    dsimp [u, channels, decode, Coeff.atOne]
    field_simp [h]
    ring
  have hu : u.r.atOne = u.y.atOne := dc_equal α _
  rw [hy] at hu
  have h1 : u.r.c1 = q.r.c1 := by
    simp only [Coeff.atOne] at hu he
    linarith
  exact Channels.ext hy (Coeff.ext h0 h1 h2)

def Digital.Admissible (v : Digital) : Prop :=
  0 < v.k ∧ 0 < v.d ∧ 0 < v.A ∧ -v.A ≤ v.B ∧ v.B ≤ 0 ∧ -v.d ≤ v.V ∧ v.V ≤ 0

def realization (K k d g b c : ℝ) : Digital :=
  ⟨k, d, K+k*g, K*(b-1), d*(c-1)⟩

def PositiveRealization (α : ℝ) (q : Channels) : Prop :=
  ∃ K k d g b c : ℝ, 0 < K ∧ 0 < k ∧ 0 < d ∧
    g ∈ Set.Icc 0 1 ∧ b ∈ Set.Icc 0 1 ∧ c ∈ Set.Icc 0 1 ∧
    channels α (realization K k d g b c) = q

theorem realization_admissible {K k d g b c : ℝ} (hK : 0 < K)
    (hk : 0 < k) (hd : 0 < d) (hg : g ∈ Set.Icc 0 1)
    (hb : b ∈ Set.Icc 0 1) (hc : c ∈ Set.Icc 0 1) :
    (realization K k d g b c).Admissible := by
  rcases hg with ⟨hg0, hg1⟩
  rcases hb with ⟨hb0, hb1⟩
  rcases hc with ⟨hc0, hc1⟩
  dsimp [Digital.Admissible, realization]
  refine ⟨hk,hd,?_,?_,?_,?_,?_⟩
  · nlinarith [mul_nonneg hk.le hg0]
  · nlinarith [mul_nonneg hk.le hg0, mul_nonneg hK.le hb0]
  · exact mul_nonpos_of_nonneg_of_nonpos hK.le (by linarith)
  · nlinarith [mul_nonneg hd.le hc0]
  · exact mul_nonpos_of_nonneg_of_nonpos hd.le (by linarith)

/-- Equations (11)–(12), allowing every admissible integral discretization. -/
theorem realize_at_integral_weight (v : Digital) (hv : v.Admissible) (g : ℝ)
    (hK : 0 < v.A-v.k*g) (hB : -v.B ≤ v.A-v.k*g) :
    let K := v.A-v.k*g
    let b := 1+v.B/K
    let c := 1+v.V/v.d
    b ∈ Set.Icc 0 1 ∧ c ∈ Set.Icc 0 1 ∧ realization K v.k v.d g b c = v := by
  rcases hv with ⟨hk,hd,hA,hBA,hB0,hVd,hV0⟩
  dsimp only
  have hd' := ne_of_gt hd
  have hK' := ne_of_gt hK
  refine ⟨⟨?_,?_⟩,⟨?_,?_⟩,?_⟩
  · have H : -1 ≤ v.B / (v.A - v.k*g) :=
      (le_div_iff₀ hK).2 (by linarith)
    linarith
  · linarith [div_nonpos_of_nonpos_of_nonneg hB0 hK.le]
  · have H : -1 ≤ v.V / v.d := (le_div_iff₀ hd).2 (by linarith)
    linarith
  · linarith [div_nonpos_of_nonpos_of_nonneg hV0 hd.le]
  · apply Digital.ext <;> dsimp [realization] <;> field_simp [hK', hd']

/-- Theorem 3.1. Equality is coefficient equality in both channels, including the
chosen pole in a nonminimal representation. -/
theorem positive_membership_iff {α : ℝ} (hα : α < 1) (q : Channels) :
    PositiveRealization α q ↔ q.r.atOne = q.y.atOne ∧ (decode α q).Admissible := by
  constructor
  · rintro ⟨K,k,d,g,b,c,hK,hk,hd,hg,hb,hc,rfl⟩
    rw [decode_channels α hα]
    exact ⟨dc_equal _ _, realization_admissible hK hk hd hg hb hc⟩
  · rintro ⟨he,hv⟩
    let v := decode α q
    have hA : 0 < v.A := hv.2.2.1
    have hB : -v.B ≤ v.A := by linarith [hv.2.2.2.1]
    obtain ⟨hb,hc,hm⟩ := realize_at_integral_weight v hv 0 (by simpa using hA)
      (by simpa using hB)
    simp only [mul_zero,sub_zero] at hb hc hm
    refine ⟨v.A,v.k,v.d,0,1+v.B/v.A,1+v.V/v.d,hA,hv.1,hv.2.1,?_,hb,hc,?_⟩
    · constructor <;> norm_num
    · rw [hm]
      exact channels_decode α hα q he

/-- Physical time constants (12b) reproduce (5), for every allowed derivative weight. -/
theorem physical_parameters {K k d h α gD : ℝ}
    (hK : 0 < K) (hk : 0 < k) (hd : 0 < d) (hh : 0 < h)
    (hα : α < 1) (hg : gD < 1/(1-α)) :
    let Ti := K*h/k
    let Td := d*h/(K*(1-α))
    let Tf := h*(1/(1-α)-gD)
    0 < Ti ∧ 0 < Td ∧ 0 < Tf ∧ K*h/Ti = k ∧
      1-h/(Tf+gD*h) = α ∧ K*Td/(Tf+gD*h) = d := by
  have h1 : 0 < 1-α := by linarith
  have hden : h*(1/(1-α)-gD)+gD*h = h/(1-α) := by ring
  dsimp only
  rw [hden]
  refine ⟨by positivity, by positivity, mul_pos hh (sub_pos.mpr hg), ?_, ?_, ?_⟩ <;>
    field_simp [ne_of_gt hK,ne_of_gt hk,ne_of_gt hh,ne_of_gt h1]
  ring

/-- Conversely every strictly positive physical realization obeys the
inverse parameter equations and derivative-weight restriction (11b)–(12). -/
theorem physical_inverse {K k d h α gD Ti Td Tf : ℝ}
    (hK : 0 < K) (hh : 0 < h) (hTi : 0 < Ti) (hTd : 0 < Td)
    (hTf : 0 < Tf) (hgD : 0 ≤ gD)
    (hk : k=K*h/Ti) (hd : d=K*Td/(Tf+gD*h)) (hα : α=1-h/(Tf+gD*h)) :
    0 < k ∧ 0 < d ∧ α<1 ∧ gD < 1/(1-α) ∧
    Ti=K*h/k ∧ Td=d*h/(K*(1-α)) ∧ Tf=h*(1/(1-α)-gD) := by
  have hs : 0 < Tf+gD*h := add_pos_of_pos_of_nonneg hTf (mul_nonneg hgD hh.le)
  have Hk : 0 < k := by rw [hk]; exact div_pos (mul_pos hK hh) hTi
  have Hd : 0 < d := by rw [hd]; exact div_pos (mul_pos hK hTd) hs
  have Hα : 0 < 1-α := by rw [hα]; linarith [div_pos hh hs]
  have hA : (1-α)*(Tf+gD*h) = h := by rw [hα]; field_simp [ne_of_gt hs]
  have hi : 1/(1-α)=(Tf+gD*h)/h := by
    field_simp [ne_of_gt Hα,ne_of_gt hh]
    nlinarith
  refine ⟨Hk,Hd,by linarith,?_,?_,?_,?_⟩
  · rw [hi]
    apply (lt_div_iff₀ hh).2
    linarith
  · apply (eq_div_iff (ne_of_gt Hk)).2
    have := (eq_div_iff (ne_of_gt hTi)).1 hk
    linarith only [mul_comm Ti k,this]
  · apply (eq_div_iff (ne_of_gt (mul_pos hK Hα))).2
    have hd' := (eq_div_iff (ne_of_gt hs)).1 hd
    linear_combination d*hA - (1-α)*hd'
  · rw [hi]
    field_simp [ne_of_gt hh]
    ring

/-- Coefficient uniqueness recovers each free weight and its two setpoint
weights from any realization with positive coefficients. -/
theorem branch_inverse {K k d g b c α : ℝ} (hα : α<1) (hK : 0<K) (hd : 0<d) :
    let v := decode α (channels α (realization K k d g b c))
    K=v.A-v.k*g ∧ b=1+v.B/K ∧ c=1+v.V/v.d := by
  dsimp only
  rw [decode_channels α hα]
  dsimp [realization]
  constructor
  · ring
  · constructor <;> field_simp [ne_of_gt hK,ne_of_gt hd]

/-- Polynomial identity (21), with the delay symbol as an indeterminate. -/
theorem residual_identity {a b₀ b₁ η f t ζ α w U Y R : ℝ}
    (ht : t + ζ*(b₀+b₁) = 1) (hα : α = -ζ*b₁) :
    (1-w)*(1-α*w)*U - η*R + ((f+ζ)-a*ζ*w)*Y =
    ((1-t*w)*U-η*R+f*Y) + ζ*((1-a*w)*Y-w*(b₀+b₁*w)*U) := by
  rw [hα]
  linear_combination (w*U)*ht

/-- The causal form of (21), including arbitrary nonzero histories. -/
theorem sample_residual {a b₀ b₁ η f t ζ α u v vprev y yp r : ℝ}
    (ht : t+ζ*(b₀+b₁)=1) (hα : α = -ζ*b₁) :
    u-(1+α)*v+α*vprev-η*r+(f+ζ)*y-a*ζ*yp =
      u-η*r+f*y-t*v + ζ*(y-a*yp-b₀*v-b₁*vprev) := by
  rw [hα]
  linear_combination v*ht

/-- The two controller difference equations define identical behavior on the nominal plant.
The free `k` indexes triples of compatible history entries, including sample zero. -/
theorem nominal_trajectories {a b₀ b₁ η f t ζ α : ℝ}
    (ht : t+ζ*(b₀+b₁)=1) (hα : α = -ζ*b₁)
    (u v vp y yp r : ℕ → ℝ)
    (plant : ∀ k, y k = a*yp k+b₀*v k+b₁*vp k) :
    (∀ k, u k-(1+α)*v k+α*vp k-η*r k+(f+ζ)*y k-a*ζ*yp k=0) ↔
    ∀ k, u k=η*r k-f*y k+t*v k := by
  have E (k : ℕ) : u k-(1+α)*v k+α*vp k-η*r k+(f+ζ)*y k-a*ζ*yp k =
      u k-η*r k+f*y k-t*v k := by
    rw [sample_residual ht hα, plant k]
    ring
  constructor
  · intro H k
    have Hk := H k
    rw [E k] at Hk
    linarith
  · intro H k
    rw [E k,H k]
    ring

/-- Independent PID and MPC loops with identical compatible prehistories give the
same samples. Index 0 of `y` denotes the previous output, and indices 0,1 of
`u` are the two previous commands. -/
theorem separate_loops_equal {a b₀ b₁ η f t ζ α : ℝ}
    (ht : t+ζ*(b₀+b₁)=1) (hα : α = -ζ*b₁)
    (uP uM yP yM r : ℕ → ℝ)
    (plantP : ∀ k, yP (k+1)=a*yP k+b₀*uP (k+1)+b₁*uP k)
    (plantM : ∀ k, yM (k+1)=a*yM k+b₀*uM (k+1)+b₁*uM k)
    (pid : ∀ k, uP (k+2)-(1+α)*uP (k+1)+α*uP k-η*r k+
      (f+ζ)*yP (k+1)-a*ζ*yP k=0)
    (mpc : ∀ k, uM (k+2)=η*r k-f*yM (k+1)+t*uM (k+1))
    (hy0 : yP 0=yM 0) (hu0 : uP 0=uM 0) (hu1 : uP 1=uM 1) :
    ∀ k, yP k=yM k ∧ uP k=uM k ∧ uP (k+1)=uM (k+1) := by
  have law := (nominal_trajectories ht hα (fun k => uP (k+2))
    (fun k => uP (k+1)) uP (fun k => yP (k+1)) yP r plantP).mp pid
  intro k
  induction k with
  | zero => exact ⟨hy0,hu0,hu1⟩
  | succ k ih =>
    have hy : yP (k+1)=yM (k+1) := by
      rw [plantP,plantM,ih.1,ih.2.2,ih.2.1]
    have hu : uP (k+2)=uM (k+2) := by
      rw [law,mpc,hy,ih.2.2]
    exact ⟨hy,ih.2.2,hu⟩

def target (_α a f ζ η : ℝ) : Channels := ⟨⟨f+ζ,-a*ζ,0⟩,⟨η,0,0⟩⟩

theorem target_has_positive_realization {α a f ζ η : ℝ} (ha : 0 ≤ a)
    (hη : 0 < η) (hζ : 0 < ζ) (hα : α < 0)
    (he : η=f+ζ*(1-a)) : PositiveRealization α (target α a f ζ η) := by
  have hα1 : α < 1 := by linarith
  have h1 : 0 < 1-α := by linarith
  have hn : 1-α ≠ 0 := ne_of_gt h1
  let v := decode α (target α a f ζ η)
  have hk : v.k = η/(1-α) := by
    dsimp [v,decode,target,Coeff.atOne]
    rw [he]
    ring
  have hfd : 0 < f+ζ := by nlinarith [mul_nonneg ha hζ.le]
  have hD : v.d = (α^2*(f+ζ)-α*a*ζ)/(1-α)^2 := by
    dsimp [v,decode,target]
    ring
  have hd : 0 < v.d := by
    rw [hD]
    have hx : 0 < α^2*(f+ζ) := mul_pos (sq_pos_of_ne_zero (ne_of_lt hα)) hfd
    have hy : α*a*ζ ≤ 0 := mul_nonpos_of_nonpos_of_nonneg
      (mul_nonpos_of_nonpos_of_nonneg hα.le ha) hζ.le
    exact div_pos (by linarith) (sq_pos_of_pos h1)
  have hBB : v.B = -(a*ζ)/(1-α) := by
    dsimp [v,decode,target]
    rw [he]
    ring
  have hVV : v.V = α*a*ζ/(1-α) := by
    dsimp [v,decode,target]
    rw [he]
    ring
  have hsum : v.A+v.B = η*(1-2*α)/(1-α)^2 := by
    dsimp [v,decode,target,Coeff.atOne]
    rw [he]
    field_simp [hn]
    ring
  have hsum' : v.d+v.V = α^2*η/(1-α)^2 := by
    rw [hD,hVV,he]
    field_simp [hn]
    ring
  have hb : v.B ≤ 0 := by
    rw [hBB]
    exact div_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr (mul_nonneg ha hζ.le)) h1.le
  have hc : v.V ≤ 0 := by
    rw [hVV]
    exact div_nonpos_of_nonpos_of_nonneg
      (mul_nonpos_of_nonpos_of_nonneg (mul_nonpos_of_nonpos_of_nonneg hα.le ha) hζ.le) h1.le
  have hab : 0 < v.A+v.B := by
    rw [hsum]
    exact div_pos (mul_pos hη (by linarith)) (sq_pos_of_pos h1)
  have hdv : 0 ≤ v.d+v.V := by rw [hsum']; positivity
  apply (positive_membership_iff hα1 _).2
  refine ⟨?_,?_⟩
  · dsimp [target,Coeff.atOne]
    nlinarith
  · change v.Admissible
    exact ⟨by rw [hk]; exact div_pos hη h1,hd,by linarith,by linarith,hb,by linarith,hc⟩

/-- Evaluation of the reconstructed channel numerators coincides with the
branch sum of the integral, proportional and filtered derivative components. -/
theorem branch_channels (K k d g b c α w : ℝ) :
    let q := channels α (realization K k d g b c)
    let yi := k*(g+(1-g)*w)*(1-α*w)
    q.y.c0+q.y.c1*w+q.y.c2*w^2 =
      K*(1-w)*(1-α*w)+yi+d*(1-w)^2 ∧
    q.r.c0+q.r.c1*w+q.r.c2*w^2 =
      K*b*(1-w)*(1-α*w)+yi+d*c*(1-w)^2 := by
  dsimp [channels,realization]
  constructor <;> ring

/-- Eliminating the branch states from two consecutive updates (2a–f)
recovers both coefficient channels for arbitrary signals and branch memories. -/
theorem branch_update_difference (K k d g b c α i₀ df₀ r₀ r₁ r₂ y₀ y₁ y₂ : ℝ) :
    let i₁ := i₀+k*(g*(r₁-y₁)+(1-g)*(r₀-y₀))
    let i₂ := i₁+k*(g*(r₂-y₂)+(1-g)*(r₁-y₁))
    let df₁ := α*df₀+d*((c*r₁-y₁)-(c*r₀-y₀))
    let df₂ := α*df₁+d*((c*r₂-y₂)-(c*r₁-y₁))
    let u₀ := K*(b*r₀-y₀)+i₀+df₀
    let u₁ := K*(b*r₁-y₁)+i₁+df₁
    let u₂ := K*(b*r₂-y₂)+i₂+df₂
    let q := channels α (realization K k d g b c)
    u₂-(1+α)*u₁+α*u₀ =
      q.r.c0*r₂+q.r.c1*r₁+q.r.c2*r₀-(q.y.c0*y₂+q.y.c1*y₁+q.y.c2*y₀) := by
  dsimp [channels,realization]
  ring

/-- Each integral discretization weight in the unit interval yields admissible
physical gains for the nominal matching construction (Theorem 4.2). -/
theorem target_all_integral_weights {α a f ζ η g : ℝ}
    (ha : 0 ≤ a) (hη : 0 < η) (hζ : 0 < ζ) (hα : α < 0)
    (he : η=f+ζ*(1-a)) (hg : g ∈ Set.Icc 0 1) :
    let q := target α a f ζ η
    let v := decode α q
    let K := v.A-v.k*g
    let b := 1+v.B/K
    let c := 1+v.V/v.d
    0 < K ∧ 0 < v.k ∧ 0 < v.d ∧ b ∈ Set.Icc 0 1 ∧ c ∈ Set.Icc 0 1 ∧
      channels α (realization K v.k v.d g b c) = q := by
  let q := target α a f ζ η
  let v := decode α q
  have hα1 : α<1 := by linarith
  have h1 : 0<1-α := by linarith
  obtain ⟨hdc,hv⟩ := (positive_membership_iff hα1 q).1
    (target_has_positive_realization ha hη hζ hα he)
  change v.Admissible at hv
  have haB : v.A+v.B-v.k = (-α)*η/(1-α)^2 := by
    dsimp [v,q,decode,target,Coeff.atOne]
    rw [he]
    field_simp [ne_of_gt h1]
    ring
  have hl : 0 < v.A+v.B-v.k := by
    rw [haB]
    exact div_pos (mul_pos (neg_pos.mpr hα) hη) (sq_pos_of_pos h1)
  have hkg : v.k*g ≤ v.k := by
    simpa using mul_le_mul_of_nonneg_left hg.2 hv.1.le
  have hK : 0 < v.A-v.k*g := by linarith [hv.2.2.2.2.1]
  have hB : -v.B ≤ v.A-v.k*g := by linarith
  obtain ⟨hb,hc,hr⟩ := realize_at_integral_weight v hv g hK hB
  exact ⟨hK,hv.1,hv.2.1,hb,hc,by rw [hr]; exact channels_decode α hα1 q hdc⟩

/-- Theorem 4.2 with a common initialization for two independently run loops.
The raw PID law is the coefficient law constructed by the membership theorem. -/
theorem constructive_nominal_matching {a b₀ b₁ η f t ζ : ℝ}
    (ha : 0 ≤ a) (hζ : 0 < ζ) (hη : 0 < η) (hb₁ : 0 < b₁)
    (hm : ζ*b₁ < 1) (he : η=f+ζ*(1-a)) (ht : t+ζ*(b₀+b₁)=1) :
    let α := -ζ*b₁
    (-1 < α ∧ α < 1) ∧ PositiveRealization α (target α a f ζ η) ∧
    ∀ (uP uM yP yM r : ℕ → ℝ),
      (∀ k, yP (k+1)=a*yP k+b₀*uP (k+1)+b₁*uP k) →
      (∀ k, yM (k+1)=a*yM k+b₀*uM (k+1)+b₁*uM k) →
      (∀ k, uP (k+2)-(1+α)*uP (k+1)+α*uP k-η*r k+
          (f+ζ)*yP (k+1)-a*ζ*yP k=0) →
      (∀ k, uM (k+2)=η*r k-f*yM (k+1)+t*uM (k+1)) →
      yP 0=yM 0 → uP 0=uM 0 → uP 1=uM 1 →
      ∀ k, yP k=yM k ∧ uP k=uM k ∧ uP (k+1)=uM (k+1) := by
  dsimp only
  have hneg : -ζ*b₁<0 := mul_neg_of_neg_of_pos (neg_neg_of_pos hζ) hb₁
  exact ⟨⟨by linarith,by linarith⟩,target_has_positive_realization ha hη hζ hneg he,
    fun uP uM yP yM r => separate_loops_equal ht rfl uP uM yP yM r⟩

/-- Disturbance discrepancy (37) sample by sample, before closing the second loop. -/
theorem disturbed_move {a b₀ b₁ η f t ζ α u v vp y yp r ν : ℝ}
    (ht : t+ζ*(b₀+b₁)=1) (hα : α = -ζ*b₁)
    (plant : y=a*yp+b₀*v+b₁*vp+ν)
    (pid : u-(1+α)*v+α*vp-η*r+(f+ζ)*y-a*ζ*yp=0) :
    u-η*r+f*y-t*v = -ζ*ν := by
  rw [sample_residual ht hα] at pid
  have E : y-a*yp-b₀*v-b₁*vp=ν := by linarith
  rw [E] at pid
  linarith

/-- Polynomial reduction in (104)–(105), at every complex argument. -/
theorem closed_loop_factor {a b₀ b₁ f t ζ α : ℂ} (z : ℂ)
    (ht : t+ζ*(b₀+b₁)=1) (hα : α = -ζ*b₁) :
    z^3*(z*(z-a)*(z-1)*(z-α) + (b₀*z+b₁)*((f+ζ)*z^2-a*ζ*z)) =
    z^5*(z^2-(a+t-b₀*f)*z+(a*t+b₁*f)) := by
  rw [hα]
  linear_combination z^5*(z-a)*ht

/-- Zero modes cannot alter the open-unit-disk stability of the target. -/
theorem zero_modes_schur (q : ℂ → ℂ) :
    (∀ z : ℂ, z^5 * q z = 0 → ‖z‖ < 1) ↔ (∀ z : ℂ, q z = 0 → ‖z‖ < 1) := by
  constructor
  · intro h z hz
    apply h
    rw [hz,mul_zero]
  · intro h z hz
    rcases mul_eq_zero.mp hz with hz | hz
    · have : z = 0 := by simpa using hz
      simp [this]
    · exact h z hz


private theorem real_pair_jury (u v : ℝ) :
    (|u| < 1 ∧ |v| < 1) ↔
    0 < (1-u)*(1-v) ∧ 0 < (1+u)*(1+v) ∧ u*v < 1 := by
  constructor
  · rintro ⟨hu,hv⟩
    rcases abs_lt.mp hu with ⟨hum,hup⟩
    rcases abs_lt.mp hv with ⟨hvm,hvp⟩
    refine ⟨mul_pos (by linarith) (by linarith),mul_pos (by linarith) (by linarith),?_⟩
    have p : 0 < (1-u)*(1+v) := mul_pos (by linarith) (by linarith)
    have q : 0 < (1+u)*(1-v) := mul_pos (by linarith) (by linarith)
    nlinarith
  · rintro ⟨hp,hm,hd⟩
    rcases mul_pos_iff.mp hp with hp | hp
    · rcases mul_pos_iff.mp hm with hm | hm
      · exact ⟨abs_lt.mpr ⟨by linarith [hm.1], by linarith [hp.1]⟩,
          abs_lt.mpr ⟨by linarith [hm.2], by linarith [hp.2]⟩⟩
      · rcases hm with ⟨hu,hv⟩
        nlinarith [mul_nonneg_of_nonpos_of_nonpos hu.le hv.le]
    · rcases hp with ⟨hu,hv⟩
      nlinarith [mul_nonneg_of_nonpos_of_nonpos hu.le hv.le]

private theorem root_components {τ δ : ℝ} {z : ℂ}
    (hz : z^2-(τ:ℂ)*z+(δ:ℂ)=0) :
    z.re^2-z.im^2-τ*z.re+δ=0 ∧ (2*z.re-τ)*z.im=0 := by
  have hr := congrArg Complex.re hz
  have hi := congrArg Complex.im hz
  simp [pow_two,Complex.mul_re] at hr
  simp [pow_two,Complex.mul_im] at hi
  constructor <;> nlinarith

private theorem norm_sq_coordinates (z : ℂ) : ‖z‖^2 = z.re^2+z.im^2 := by
  rw [Complex.sq_norm, Complex.normSq_apply]
  ring

/-- The second-order strict Jury test, including repeated roots and nonreal pairs. -/
theorem quadratic_schur_iff (τ δ : ℝ) :
    (∀ z : ℂ, z^2-(τ:ℂ)*z+(δ:ℂ)=0 → ‖z‖<1) ↔
    0 < 1-τ+δ ∧ 0 < 1+τ+δ ∧ 0 < 1-δ := by
  constructor
  · intro hall
    have hsquare : ∃ s : ℂ, s^2=(τ:ℂ)^2-4*(δ:ℂ) := by
      by_cases hd : 0 ≤ τ^2-4*δ
      · exact ⟨(Real.sqrt (τ^2-4*δ) : ℝ), by exact_mod_cast Real.sq_sqrt hd⟩
      · refine ⟨Complex.I*(Real.sqrt (4*δ-τ^2) : ℝ),?_⟩
        rw [mul_pow,Complex.I_sq,← Complex.ofReal_pow,Real.sq_sqrt (by linarith)]
        push_cast
        ring
    obtain ⟨s,hs⟩ := hsquare
    let z : ℂ := ((τ:ℂ)+s)/2
    have hz : z^2-(τ:ℂ)*z+(δ:ℂ)=0 := by
      dsimp [z]
      linear_combination hs/4
    have h := hall z hz
    obtain ⟨hr,hi⟩ := root_components hz
    by_cases hz0 : z.im=0
    · have h1 : z = (z.re:ℂ) := by apply Complex.ext <;> simp [hz0]
      have hu : |z.re| < 1 := calc
        |z.re| = ‖(z.re:ℂ)‖ := by simp
        _ = ‖z‖ := congrArg _ h1.symm
        _ < 1 := h
      let v := τ-z.re
      have hv0 : v^2-τ*v+δ=0 := by dsimp [v]; rw [hz0] at hr; nlinarith
      have hvC : (v:ℂ)^2-(τ:ℂ)*v+(δ:ℂ)=0 := by exact_mod_cast hv0
      have hv : |v|<1 := by simpa using hall (v:ℂ) hvC
      obtain ⟨hp,hm,hd⟩ := (real_pair_jury _ _).mp ⟨hu,hv⟩
      dsimp [v] at hp hm hd
      rw [hz0] at hr
      exact ⟨by nlinarith,by nlinarith,by nlinarith⟩
    · have hτ := (mul_eq_zero.mp hi).resolve_right hz0
      have hsqi := sq_pos_of_ne_zero hz0
      have hns := norm_sq_coordinates z
      have hpos : 0 < (1-‖z‖)*(1+‖z‖) := mul_pos (by linarith) (by positivity)
      have hδ : δ=z.re^2+z.im^2 := by
        have hτ' : τ=2*z.re := by linarith
        rw [hτ'] at hr
        nlinarith
      exact ⟨by nlinarith [sq_nonneg (1-z.re)],by nlinarith [sq_nonneg (1+z.re)],by nlinarith⟩
  · rintro ⟨hp,hm,hd⟩ z hz
    obtain ⟨hr,hi⟩ := root_components hz
    have hn := norm_sq_coordinates z
    by_cases hz0 : z.im=0
    · rw [hz0] at hr hn
      have habs := (real_pair_jury z.re (τ-z.re)).mpr ⟨by nlinarith,by nlinarith,by nlinarith⟩
      rcases abs_lt.mp habs.1 with ⟨hl,hu⟩
      have hpos : 0 < (1-z.re)*(1+z.re) := mul_pos (by linarith) (by linarith)
      nlinarith [sq_nonneg (‖z‖-1)]
    · have hτ := (mul_eq_zero.mp hi).resolve_right hz0
      have hτ' : τ=2*z.re := by linarith
      rw [hτ'] at hr
      nlinarith [sq_nonneg (‖z‖-1)]
/-- The one-step increment-penalty QP (26); exact strong convexity gap. -/
theorem quadratic_first_move {Q L b e v : ℝ} (hQ : 0 < Q) (hL : 0 < L) :
    let g := Q*b/(L+Q*b^2)
    Q*(e-b*v)^2+L*v^2 - (Q*(e-b*(g*e))^2+L*(g*e)^2) =
      (L+Q*b^2)*(v-g*e)^2 := by
  have hn : L+Q*b^2 ≠ 0 := ne_of_gt (by positivity)
  dsimp only
  field_simp [hn]
  ring

/-- The three real Schur inequalities for the one-step law, in the gain domain (28). -/
theorem one_step_jury {a b₀ b₁ g : ℝ} (ha : 0 ≤ a) (ha1 : a < 1)
    (hb₀ : 0 < b₀) (hb₁ : 0 < b₁) (hg : 0 < g)
    (hg₀ : g*b₀ < 1) (hg₁ : g*b₁ < 1) :
    let μ := 1-g*b₀
    let t := 1-g*(b₀+b₁)
    let τ := a*μ+t
    let δ := a*μ
    0 < 1-τ+δ ∧ 0 < 1+τ+δ ∧ 0 < 1-δ := by
  dsimp only
  have hpos := mul_nonneg ha (sub_nonneg.mpr hg₀.le)
  have H : a*(1-g*b₀) ≤ a := by nlinarith [mul_nonneg ha (mul_nonneg hg.le hb₀.le)]
  refine ⟨?_,?_,?_⟩ <;> nlinarith [mul_pos hg hb₀, mul_pos hg hb₁]

/-- Equations (27)–(32) give the positive PID and open-disk spectrum
directly from the one-step tracking and move-penalty weights. -/
theorem quadratic_mpc_one_step {a b₀ b₁ Q L : ℝ} (ha : 0≤a) (ha1 : a<1)
    (hb₀ : 0<b₀) (hb₁ : 0<b₁) (hQ : 0<Q) (hL : 0<L)
    (hm : (Q*b₀/(L+Q*b₀^2))*b₁ < 1) :
    let g := Q*b₀/(L+Q*b₀^2)
    let t := 1-g*(b₀+b₁)
    let μ := 1-g*b₀
    let τ := a*μ+t
    let δ := a*μ
    PositiveRealization (-g*b₁) (target (-g*b₁) a (g*a) g g) ∧
      ∀ z : ℂ, z^2-(τ:ℂ)*z+(δ:ℂ)=0 → ‖z‖<1 := by
  let g := Q*b₀/(L+Q*b₀^2)
  have hden : 0<L+Q*b₀^2 := by positivity
  have hg : 0<g := div_pos (mul_pos hQ hb₀) hden
  have hg₀ : g*b₀<1 := by
    dsimp [g]
    rw [div_mul_eq_mul_div, div_lt_one hden]
    nlinarith
  refine ⟨target_has_positive_realization ha hg hg
    (mul_neg_of_neg_of_pos (neg_neg_of_pos hg) hb₁) (by ring),?_⟩
  exact (quadratic_schur_iff _ _).2 (one_step_jury ha ha1 hb₀ hb₁ hg hg₀ hm)

/-- Appendix D, both PI channel numerators, including the endpoint γ=1 when a>0. -/
theorem pi_boundary {a g γ : ℝ} (_hg : 0 < g) (hγ : 0 < 1+a-γ) (w : ℝ) :
    let K := g*(1+a-γ)
    let b := (1-γ)/(1+a-γ)
    K*(1-w)+g*(γ+(1-γ)*w) = g*((1+a)-a*w) ∧
      K*b*(1-w)+g*(γ+(1-γ)*w) = g := by
  dsimp only
  constructor
  · ring
  · field_simp [ne_of_gt hγ]
    ring

end
end MPCPID.Matching
