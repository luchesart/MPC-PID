import MPCPID.NominalLiftBridge
import MPCPID.PeriodicNominal
import MPCPID.EquilibriumResponse
import MPCPID.GainReserve

/-! Detectability at a designated exit phase of a finite dimensional periodic
target. Every nonzero step response there has a finite positive-lag impulse
witness there, provided the direct output feedthrough vanishes. -/
namespace MPCPID.PeriodicExcitation
open PhysicalLift PhysicalSchedule Periodic NominalLiftBridge PhaseCorrection
open NominalColumns (pulse)
noncomputable section

def atPulse {t : ℕ} (X : ℕ → System ℝ t 1 2) (s l : ℕ) :=
  outputAt (fun k => X (s+k)) pulse l

def Y {t : ℕ} (X : ℕ → System ℝ t 1 2) (s l : ℕ) := atPulse X s l 0 0
def U {t : ℕ} (X : ℕ → System ℝ t 1 2) (s l : ℕ) := atPulse X s l 1 0

/-- Keep just the true-output channel at one designated exit phase. -/
def row {t : ℕ} (X : ℕ → System ℝ t 1 2) (H p k : ℕ) : Mat 1 t :=
  if k%H=p then (fun _ j => (X k).C 0 j) else 0

private theorem scalar_one : scalar (1:ℝ) = (1 : Mat 1 1) := by
  ext i j
  fin_cases i; fin_cases j; simp [scalar]

theorem pulse_zero {t : ℕ} (X : ℕ → System ℝ t 1 2) (s : ℕ) :
    atPulse X s 0 = (X s).D := by
  simp [atPulse,outputAt,state,frameState,pulse,scalar_one]

theorem pulse_succ {t : ℕ} (X : ℕ → System ℝ t 1 2) (s k : ℕ) :
    atPulse X s (k+1) = (X (s+1+k)).C * trans (fun j => (X j).A) (s+1) k * (X s).B := by
  have zero (k : ℕ) : scalar (pulse (k+1)) = (0 : Mat 1 1) := by ext i j; simp [scalar,pulse]
  have st (j : ℕ) : state (fun k => X (s+k)) pulse (j+1) =
      trans (fun k => (X k).A) (s+1) j * (X s).B := by
    induction j with
    | zero => simp [state,frameState,pulse,scalar_one,PhaseCorrection.trans]
    | succ j ih =>
      change (X (s+(j+1))).A * state (fun k => X (s+k)) pulse (j+1) +
          (X (s+(j+1))).B * scalar (pulse (j+1)) = _
      rw [ih,zero,Matrix.mul_zero,add_zero,PhaseCorrection.trans,Matrix.mul_assoc,
        show s+(j+1)=s+1+j by omega]
  simp only [atPulse,outputAt,st,zero,Matrix.mul_zero,add_zero,Matrix.mul_assoc,
    show s+(k+1)=s+1+k by omega]

private theorem earlier_origin {H p s l : ℕ} (hH : 0<H) (hp : (s+l)%H=p) (hs : s<H) :
    PeriodicNominal.origin H p l = s := by
  have hbase : (s+l)%H = (p+l*(H-1)+l)%H := by
    have plus : p+l*(H-1)+l = p+l*H := by
      obtain ⟨u,rfl⟩ := Nat.exists_eq_succ_of_ne_zero hH.ne'
      simp [Nat.mul_succ,Nat.add_assoc]
    rw [plus,Nat.add_mod p (l*H),Nat.mod_eq_zero_of_dvd (dvd_mul_left H l)]
    have hpeq : p%H=p := (hp ▸ Nat.mod_mod (s+l) H)
    simpa [hpeq] using hp
  have cancel := Nat.ModEq.add_right_cancel' l (show Nat.ModEq H (s+l) ((p+l*(H-1))+l) from hbase)
  exact (show s%H = (p+l*(H-1))%H from cancel).symm.trans (Nat.mod_eq_of_lt hs)

private theorem step_state {t : ℕ} (X : ℕ → System ℝ t 1 2) (s : ℕ) :
    state X (fun _ => 1) s =
    response (fun k => (X k).A) (fun k => (X k).B) (fun _ => 1) s := by
  induction s with
  | zero => rfl
  | succ s ih =>
    change (X s).A * state X _ s + (X s).B * scalar 1 = _
    rw [ih,scalar_one,Matrix.mul_one,response,one_smul]

/-- For a period-H target of dimension t, the first H*t positive lags
suffice at a specified exit phase. Launch phases may depend on lag. -/
theorem finite_exit_lag {t H : ℕ} (hH : 0<H) (X : ℕ → System ℝ t 1 2)
    (hX : ∀ k, X (k+H)=X k) (p : Fin H) (direct : ∀ k, k%H=p → (X k).D 0 0 = 0)
    (step : ∃ N, N%H=p ∧ (outputAt X (fun _ => 1) N) 0 0 ≠ 0) :
    ∃ l, 0<l ∧ l≤H*t ∧ Y X (PeriodicNominal.origin H p l) l ≠ 0 := by
  classical
  by_contra! no
  let A := fun j => (X j).A
  let B := fun j => (X j).B
  let C := row X H p
  have hA (k : ℕ) : A (k+H) = A k := congrArg System.A (hX k)
  have hB (k : ℕ) : B (k+H) = B k := congrArg System.B (hX k)
  have hC (k : ℕ) : C (k+H) = C k := by simp [C,row,hX,Nat.add_mod]
  have sig (s : Fin H) (j : Fin t) (k : Fin H) : signature A C s (B s) j k = 0 := by
    let l := 1+(j:ℕ)*H+k
    have hl : l ≤ H*t := by
      have ub := Nat.mul_le_mul_right H (Nat.succ_le_of_lt j.isLt)
      simp only [Nat.succ_mul] at ub
      dsimp [l]
      rw [Nat.mul_comm H t]
      omega
    by_cases hit : ((s:ℕ)+1+k)%H=p
    · have eqphase : ((s:ℕ)+l)%H=p := by
        change ((s:ℕ)+(1+(j:ℕ)*H+k))%H=p
        rw [show (s:ℕ)+(1+(j:ℕ)*H+k) = (s.val+1+k)+j.val*H by omega,
          Nat.add_mod, Nat.mod_eq_zero_of_dvd (dvd_mul_left H _)]
        simpa using hit
      have hzero := no l (by dsimp [l]; omega) hl
      rw [earlier_origin hH eqphase s.isLt] at hzero
      have hrep : l = (j.val*H+k.val)+1 := by dsimp [l]; omega
      rw [Y,hrep,pulse_succ] at hzero
      have hx : X (s.val+1+(j.val*H+k.val)) = X (s.val+1+k.val) := by
        rw [show s.val+1+(j.val*H+k.val)=(s.val+1+k.val)+j.val*H by omega,period_shift hX]
      rw [hx,trans_append,trans_shift hA,trans_frames hA] at hzero
      ext a b
      obtain rfl : a=0 := Subsingleton.elim _ _
      obtain rfl : b=0 := Subsingleton.elim _ _
      change (((if (s.val+1+k.val)%H=p then (fun (_ : Fin 1) v => (X (s.val+1+k.val)).C 0 v) else 0) :
          Mat 1 t) * trans A (s.val+1) k * trans A (s.val+1) H^j.val * B s) 0 0 = 0
      rw [if_pos hit]
      simpa only [Matrix.mul_assoc] using hzero
    · simp [signature,C,row,hit]
  obtain ⟨N,obs,hne⟩ := step
  apply hne
  have hzero := ((residual_finite_iff hH hA hC hB).1 sig) (fun _ => 1) N
  have val := congrArg (fun z : Mat 1 1 => z 0 0) hzero
  unfold outputAt
  rw [step_state, scalar_one,Matrix.mul_one]
  rw [Matrix.add_apply]
  rw [direct N obs,add_zero]
  simpa [C,row,obs] using val

private theorem mod_start {t H : ℕ} (X : ℕ → System ℝ t 1 2)
    (hX : ∀ k, X (k+H) = X k) (s : ℕ) :
    (fun j => X (s+j)) = fun j => X (s%H+j) := by
  funext j
  have e : s%H+s/H*H=s := by simpa [Nat.mul_comm] using Nat.mod_add_div s H
  calc
    X (s+j) = X ((s%H+j)+(s/H)*H) := congrArg X (by omega)
    _ = X (s%H+j) := period_shift hX _ _

/-- Actual equality for the physical nominal plant, independent of the
starting phase of each experiment. -/
theorem phase_matches {n t L H : ℕ} (s : Clocks L) (P : Plant ℝ n)
    (g : GainGraph.Coeff ℝ) (X : ℕ → System ℝ t 1 2) (hX : ∀ k, X (k+H)=X k)
    (hXL : ∀ k, X (k+L)=X k)
    (hm : MatchSys (physicalFrame P g s.flags L) (liftScalar X L)) (p k : ℕ) :
    let z := NominalExecution.closedRun s P g p k
    let z' := NominalExecution.closedRun s P g p (k+1)
    NominalExecution.measure P z.1 = Y X (p%H) k ∧ OperatorPhase.command z'.2 = U X (p%H) k := by
  let T := fun q => physicalPhase P g (s.flags q)
  have hT (j : ℕ) : T (j+L)=T j := congrArg (physicalPhase P g) (s.flags_periodic j)
  have he := all_base_outputs s.frame_pos hT hXL hm (delayed p) (p+k)
  rw [shift_output,shift_output] at he
  change outputAt (fun j => physicalPhase P g (s.flags (p+j))) pulse k =
    outputAt (fun j => X (p+j)) pulse k at he
  rw [physical_output,mod_start X hX p] at he
  exact ⟨congrArg (fun z : Mat 2 1 => z 0 0) he,congrArg (fun z : Mat 2 1 => z 1 0) he⟩

private theorem one_history (L q : ℕ) :
    history L (fun _ => 1) q = List.replicate q (NoZeroTarget.ones L) := by
  induction q with
  | zero => rfl
  | succ q ih => rw [history,ih,List.replicate_succ]; rfl

/-- Unconditional period cutoff for any feasible fixed finite-dimensional
periodic target, with no separate impulse-observability assumption. A common
frame accommodating its clocks always exists. -/
theorem feasible_periodic_cutoff {n t H L : ℕ} (hH : 0<H) (s : Clocks L)
    (hHL : H ∣ L) (P : Plant ℝ n) (X : ℕ → System ℝ t 1 2)
    (hX : ∀ k, X (k+H)=X k) (p : GainGraph.Physical) {h R : ℝ}
    (hh : 0<h) (hR : 1≤R)
    (fit : GainReserve.PhysicalAt P h R s (liftScalar X L) p) :
    ∀ j, NominalBound.periods s j ≤ 2*H^2*(max (H*t) (3*H))^2 := by
  let g := GainGraph.rational (s.TI h) (s.TD h) p
  obtain ⟨hp,hm,hr⟩ := fit
  have st := hr 1 ⟨le_rfl,hR⟩
  rw [GainReserve.scale_one] at st
  have hXL (k : ℕ) : X (k+L)=X k := by
    obtain ⟨a,ha⟩ := hHL
    rw [ha,Nat.mul_comm H a,period_shift hX]
  have trajectories (a k : ℕ) := phase_matches s P g X hX hXL hm a k
  have direct (a : ℕ) : (X a).D 0 0 = 0 := by
    have e := (trajectories a 0).1
    change (P.C.mulVec 0) 0 = Y X (a%H) 0 at e
    rw [Y,pulse_zero,Matrix.mulVec_zero] at e
    have hv := congrFun (mod_start X hX a) 0
    simp only [Nat.add_zero] at hv
    simpa [hv] using e.symm
  have nonzero (a : Fin H) : ∃ N, N%H = a ∧ (outputAt X (fun _ => 1) N) 0 0 ≠ 0 := by
    have HL : H≤L := Nat.le_of_dvd s.frame_pos hHL
    let j : Fin L := ⟨a,a.isLt.trans_le HL⟩
    obtain ⟨q,hq⟩ := EquilibriumResponse.every_matched_phase P g s.flags (liftScalar X L) st hm j
    refine ⟨q*L+a,?_,?_⟩
    · rw [Nat.add_mod,Nat.mod_eq_zero_of_dvd (dvd_mul_of_dvd_right hHL q),Nat.zero_add,
        Nat.mod_eq_of_lt a.isLt,Nat.mod_eq_of_lt a.isLt]
    · have obs := output_from_lift hXL (fun _ => 1) q j
      rw [one_history,←NoZeroTarget.blocksAt_advance] at obs
      intro hz
      apply hq
      exact (congrArg (fun z : Mat 2 1 => z 0 0) obs).symm.trans hz
  have matched (a k : ℕ) :
      NominalColumns.output s g (Y X (a%H)) a (k+1) = U X (a%H) k := by
    have loop (j : ℕ) : (NominalExecution.closedRun s P g a j).2 =
        OperatorPhase.run g (fun k => s.flags (a+k))
          (fun k => ![pulse k,Y X (a%H) k]) 0 j := by
      induction j with
      | zero => rfl
      | succ j ih =>
        change OperatorPhase.tick g _ ![pulse j,NominalExecution.measure P
          (NominalExecution.closedRun s P g a j).1] (NominalExecution.closedRun s P g a j).2 = _
        rw [(trajectories a j).1,ih]
        rfl
    have phys := (trajectories a k).2
    change OperatorPhase.command (NominalExecution.closedRun s P g a (k+1)).2 = _ at phys
    rw [loop,NominalExecution.operator_run] at phys
    exact phys
  apply PeriodicNominal.physical_periodic_cutoff hH s p h hh hp (Y X) (U X)
    (fun q => by rw [Y,pulse_zero,direct])
    (fun a => finite_exit_lag hH X hX a (fun k _ => direct k) (nonzero a)) matched

end
end MPCPID.PeriodicExcitation
