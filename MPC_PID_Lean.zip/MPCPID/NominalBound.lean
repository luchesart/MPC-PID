import MPCPID.ClockBound
import MPCPID.NominalColumns
import Mathlib.Tactic.FinCases

/-! A finite cutoff for unrestricted schedules of a nominal LTI target.
Only one nonzero positive-lag output impulse coefficient is required. -/
namespace MPCPID.NominalBound
open ClockBound NominalColumns PhysicalSchedule GainGraph
open scoped BigOperators
noncomputable section

def periods {L : ℕ} (s : Clocks L) : Triple := ![s.mP, s.mI, s.mD]
def phases {L : ℕ} (s : Clocks L) : Triple := ![s.φP, s.φI, s.φD]

theorem phase_bounds {L : ℕ} (s : Clocks L) (j : Fin 3) :
    phases s j < periods s j := by
  fin_cases j
  · exact s.phaseP
  · exact s.phaseI
  · exact s.phaseD

def col {L : ℕ} (s : Clocks L) (g : Coeff ℝ) (Y : ℕ → ℝ) (lag : ℕ) : Fin 3 → ℝ :=
  ![column (pStep g Y) s.mP lag,column (iStep g Y) s.mI lag,column (dStep g Y) s.mD lag]

def amps (g : Coeff ℝ) : Fin 3 → ℝ := ![g.K,g.i0,g.β]

theorem restricted_of_impulse {L d : ℕ} (s : Clocks L) (g : Coeff ℝ) (Y U : ℕ → ℝ)
    (hd : 0 < d) (hy : Y 0=0) (hn : Y d ≠ 0)
    (hK : 0 < g.K) (hb : 0 < g.β) (hi : 0 ≤ g.i0) (hiSum : 0 < g.i0+g.i1)
    (matchImpulse : ∀ start k, output s g Y start (k+1) = U k) :
    RestrictedRigid d (periods s) (phases s) := by
  classical
  let A := support (periods s) (phases s)
  have hcol (phase lag : ℕ) :
      ∑ j ∈ A phase, col s g Y lag j = diff U lag := by
    rw [phase_signature s g Y U matchImpulse phase lag]
    -- Write the three column contributions as a sum over the firing subset.
    dsimp only [A,support]
    rw [Finset.sum_filter]
    simp [periods,phases,col,Fin.sum_univ_succ,add_assoc]
  intro k l agree sub j hj
  by_cases member : j ∈ A k
  · exact (mem_support _ _ _ _).1 member
  exfalso
  have subset : A k ⊆ A l := fun i h => (mem_support ..).2 (sub i ((mem_support ..).1 h))
  let D := A l \ A k
  have dj : j ∈ D := Finset.mem_sdiff.mpr ⟨(mem_support ..).2 hj,member⟩
  have zeroSum (lag : ℕ) : ∑ i ∈ D, col s g Y lag i = 0 := by
    have h := Finset.sum_sdiff subset (f := col s g Y lag)
    change (∑ i ∈ A l \ A k, col s g Y lag i) = 0
    linarith [hcol k lag,hcol l lag]
  have slow {i} (h : i ∈ D) : d < periods s i := by
    obtain ⟨inl,nink⟩ := Finset.mem_sdiff.mp h
    by_contra! fast
    exact nink ((mem_support ..).2 ((agree i fast).2 ((mem_support ..).1 inl)))
  have hc {i} (h : i ∈ D) : col s g Y d i = amps g i * (-Y d) := by
    have H := slow_columns g Y hd (slow h)
    fin_cases i
    · simpa [col,amps] using H.1
    · simpa [col,amps] using H.2.1
    · simpa [col,amps] using H.2.2
  have scal : (∑ i ∈ D, amps g i) * (-Y d) = 0 := by
    rw [Finset.sum_mul]
    exact (Finset.sum_congr rfl (fun i h => (hc h).symm)).trans (zeroSum d)
  have van := (mul_eq_zero.mp scal).resolve_right (neg_ne_zero.mpr hn)
  have nonneg (i : Fin 3) : 0 ≤ amps g i := by
    fin_cases i
    · exact hK.le
    · exact hi
    · exact hb.le
  have each (i) (h : i ∈ D) : amps g i = 0 :=
    (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => nonneg i)).mp van i h
  have onlyI (i : Fin 3) (h : i ∈ D) : i = 1 := by
    have hz := each i h
    fin_cases i
    · exact False.elim (hK.ne' hz)
    · rfl
    · exact False.elim (hb.ne' hz)
  have Ds : D = {1} := by
    apply Finset.eq_singleton_iff_unique_mem.mpr
    exact ⟨(onlyI j dj) ▸ dj,onlyI⟩
  have hi0 : g.i0 = 0 := each 1 (Ds ▸ Finset.mem_singleton_self _)
  have hlast := zeroSum s.mI
  rw [Ds,Finset.sum_singleton] at hlast
  change column (iStep g Y) s.mI s.mI = 0 at hlast
  rw [integral_period_column g Y hy hi0 (Nat.zero_lt_of_lt s.phaseI)] at hlast
  linarith

theorem physical_restricted {L d : ℕ} (s : Clocks L) (p : Physical) (h : ℝ)
    (hh : 0 < h) (hp : Admissible p) (Y U : ℕ → ℝ)
    (hd : 0 < d) (hy : Y 0=0) (hn : Y d ≠ 0)
    (matchImpulse : ∀ start k, output s (rational (s.TI h) (s.TD h) p) Y start (k+1) = U k) :
    RestrictedRigid d (periods s) (phases s) := by
  rcases hp with ⟨hK,hTi,hTd,hTf,hI,hD,_,_⟩
  have ti : 0 < s.TI h := mul_pos (by exact_mod_cast Nat.zero_lt_of_lt s.phaseI) hh
  have td : 0 < s.TD h := mul_pos (by exact_mod_cast Nat.zero_lt_of_lt s.phaseD) hh
  have den := add_pos_of_pos_of_nonneg hTf (mul_nonneg hD.1 td.le)
  have kpos := div_pos (mul_pos hK ti) hTi
  have hr := restricted_of_impulse s (rational (s.TI h) (s.TD h) p) Y U hd hy hn hK
    (div_pos (mul_pos hK hTd) den) (mul_nonneg kpos.le hI.1)
    (by dsimp [rational]; linarith only [kpos]) matchImpulse
  exact hr

theorem physical_period_bound {L d : ℕ} (s : Clocks L) (p : Physical) (h : ℝ)
    (hh : 0 < h) (hp : Admissible p) (Y U : ℕ → ℝ)
    (hd : 0 < d) (hy : Y 0=0) (hn : Y d ≠ 0)
    (matchImpulse : ∀ start k, output s (rational (s.TI h) (s.TD h) p) Y start (k+1) = U k) :
    ∀ j, periods s j ≤ 2*(max d 3)^2 := by
  exact periods_le_lag_bound _ _ (phase_bounds s) (physical_restricted s p h hh hp Y U hd hy hn matchImpulse)

theorem physical_first_sample_bound {L : ℕ} (s : Clocks L) (p : Physical) (h : ℝ)
    (hh : 0 < h) (hp : Admissible p) (Y U : ℕ → ℝ)
    (hy : Y 0=0) (hn : Y 1 ≠ 0)
    (matchImpulse : ∀ start k, output s (rational (s.TI h) (s.TD h) p) Y start (k+1) = U k) :
    ∀ j, periods s j ≤ 4 := by
  exact periods_le_four_of_lag_one _ _ (phase_bounds s)
    (physical_restricted s p h hh hp Y U (by decide : 0 < 1) hy hn matchImpulse)

end
end MPCPID.NominalBound
