import Mathlib.Data.Real.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Ring

/-! Physical branch memory, the plant residual, and the maximal viable box. -/
namespace MPCPID.Conditioned

abbrev Signal := ℕ → ℝ

/-- Unit delay on signals measured from a compatible equilibrium. -/
def lag (x : Signal) : Signal
  | 0 => 0
  | n+1 => x n

def den (α : ℝ) (x : Signal) (n : ℕ) : ℝ :=
  x n - (1+α)*lag x n + α*lag (lag x) n

def tap (q₀ q₁ q₂ : ℝ) (x : Signal) (n : ℕ) :=
  q₀*x n + q₁*lag x n + q₂*lag (lag x) n

theorem memoryWeights (α : ℝ) (ha : α ≠ 1) :
    1/(1-α) + (-α)/(1-α) = 1 ∧ α*(1/(1-α)) + (-α)/(1-α) = 0 := by
  constructor <;> field_simp [sub_ne_zero.mpr (Ne.symm ha)]
  all_goals ring

/-- The actual correction applied to the outputs of both branches. The first
branch accumulates with pole one, and the second branch has pole α. -/
theorem injectedCorrection (α : ℝ) (ha : α ≠ 1) (δ i d : Signal)
    (hi : ∀ k, i k = lag i k + δ k/(1-α))
    (hd : ∀ k, d k = α*lag d k - α*δ k/(1-α)) (k : ℕ) :
    den α (fun n => i n + d n) k = δ k := by
  have hi' : lag i k = lag (lag i) k + lag δ k/(1-α) := by
    cases k with
    | zero => simp [lag]
    | succ n => exact hi n
  have hd' : lag d k = α*lag (lag d) k - α*lag δ k/(1-α) := by
    cases k with
    | zero => simp [lag]
    | succ n => exact hd n
  have addLag (x y : Signal) (n : ℕ) :
      lag (fun j => x j + y j) n = lag x n + lag y n := by cases n <;> simp [lag]
  have a2 : lag (lag fun n => i n + d n) k =
      lag (lag i) k + lag (lag d) k := by
    cases k with
    | zero => simp [lag]
    | succ n => exact addLag i d n
  unfold den
  rw [a2, addLag]
  dsimp only
  rw [hi k, hd k, hi', hd']
  field_simp [sub_ne_zero.mpr (Ne.symm ha)]
  ring

theorem den_add (α : ℝ) (x y : Signal) (n : ℕ) :
    den α (fun k => x k + y k) n = den α x n + den α y n := by
  cases n with
  | zero => simp [den, lag]
  | succ n => cases n <;> simp [den, lag] <;> ring

/-- The transfer numerator for a single reference or feedback channel in (6),
in time domain. P is static, I is an accumulator, D is a filtered difference. -/
theorem physicalChannel (α kp ki₀ ki₁ kd : ℝ) (x i d : Signal)
    (hi : ∀ k, i k = lag i k + ki₀*x k + ki₁*lag x k)
    (hd : ∀ k, d k = α*lag d k + kd*(x k-lag x k)) (k : ℕ) :
    den α (fun n => kp*x n+i n+d n) k =
      tap (kp+ki₀+kd) (-(1+α)*kp+ki₁-α*ki₀-2*kd)
        (α*kp-α*ki₁+kd) x k := by
  have hi' : lag i k = lag (lag i) k + ki₀*lag x k + ki₁*lag (lag x) k := by
    cases k with
    | zero => simp [lag]
    | succ k => exact hi k
  have hd' : lag d k = α*lag (lag d) k + kd*(lag x k-lag (lag x) k) := by
    cases k with
    | zero => simp [lag]
    | succ k => exact hd k
  have step (j : ℕ) : lag (fun n => kp*x n+i n+d n) j =
        kp*lag x j+lag i j+lag d j := by cases j <;> simp [lag]
  have step2 : lag (lag fun n => kp*x n+i n+d n) k =
        kp*lag (lag x) k+lag (lag i) k+lag (lag d) k := by
    cases k with
    | zero => simp [lag]
    | succ k => exact step k
  unfold den tap
  rw [step2, step]
  dsimp only
  rw [hi k, hd k, hi', hd']
  ring

theorem den_sub (α : ℝ) (x y : Signal) (n : ℕ) :
    den α (fun k => x k - y k) n = den α x n - den α y n := by
  cases n with
  | zero => simp [den, lag]
  | succ n => cases n <;> simp [den, lag] <;> ring

/-- The driven physical, common-rate realization. Here u is the sum of the
stored branch outputs, including the correction made after the actuator acts.
The two tap equations below are precisely the fitted channel numerators. -/
theorem corrected_physical_den (α kp b c ki₀ ki₁ kd η f ζ a : ℝ) (ha : α ≠ 1)
    (r y u i d δ : Signal)
    (hu : ∀ k, u k = kp*(b*r k-y k)+i k+d k)
    (hi : ∀ k, i k = lag i k + ki₀*(r k-y k) + ki₁*(lag r k-lag y k)
        + δ k/(1-α))
    (hd : ∀ k, d k = α*lag d k + kd*(c*r k-y k-c*lag r k+lag y k)
        - α*δ k/(1-α))
    (hr : ∀ k, tap (kp*b+ki₀+kd*c) (-(1+α)*kp*b+ki₁-α*ki₀-2*kd*c)
        (α*kp*b-α*ki₁+kd*c) r k = η*r k)
    (hy : ∀ k, tap (kp+ki₀+kd) (-(1+α)*kp+ki₁-α*ki₀-2*kd)
        (α*kp-α*ki₁+kd) y k = (f+ζ)*y k-a*ζ*lag y k) (k : ℕ) :
    den α u k = η*r k - (f+ζ)*y k + a*ζ*lag y k + δ k := by
  have u1 (n : ℕ) : lag u n = kp*(b*lag r n-lag y n)+lag i n+lag d n := by
    cases n with
    | zero => simp [lag]
    | succ n => exact hu n
  have u2 : lag (lag u) k = kp*(b*lag (lag r) k-lag (lag y) k)
       + lag (lag i) k + lag (lag d) k := by
    cases k with
    | zero => simp [lag]
    | succ n => exact u1 n
  have i1 : lag i k = lag (lag i) k + ki₀*(lag r k-lag y k)
      + ki₁*(lag (lag r) k-lag (lag y) k) + lag δ k/(1-α) := by
    cases k with
    | zero => simp [lag]
    | succ n => exact hi n
  have d1 : lag d k = α*lag (lag d) k
      + kd*(c*lag r k-lag y k-c*lag (lag r) k+lag (lag y) k)
      - α*lag δ k/(1-α) := by
    cases k with
    | zero => simp [lag]
    | succ n => exact hd n
  have hR := hr k
  have hY := hy k
  unfold tap at hR hY
  unfold den
  rw [u2, u1, hu, hi k, hd k, i1, d1]
  have H : 1-α ≠ 0 := sub_ne_zero.mpr (Ne.symm ha)
  field_simp [H]
  linear_combination (1-α)*hR - (1-α)*hY

theorem raw_of_forced_den (a b₀ b₁ η f t ζ α : ℝ)
    (hpole : α = -ζ*b₁) (ht : t+ζ*(b₀+b₁)=1)
    (r y u raw δ : Signal)
    (hplant : ∀ k, y k = a*lag y k+b₀*lag u k+b₁*lag (lag u) k)
    (hden : ∀ k, den α u k = η*r k-(f+ζ)*y k+a*ζ*lag y k+δ k)
    (hδ : ∀ k, δ k = u k-raw k) :
    ∀ k, raw k = η*r k - f*y k + t*lag u k := by
  intro k
  have hd := hden k
  unfold den at hd
  rw [hδ, hpole] at hd
  linear_combination hd - ζ*(hplant k) - lag u k*ht

def clip (L H x : ℝ) := min H (max L x)

/-- The nominal channel is evaluated on the actual measured signals. The two
additional branch states are exactly the differences from these unconditioned
branch responses. Their recurrences hold independently of how the actuator
chooses the applied command. -/
theorem raw_eq_prescribed (a b₀ b₁ η f t ζ α : ℝ)
    (ha : α ≠ 1) (hpole : α = -ζ*b₁) (ht : t+ζ*(b₀+b₁)=1)
    (r y u v base δ i d : Signal)
    (hplant : ∀ k, y k = a*lag y k+b₀*lag u k+b₁*lag (lag u) k)
    (hchannels : ∀ k, den α base k = η*r k - (f+ζ)*y k + a*ζ*lag y k)
    (hi : ∀ k, i k = lag i k + δ k/(1-α))
    (hd : ∀ k, d k = α*lag d k - α*δ k/(1-α))
    (hout : ∀ k, u k = base k + (i k+d k)) (hδ : ∀ k, δ k = u k-v k) (k : ℕ) :
    v k = η*r k - f*y k + t*lag u k := by
  have hu : u = fun n => base n + (i n+d n) := funext hout
  have hden : den α u k = η*r k - (f+ζ)*y k + a*ζ*lag y k + δ k := by
    rw [hu, den_add, hchannels, injectedCorrection α ha δ i d hi hd]
  unfold den at hden
  rw [hδ] at hden
  rw [hpole] at hden
  linear_combination hden - ζ*(hplant k) - lag u k*ht

/-- Once the raw command is identified, projection gives exactly the same
applied input at every time, including repeated changes of active bounds. -/
theorem projected_eq (v target applied L H : Signal)
    (hv : ∀ k, v k = target k) (hc : ∀ k, applied k = clip (L k) (H k) (v k)) :
    ∀ k, applied k = clip (L k) (H k) (target k) := by
  intro k
  rw [hc, hv]

structure Box where
  a : ℝ
  b₀ : ℝ
  b₁ : ℝ
  Y : ℝ
  U : ℝ
  ha₀ : 0 ≤ a
  ha₁ : a < 1
  hb₀ : 0 < b₀
  hb₁ : 0 < b₁
  hY : 0 ≤ Y
  hU : 0 ≤ U

namespace Box

def inside (m : Box) (y v : ℝ) : Prop := 0 ≤ y ∧ y ≤ m.Y ∧ 0 ≤ v ∧ v ≤ m.U
def safe (m : Box) (y v : ℝ) : Prop := m.inside y v ∧ m.a*y + m.b₁*v ≤ m.Y
def next (m : Box) (y v u : ℝ) := m.a*y + m.b₀*u + m.b₁*v
noncomputable def upper (m : Box) (y v : ℝ) :=
  min m.U (min ((m.Y-m.a*y-m.b₁*v)/m.b₀)
      ((m.Y-m.a^2*y-m.a*m.b₁*v)/(m.a*m.b₀+m.b₁)))

theorem zero_successor (m : Box) (y v : ℝ) (h : m.safe y v) :
    m.safe (m.next y v 0) 0 := by
  obtain ⟨⟨hy, _, hv, _⟩, hb⟩ := h
  have hn : 0 ≤ m.a*y + m.b₁*v := add_nonneg (mul_nonneg m.ha₀ hy) (mul_nonneg m.hb₁.le hv)
  have hcontract := mul_le_mul_of_nonneg_right (le_of_lt m.ha₁) hn
  simpa [safe, inside, next] using
    (show (0 ≤ m.a*y + m.b₁*v ∧ m.a*y + m.b₁*v ≤ m.Y ∧
      0 ≤ (0:ℝ) ∧ 0 ≤ m.U) ∧ m.a*(m.a*y+m.b₁*v) ≤ m.Y from
      ⟨⟨hn,hb,le_rfl,m.hU⟩, le_trans (by simpa using hcontract) hb⟩)

/-- Every controlled-invariant subset of the box is contained in safe. -/
theorem maximal (m : Box) (K : ℝ → ℝ → Prop)
    (hbox : ∀ y v, K y v → m.inside y v)
    (hstep : ∀ y v, K y v → ∃ u, K (m.next y v u) u) :
    ∀ y v, K y v → m.safe y v := by
  intro y v h
  obtain ⟨u, hu⟩ := hstep y v h
  have h' := hbox _ _ hu
  refine ⟨hbox _ _ h, ?_⟩
  have hp := mul_nonneg m.hb₀.le h'.2.2.1
  have hb := h'.2.1
  unfold next at hb
  linarith

theorem admissible_iff (m : Box) (y v u : ℝ) (h : m.safe y v) :
    m.safe (m.next y v u) u ↔ 0 ≤ u ∧ u ≤ m.upper y v := by
  have hc : 0 < m.a*m.b₀ + m.b₁ :=
    add_pos_of_nonneg_of_pos (mul_nonneg m.ha₀ m.hb₀.le) m.hb₁
  have hy := h.1.1
  have hv := h.1.2.2.1
  have hbase := mul_nonneg m.ha₀ hy
  have hprev := mul_nonneg m.hb₁.le hv
  simp only [safe, inside, next, upper, le_min_iff, le_div_iff₀ m.hb₀,
    le_div_iff₀ hc]
  constructor
  · rintro ⟨⟨_, hnext, hu, hU⟩, hl⟩
    exact ⟨hu,hU,by linarith, by nlinarith only [hl]⟩
  · rintro ⟨hu, hU, hnext, hl⟩
    have hu' := mul_nonneg m.hb₀.le hu
    exact ⟨⟨by linarith, by linarith, hu, hU⟩, by nlinarith only [hl]⟩

theorem projected_successor (m : Box) (y v raw : ℝ) (h : m.safe y v) :
    m.safe (m.next y v (clip 0 (m.upper y v) raw)) (clip 0 (m.upper y v) raw) := by
  have h0 := ((m.admissible_iff y v 0 h).mp (m.zero_successor y v h)).2
  apply (m.admissible_iff _ _ _ h).mpr
  exact ⟨le_min h0 (le_max_left _ _), min_le_left _ _⟩

theorem projected_all (m : Box) (y v raw : Signal) (h0 : m.safe (y 0) (v 0))
    (hu : ∀ k, v (k+1) = clip 0 (m.upper (y k) (v k)) (raw k))
    (hy : ∀ k, y (k+1) = m.next (y k) (v k) (v (k+1))) :
    ∀ k, m.safe (y k) (v k) := by
  intro k
  induction k with
  | zero => exact h0
  | succ k ih => rw [hy, hu]; exact m.projected_successor _ _ _ ih

end Box
end MPCPID.Conditioned
