import MPCPID.Matching
import Mathlib.LinearAlgebra.Matrix.PosDef
import Mathlib.Tactic.Abel
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-! # Condensed predictive control and the physical closed-loop spectrum
Appendices A, B and D. All signal and matrix identities are over the reals.
The seven-state determinant below uses the states of the physical implementation,
including both sampled-error memories and the held proportional output. -/

namespace MPCPID.Appendices
open Matrix
open scoped Matrix BigOperators

set_option maxRecDepth 8192
set_option maxHeartbeats 2400000

/-- Unrolling the augmented increment dynamics gives the finite convolution
used to construct the rows of F and G in Appendix A. -/
theorem prediction_convolution {V : Type*} [AddCommGroup V] [Module ℝ V]
    (T : V →ₗ[ℝ] V) (B : V) (v : ℕ → ℝ) (x : ℕ → V)
    (hx : ∀ k, x (k+1) = T (x k) + (v k) • B) (k : ℕ) :
    x k = (T^k) (x 0) + ∑ j ∈ Finset.range k, (v j) • (T^(k-1-j)) B := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [hx, ih, map_add, map_sum, Finset.sum_range_succ,
      Nat.succ_sub_one, Nat.sub_self, pow_zero]
    simp only [map_smul, Module.End.one_apply]
    have powers (n : ℕ) (z : V) : T ((T ^ n) z) = (T ^ (n + 1)) z := by
      rw [pow_succ', Module.End.mul_apply]
    rw [powers]
    rw [add_assoc]
    congr 2
    apply Finset.sum_congr rfl
    intro j hj
    have hj' := Finset.mem_range.mp hj
    rw [powers, show k-1-j+1 = k-j by omega]

section LeastSquares
variable {n m : Type*} [Fintype n] [DecidableEq n] [Fintype m]

def normal (G : Matrix m n ℝ) (Q l : ℝ) : Matrix n n ℝ :=
  Q • (G.transpose * G) + l • (1 : Matrix n n ℝ)

/-- A Gramian plus the positive move penalty has a trivial nullspace. -/
theorem normal_form (G : Matrix m n ℝ) (Q l : ℝ) (x y : n → ℝ) :
    dotProduct x ((normal G Q l).mulVec y) =
      Q * dotProduct (G.mulVec x) (G.mulVec y) + l * dotProduct x y := by
  simp only [normal, add_mulVec, smul_mulVec_assoc, one_mulVec, ← mulVec_mulVec,
    dotProduct_add, dotProduct_smul, dotProduct_mulVec x G.transpose, vecMul_transpose,
    smul_eq_mul]

omit [DecidableEq n] in
private theorem dot_nonneg (x : n → ℝ) : 0 ≤ dotProduct x x :=
  Finset.sum_nonneg (fun i _ => mul_self_nonneg (x i))

omit [DecidableEq n] in
private theorem dot_pos (x : n → ℝ) (hx : x ≠ 0) : 0 < dotProduct x x :=
  lt_of_le_of_ne (dot_nonneg x) (Ne.symm (fun h => hx (dotProduct_self_eq_zero.mp h)))

theorem normal_invertible (G : Matrix m n ℝ) {Q l : ℝ} (hQ : 0 ≤ Q) (hl : 0 < l) :
    IsUnit (normal G Q l) := by
  apply mulVec_injective_iff_isUnit.mp
  intro x y he
  by_contra h
  have hn : x-y ≠ 0 := sub_ne_zero.mpr h
  have hz : (normal G Q l).mulVec (x-y) = 0 := by rw [mulVec_sub, he, sub_self]
  have hd := normal_form G Q l (x-y) (x-y)
  rw [hz, dotProduct_zero] at hd
  have h1 := dot_nonneg (G.mulVec (x-y))
  have h2 := dot_pos (x-y) hn
  linarith [mul_nonneg hQ h1, mul_pos hl h2]

def predictorCost (G : Matrix m n ℝ) (Q l : ℝ) (b : m → ℝ) (v : n → ℝ) : ℝ :=
  Q * dotProduct (G.mulVec v - b) (G.mulVec v - b) + l * dotProduct v v

/-- Completion of squares for an arbitrary prediction matrix; the equality
also identifies the unique optimal move sequence. -/
theorem leastSquares_gap (G : Matrix m n ℝ) (Q l : ℝ) (b : m → ℝ) (u v : n → ℝ)
    (hu : (normal G Q l).mulVec u = Q • (G.transpose.mulVec b)) :
    predictorCost G Q l b (u+v) - predictorCost G Q l b u =
      Q * dotProduct (G.mulVec v) (G.mulVec v) + l * dotProduct v v := by
  have hc := normal_form G Q l v u
  rw [hu, dotProduct_smul, dotProduct_mulVec, vecMul_transpose, smul_eq_mul] at hc
  unfold predictorCost
  rw [mulVec_add]
  simp only [sub_dotProduct, dotProduct_sub, add_dotProduct, dotProduct_add]
  rw [dotProduct_comm (G.mulVec u) (G.mulVec v),
    dotProduct_comm b (G.mulVec v), dotProduct_comm u v]
  linarith only [hc]

theorem inverse_is_unique_minimizer (G : Matrix m n ℝ) (b : m → ℝ) {Q l : ℝ}
    (hQ : 0 ≤ Q) (hl : 0 < l) :
    let u := (normal G Q l)⁻¹.mulVec (Q • (G.transpose.mulVec b))
    ∀ v, v ≠ u → predictorCost G Q l b u < predictorCost G Q l b v := by
  dsimp only
  let H := normal G Q l
  let u := H⁻¹.mulVec (Q • (G.transpose.mulVec b))
  have hH := normal_invertible G hQ hl
  letI := hH.invertible
  have hu : (normal G Q l).mulVec u = Q • (G.transpose.mulVec b) := by
    dsimp [u,H]
    rw [mulVec_mulVec, mul_inv_of_invertible, one_mulVec]
  intro v hne
  obtain ⟨w, hw⟩ : ∃ w, v = u + w := ⟨v-u, by abel⟩
  have hw0 : w ≠ 0 := by intro e; subst w; apply hne; simpa using hw
  have hgap := leastSquares_gap G Q l b u w hu
  change predictorCost G Q l b u < predictorCost G Q l b v
  rw [hw]
  linarith [mul_nonneg hQ (dot_nonneg (G.mulVec w)), mul_pos hl (dot_pos w hw0)]

omit [DecidableEq n] in
/-- Reading the first row of the inverse normal equations gives the three
first-move gains with the paper's increment convention. -/
theorem first_move_gains (q F₁ F₂ : n → ℝ) (r y prev : ℝ) :
    prev + dotProduct q ((fun _ => r) - y • F₁ - prev • F₂) =
      (∑ i, q i) * r - dotProduct q F₁ * y + (1 - dotProduct q F₂) * prev := by
  rw [dotProduct_sub, dotProduct_sub, dotProduct_smul, dotProduct_smul]
  simp only [smul_eq_mul]
  have h : dotProduct q (fun _ => r) = (∑ i, q i) * r := by
    simp only [dotProduct, Finset.sum_mul]
  rw [h]; ring

end LeastSquares

/-- Subtract the plant and control equations for the two trajectories with the
same disturbance. The cross-multiplied relation also applies at denominator zeros. -/
theorem disturbance_difference (a w t f b₀ b₁ ζ E du dy : ℝ)
    (plant : (1-a*w)*dy = w*(b₀+b₁*w)*du)
    (law : (1-t*w)*du + f*dy = -ζ*E) :
    ((1-a*w)*(1-t*w)+f*w*(b₀+b₁*w))*du = -ζ*(1-a*w)*E := by
  linear_combination (1-a*w)*law - f*plant

theorem one_step_jury (a g b₀ b₁ : ℝ)
    (ha : 0 ≤ a) (ha1 : a < 1) (hg : 0 < g) (h₀ : 0 < b₀) (h₁ : 0 < b₁)
    (hgb₀ : g*b₀ < 1) (hgb₁ : g*b₁ < 1) :
    let t := 1-g*(b₀+b₁)
    let μ := 1-g*b₀
    let τ := a*μ+t
    let δ := a*μ
    0 < 1-τ+δ ∧ 0 < 1+τ+δ ∧ 0 < 1-δ := by
  dsimp only
  have hg0 := mul_pos hg h₀
  have hg1 := mul_pos hg h₁
  have hm : 0 < 1-g*b₀ := by linarith
  have hm1 : 1-g*b₀ ≤ 1 := by linarith
  have hδ := mul_nonneg ha hm.le
  have hδ1 : a*(1-g*b₀) < 1 := (mul_le_of_le_one_right ha hm1).trans_lt ha1
  constructor
  · nlinarith
  constructor <;> nlinarith

theorem pi_boundary (g a γ w : ℝ) (hg : 0 < g) (ha : 0 ≤ a)
    (_hγ : 0 ≤ γ) (hγ1 : γ ≤ 1) (ht : 0 < 1+a-γ) :
    let kp := g*(1+a-γ)
    let b := (1-γ)/(1+a-γ)
    0 < kp ∧ 0 ≤ b ∧ b ≤ 1 ∧
      kp*(1-w) + g*(γ+(1-γ)*w) = g*((1+a)-a*w) ∧
      kp*b*(1-w) + g*(γ+(1-γ)*w) = g := by
  dsimp only
  refine ⟨mul_pos hg ht, div_nonneg (by linarith) ht.le,
    (div_le_one ht).mpr (by linarith), by ring, ?_⟩
  field_simp [ne_of_gt ht]; ring

/-- The rational example in §4.4, at unit sampling interval. -/
theorem rational_branch_check (w : ℝ) :
    let kp : ℝ := 12/25
    let Ti : ℝ := 6/5
    let Td : ℝ := 7/60
    let Tf : ℝ := 3/10
    let b : ℝ := 7/12
    let c : ℝ := 2/7
    let α := 1 - 1/(Tf + 1/2)
    let κ := kp / Ti
    let d := kp*Td/(Tf+1/2)
    α = -1/4 ∧ κ = 2/5 ∧ d = 7/100 ∧
      kp*(1-w)*(1-α*w)+κ*(1+w)/2*(1-α*w)+d*(1-w)^2 = 3/4-w/4 ∧
      kp*b*(1-w)*(1-α*w)+κ*(1+w)/2*(1-α*w)+c*d*(1-w)^2 = 1/2 := by
  dsimp only
  norm_num
  constructor <;> ring


private theorem sumEntries2 (g : Fin 2 → ℝ) :
    ∑ j, g j = g 0 + (g 1) := by
  simp only [Fin.sum_univ_succ, Finset.univ_eq_empty, Finset.sum_empty, add_zero]
  rfl

private theorem laplace2 (M : Matrix (Fin 2) (Fin 2) ℝ) :
    M.det = (M 0 0 * (M.submatrix Fin.succ (0 : Fin 2).succAbove).det) + (-(M 0 1 * (M.submatrix Fin.succ (1 : Fin 2).succAbove).det)) := by
  rw [Matrix.det_succ_row_zero, sumEntries2]
  simp only [show ((0 : Fin 2) : ℕ) = 0 from rfl, show ((1 : Fin 2) : ℕ) = 1 from rfl, add_assoc, pow_zero, pow_succ, one_mul, neg_one_mul, neg_mul, mul_neg, neg_neg, mul_one]



private theorem sumEntries3 (g : Fin 3 → ℝ) :
    ∑ j, g j = g 0 + (g 1 + (g 2)) := by
  simp only [Fin.sum_univ_succ, Finset.univ_eq_empty, Finset.sum_empty, add_zero]
  rfl

private theorem laplace3 (M : Matrix (Fin 3) (Fin 3) ℝ) :
    M.det = (M 0 0 * (M.submatrix Fin.succ (0 : Fin 3).succAbove).det) + (-(M 0 1 * (M.submatrix Fin.succ (1 : Fin 3).succAbove).det)) + (M 0 2 * (M.submatrix Fin.succ (2 : Fin 3).succAbove).det) := by
  rw [Matrix.det_succ_row_zero, sumEntries3]
  simp only [show ((0 : Fin 3) : ℕ) = 0 from rfl, show ((1 : Fin 3) : ℕ) = 1 from rfl, show ((2 : Fin 3) : ℕ) = 2 from rfl, add_assoc, pow_zero, pow_succ, one_mul, neg_one_mul, neg_mul, mul_neg, neg_neg, mul_one]



private theorem sumEntries4 (g : Fin 4 → ℝ) :
    ∑ j, g j = g 0 + (g 1 + (g 2 + (g 3))) := by
  simp only [Fin.sum_univ_succ, Finset.univ_eq_empty, Finset.sum_empty, add_zero]
  rfl

private theorem laplace4 (M : Matrix (Fin 4) (Fin 4) ℝ) :
    M.det = (M 0 0 * (M.submatrix Fin.succ (0 : Fin 4).succAbove).det) + (-(M 0 1 * (M.submatrix Fin.succ (1 : Fin 4).succAbove).det)) + (M 0 2 * (M.submatrix Fin.succ (2 : Fin 4).succAbove).det) + (-(M 0 3 * (M.submatrix Fin.succ (3 : Fin 4).succAbove).det)) := by
  rw [Matrix.det_succ_row_zero, sumEntries4]
  simp only [show ((0 : Fin 4) : ℕ) = 0 from rfl, show ((1 : Fin 4) : ℕ) = 1 from rfl, show ((2 : Fin 4) : ℕ) = 2 from rfl, show ((3 : Fin 4) : ℕ) = 3 from rfl, add_assoc, pow_zero, pow_succ, one_mul, neg_one_mul, neg_mul, mul_neg, neg_neg, mul_one]



private theorem sumEntries5 (g : Fin 5 → ℝ) :
    ∑ j, g j = g 0 + (g 1 + (g 2 + (g 3 + (g 4)))) := by
  simp only [Fin.sum_univ_succ, Finset.univ_eq_empty, Finset.sum_empty, add_zero]
  rfl

private theorem laplace5 (M : Matrix (Fin 5) (Fin 5) ℝ) :
    M.det = (M 0 0 * (M.submatrix Fin.succ (0 : Fin 5).succAbove).det) + (-(M 0 1 * (M.submatrix Fin.succ (1 : Fin 5).succAbove).det)) + (M 0 2 * (M.submatrix Fin.succ (2 : Fin 5).succAbove).det) + (-(M 0 3 * (M.submatrix Fin.succ (3 : Fin 5).succAbove).det)) + (M 0 4 * (M.submatrix Fin.succ (4 : Fin 5).succAbove).det) := by
  rw [Matrix.det_succ_row_zero, sumEntries5]
  simp only [show ((0 : Fin 5) : ℕ) = 0 from rfl, show ((1 : Fin 5) : ℕ) = 1 from rfl, show ((2 : Fin 5) : ℕ) = 2 from rfl, show ((3 : Fin 5) : ℕ) = 3 from rfl, show ((4 : Fin 5) : ℕ) = 4 from rfl, add_assoc, pow_zero, pow_succ, one_mul, neg_one_mul, neg_mul, mul_neg, neg_neg, mul_one]



private theorem sumEntries6 (g : Fin 6 → ℝ) :
    ∑ j, g j = g 0 + (g 1 + (g 2 + (g 3 + (g 4 + (g 5))))) := by
  simp only [Fin.sum_univ_succ, Finset.univ_eq_empty, Finset.sum_empty, add_zero]
  rfl

private theorem laplace6 (M : Matrix (Fin 6) (Fin 6) ℝ) :
    M.det = (M 0 0 * (M.submatrix Fin.succ (0 : Fin 6).succAbove).det) + (-(M 0 1 * (M.submatrix Fin.succ (1 : Fin 6).succAbove).det)) + (M 0 2 * (M.submatrix Fin.succ (2 : Fin 6).succAbove).det) + (-(M 0 3 * (M.submatrix Fin.succ (3 : Fin 6).succAbove).det)) + (M 0 4 * (M.submatrix Fin.succ (4 : Fin 6).succAbove).det) + (-(M 0 5 * (M.submatrix Fin.succ (5 : Fin 6).succAbove).det)) := by
  rw [Matrix.det_succ_row_zero, sumEntries6]
  simp only [show ((0 : Fin 6) : ℕ) = 0 from rfl, show ((1 : Fin 6) : ℕ) = 1 from rfl, show ((2 : Fin 6) : ℕ) = 2 from rfl, show ((3 : Fin 6) : ℕ) = 3 from rfl, show ((4 : Fin 6) : ℕ) = 4 from rfl, show ((5 : Fin 6) : ℕ) = 5 from rfl, add_assoc, pow_zero, pow_succ, one_mul, neg_one_mul, neg_mul, mul_neg, neg_neg, mul_one]



private theorem sumEntries7 (g : Fin 7 → ℝ) :
    ∑ j, g j = g 0 + (g 1 + (g 2 + (g 3 + (g 4 + (g 5 + (g 6)))))) := by
  simp only [Fin.sum_univ_succ, Finset.univ_eq_empty, Finset.sum_empty, add_zero]
  rfl

private theorem laplace7 (M : Matrix (Fin 7) (Fin 7) ℝ) :
    M.det = (M 0 0 * (M.submatrix Fin.succ (0 : Fin 7).succAbove).det) + (-(M 0 1 * (M.submatrix Fin.succ (1 : Fin 7).succAbove).det)) + (M 0 2 * (M.submatrix Fin.succ (2 : Fin 7).succAbove).det) + (-(M 0 3 * (M.submatrix Fin.succ (3 : Fin 7).succAbove).det)) + (M 0 4 * (M.submatrix Fin.succ (4 : Fin 7).succAbove).det) + (-(M 0 5 * (M.submatrix Fin.succ (5 : Fin 7).succAbove).det)) + (M 0 6 * (M.submatrix Fin.succ (6 : Fin 7).succAbove).det) := by
  rw [Matrix.det_succ_row_zero, sumEntries7]
  simp only [show ((0 : Fin 7) : ℕ) = 0 from rfl, show ((1 : Fin 7) : ℕ) = 1 from rfl, show ((2 : Fin 7) : ℕ) = 2 from rfl, show ((3 : Fin 7) : ℕ) = 3 from rfl, show ((4 : Fin 7) : ℕ) = 4 from rfl, show ((5 : Fin 7) : ℕ) = 5 from rfl, show ((6 : Fin 7) : ℕ) = 6 from rfl, add_assoc, pow_zero, pow_succ, one_mul, neg_one_mul, neg_mul, mul_neg, neg_neg, mul_one]



/-- The pencil zI−A in state order (p,eI,eD,i,d_f,u_previous,y).
A common-rate update sets each error memory to -y at zero reference.
The last two rows are respectively the applied command and the plant update. -/
def physicalPencil (z a b₀ b₁ kp I₀ I₁ α d : ℝ) : Matrix (Fin 7) (Fin 7) ℝ :=
  !![z, 0, 0, 0, 0, 0, kp;
     0, z, 0, 0, 0, 0, 1;
     0, 0, z, 0, 0, 0, 1;
     0, -I₁, 0, z-1, 0, 0, I₀;
     0, 0, d, 0, z-α, 0, d;
     0, -I₁, d, -1, -α, z, kp+I₀+d;
     0, -b₀*I₁, b₀*d, -b₀, -b₀*α, -b₁, z-a+b₀*(kp+I₀+d)]



/-- Compute the seven next states directly from the branch updates,
using the applied current command for the plant. -/
def actualStep (a b₀ b₁ kp I₀ I₁ α d : ℝ) (x : Fin 7 → ℝ) : Fin 7 → ℝ :=
  let y := x 6
  let p := -kp*y
  let i := x 3 + I₁*x 1 - I₀*y
  let df := α*x 4 - d*x 2 - d*y
  let u := p+i+df
  ![p,-y,-y,i,df,u,a*y+b₀*u+b₁*x 5]

/-- The displayed pencil acts as zI minus the actual branch/plant update. -/
theorem physical_pencil_action (z a b₀ b₁ kp I₀ I₁ α d : ℝ) (x : Fin 7 → ℝ) :
    (physicalPencil z a b₀ b₁ kp I₀ I₁ α d).mulVec x =
      z • x - actualStep a b₀ b₁ kp I₀ I₁ α d x := by
  funext k
  fin_cases k <;> simp [physicalPencil, actualStep, Matrix.mulVec, dotProduct, Fin.sum_univ_succ]
    <;> ring

/-- Unreduced closed-loop determinant, before using any matching equations. -/
theorem physical_determinant (z a b₀ b₁ kp I₀ I₁ α d : ℝ) :
    (physicalPencil z a b₀ b₁ kp I₀ I₁ α d).det =
      z^3*(z*(z-a)*(z-1)*(z-α) + (b₀*z+b₁)*
        ((kp+I₀+d)*z^2 + (-kp*(1+α)+I₁-α*I₀-2*d)*z + (kp*α-I₁*α+d))) := by
  let m0 := (physicalPencil z a b₀ b₁ kp I₀ I₁ α d).submatrix Fin.succ (0 : Fin 7).succAbove
  let m00 := m0.submatrix Fin.succ (0 : Fin 6).succAbove
  let m000 := m00.submatrix Fin.succ (0 : Fin 5).succAbove
  let m0000 := m000.submatrix Fin.succ (0 : Fin 4).succAbove
  let m00000 := m0000.submatrix Fin.succ (0 : Fin 3).succAbove
  let m000000 := m00000.submatrix Fin.succ (0 : Fin 2).succAbove
  let m000001 := m00000.submatrix Fin.succ (1 : Fin 2).succAbove
  let m00002 := m0000.submatrix Fin.succ (2 : Fin 3).succAbove
  let m000020 := m00002.submatrix Fin.succ (0 : Fin 2).succAbove
  let m000021 := m00002.submatrix Fin.succ (1 : Fin 2).succAbove
  let m0003 := m000.submatrix Fin.succ (3 : Fin 4).succAbove
  let m00031 := m0003.submatrix Fin.succ (1 : Fin 3).succAbove
  let m000310 := m00031.submatrix Fin.succ (0 : Fin 2).succAbove
  let m000311 := m00031.submatrix Fin.succ (1 : Fin 2).succAbove
  let m004 := m00.submatrix Fin.succ (4 : Fin 5).succAbove
  let m0041 := m004.submatrix Fin.succ (1 : Fin 4).succAbove
  let m00410 := m0041.submatrix Fin.succ (0 : Fin 3).succAbove
  let m004100 := m00410.submatrix Fin.succ (0 : Fin 2).succAbove
  let m004101 := m00410.submatrix Fin.succ (1 : Fin 2).succAbove
  let m00411 := m0041.submatrix Fin.succ (1 : Fin 3).succAbove
  let m004110 := m00411.submatrix Fin.succ (0 : Fin 2).succAbove
  let m004111 := m00411.submatrix Fin.succ (1 : Fin 2).succAbove
  let m05 := m0.submatrix Fin.succ (5 : Fin 6).succAbove
  let m051 := m05.submatrix Fin.succ (1 : Fin 5).succAbove
  let m0510 := m051.submatrix Fin.succ (0 : Fin 4).succAbove
  let m05101 := m0510.submatrix Fin.succ (1 : Fin 3).succAbove
  let m051010 := m05101.submatrix Fin.succ (0 : Fin 2).succAbove
  let m051011 := m05101.submatrix Fin.succ (1 : Fin 2).succAbove
  let m0511 := m051.submatrix Fin.succ (1 : Fin 4).succAbove
  let m05111 := m0511.submatrix Fin.succ (1 : Fin 3).succAbove
  let m051110 := m05111.submatrix Fin.succ (0 : Fin 2).succAbove
  let m051111 := m05111.submatrix Fin.succ (1 : Fin 2).succAbove
  let m6 := (physicalPencil z a b₀ b₁ kp I₀ I₁ α d).submatrix Fin.succ (6 : Fin 7).succAbove
  let m61 := m6.submatrix Fin.succ (1 : Fin 6).succAbove
  let m611 := m61.submatrix Fin.succ (1 : Fin 5).succAbove
  let m6111 := m611.submatrix Fin.succ (1 : Fin 4).succAbove
  let m61111 := m6111.submatrix Fin.succ (1 : Fin 3).succAbove
  let m611111 := m61111.submatrix Fin.succ (1 : Fin 2).succAbove
  have hm000000 : m000000.det = z-a+b₀*(kp+I₀+d) := by rw [Matrix.det_fin_one]; rfl
  have hm000001 : m000001.det = -b₁ := by rw [Matrix.det_fin_one]; rfl
  have hm00000 : m00000.det = (z) * (z-a+b₀*(kp+I₀+d)) + (-((kp+I₀+d) * (-b₁))) := by
    rw [laplace2]
    change ((z) * m000000.det) + (-((kp+I₀+d) * m000001.det)) = _
    rw [hm000000, hm000001]
  have hm000020 : m000020.det = -b₁ := by rw [Matrix.det_fin_one]; rfl
  have hm000021 : m000021.det = -b₀*α := by rw [Matrix.det_fin_one]; rfl
  have hm00002 : m00002.det = (-α) * (-b₁) + (-((z) * (-b₀*α))) := by
    rw [laplace2]
    change ((-α) * m000020.det) + (-((z) * m000021.det)) = _
    rw [hm000020, hm000021]
  have hm0000 : m0000.det = (z-α) * ((z) * (z-a+b₀*(kp+I₀+d)) + (-((kp+I₀+d) * (-b₁)))) + (d) * ((-α) * (-b₁) + (-((z) * (-b₀*α)))) := by
    rw [laplace3]
    change ((z-α) * m00000.det) + (-((0) * (m0000.submatrix Fin.succ (1 : Fin 3).succAbove).det)) + ((d) * m00002.det) = _
    rw [hm00000, hm00002]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm000310 : m000310.det = -b₁ := by rw [Matrix.det_fin_one]; rfl
  have hm000311 : m000311.det = -b₀ := by rw [Matrix.det_fin_one]; rfl
  have hm00031 : m00031.det = (-1) * (-b₁) + (-((z) * (-b₀))) := by
    rw [laplace2]
    change ((-1) * m000310.det) + (-((z) * m000311.det)) = _
    rw [hm000310, hm000311]
  have hm0003 : m0003.det = (-((z-α) * ((-1) * (-b₁) + (-((z) * (-b₀)))))) := by
    rw [laplace3]
    change ((0) * (m0003.submatrix Fin.succ (0 : Fin 3).succAbove).det) + (-((z-α) * m00031.det)) + ((0) * (m0003.submatrix Fin.succ (2 : Fin 3).succAbove).det) = _
    rw [hm00031]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm000 : m000.det = (z-1) * ((z-α) * ((z) * (z-a+b₀*(kp+I₀+d)) + (-((kp+I₀+d) * (-b₁)))) + (d) * ((-α) * (-b₁) + (-((z) * (-b₀*α))))) + (-((I₀) * ((-((z-α) * ((-1) * (-b₁) + (-((z) * (-b₀))))))))) := by
    rw [laplace4]
    change ((z-1) * m0000.det) + (-((0) * (m000.submatrix Fin.succ (1 : Fin 4).succAbove).det)) + ((0) * (m000.submatrix Fin.succ (2 : Fin 4).succAbove).det) + (-((I₀) * m0003.det)) = _
    rw [hm0000, hm0003]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm004100 : m004100.det = -b₁ := by rw [Matrix.det_fin_one]; rfl
  have hm004101 : m004101.det = -b₀*α := by rw [Matrix.det_fin_one]; rfl
  have hm00410 : m00410.det = (-α) * (-b₁) + (-((z) * (-b₀*α))) := by
    rw [laplace2]
    change ((-α) * m004100.det) + (-((z) * m004101.det)) = _
    rw [hm004100, hm004101]
  have hm004110 : m004110.det = -b₁ := by rw [Matrix.det_fin_one]; rfl
  have hm004111 : m004111.det = b₀*d := by rw [Matrix.det_fin_one]; rfl
  have hm00411 : m00411.det = (d) * (-b₁) + (-((z) * (b₀*d))) := by
    rw [laplace2]
    change ((d) * m004110.det) + (-((z) * m004111.det)) = _
    rw [hm004110, hm004111]
  have hm0041 : m0041.det = (d) * ((-α) * (-b₁) + (-((z) * (-b₀*α)))) + (-((z-α) * ((d) * (-b₁) + (-((z) * (b₀*d)))))) := by
    rw [laplace3]
    change ((d) * m00410.det) + (-((z-α) * m00411.det)) + ((0) * (m0041.submatrix Fin.succ (2 : Fin 3).succAbove).det) = _
    rw [hm00410, hm00411]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm004 : m004.det = (-((z-1) * ((d) * ((-α) * (-b₁) + (-((z) * (-b₀*α)))) + (-((z-α) * ((d) * (-b₁) + (-((z) * (b₀*d))))))))) := by
    rw [laplace4]
    change ((0) * (m004.submatrix Fin.succ (0 : Fin 4).succAbove).det) + (-((z-1) * m0041.det)) + ((0) * (m004.submatrix Fin.succ (2 : Fin 4).succAbove).det) + (-((0) * (m004.submatrix Fin.succ (3 : Fin 4).succAbove).det)) = _
    rw [hm0041]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm00 : m00.det = (z) * ((z-1) * ((z-α) * ((z) * (z-a+b₀*(kp+I₀+d)) + (-((kp+I₀+d) * (-b₁)))) + (d) * ((-α) * (-b₁) + (-((z) * (-b₀*α))))) + (-((I₀) * ((-((z-α) * ((-1) * (-b₁) + (-((z) * (-b₀)))))))))) + (1) * ((-((z-1) * ((d) * ((-α) * (-b₁) + (-((z) * (-b₀*α)))) + (-((z-α) * ((d) * (-b₁) + (-((z) * (b₀*d)))))))))) := by
    rw [laplace5]
    change ((z) * m000.det) + (-((0) * (m00.submatrix Fin.succ (1 : Fin 5).succAbove).det)) + ((0) * (m00.submatrix Fin.succ (2 : Fin 5).succAbove).det) + (-((0) * (m00.submatrix Fin.succ (3 : Fin 5).succAbove).det)) + ((1) * m004.det) = _
    rw [hm000, hm004]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm051010 : m051010.det = -b₁ := by rw [Matrix.det_fin_one]; rfl
  have hm051011 : m051011.det = -b₀ := by rw [Matrix.det_fin_one]; rfl
  have hm05101 : m05101.det = (-1) * (-b₁) + (-((z) * (-b₀))) := by
    rw [laplace2]
    change ((-1) * m051010.det) + (-((z) * m051011.det)) = _
    rw [hm051010, hm051011]
  have hm0510 : m0510.det = (-((z-α) * ((-1) * (-b₁) + (-((z) * (-b₀)))))) := by
    rw [laplace3]
    change ((0) * (m0510.submatrix Fin.succ (0 : Fin 3).succAbove).det) + (-((z-α) * m05101.det)) + ((0) * (m0510.submatrix Fin.succ (2 : Fin 3).succAbove).det) = _
    rw [hm05101]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm051110 : m051110.det = -b₁ := by rw [Matrix.det_fin_one]; rfl
  have hm051111 : m051111.det = -b₀*I₁ := by rw [Matrix.det_fin_one]; rfl
  have hm05111 : m05111.det = (-I₁) * (-b₁) + (-((z) * (-b₀*I₁))) := by
    rw [laplace2]
    change ((-I₁) * m051110.det) + (-((z) * m051111.det)) = _
    rw [hm051110, hm051111]
  have hm0511 : m0511.det = (-((z-α) * ((-I₁) * (-b₁) + (-((z) * (-b₀*I₁)))))) := by
    rw [laplace3]
    change ((0) * (m0511.submatrix Fin.succ (0 : Fin 3).succAbove).det) + (-((z-α) * m05111.det)) + ((0) * (m0511.submatrix Fin.succ (2 : Fin 3).succAbove).det) = _
    rw [hm05111]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm051 : m051.det = (-I₁) * ((-((z-α) * ((-1) * (-b₁) + (-((z) * (-b₀))))))) + (-((z-1) * ((-((z-α) * ((-I₁) * (-b₁) + (-((z) * (-b₀*I₁))))))))) := by
    rw [laplace4]
    change ((-I₁) * m0510.det) + (-((z-1) * m0511.det)) + ((0) * (m051.submatrix Fin.succ (2 : Fin 4).succAbove).det) + (-((0) * (m051.submatrix Fin.succ (3 : Fin 4).succAbove).det)) = _
    rw [hm0510, hm0511]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm05 : m05.det = (-((z) * ((-I₁) * ((-((z-α) * ((-1) * (-b₁) + (-((z) * (-b₀))))))) + (-((z-1) * ((-((z-α) * ((-I₁) * (-b₁) + (-((z) * (-b₀*I₁)))))))))))) := by
    rw [laplace5]
    change ((0) * (m05.submatrix Fin.succ (0 : Fin 5).succAbove).det) + (-((z) * m051.det)) + ((0) * (m05.submatrix Fin.succ (2 : Fin 5).succAbove).det) + (-((0) * (m05.submatrix Fin.succ (3 : Fin 5).succAbove).det)) + ((0) * (m05.submatrix Fin.succ (4 : Fin 5).succAbove).det) = _
    rw [hm051]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm0 : m0.det = (z) * ((z) * ((z-1) * ((z-α) * ((z) * (z-a+b₀*(kp+I₀+d)) + (-((kp+I₀+d) * (-b₁)))) + (d) * ((-α) * (-b₁) + (-((z) * (-b₀*α))))) + (-((I₀) * ((-((z-α) * ((-1) * (-b₁) + (-((z) * (-b₀)))))))))) + (1) * ((-((z-1) * ((d) * ((-α) * (-b₁) + (-((z) * (-b₀*α)))) + (-((z-α) * ((d) * (-b₁) + (-((z) * (b₀*d))))))))))) + (-((1) * ((-((z) * ((-I₁) * ((-((z-α) * ((-1) * (-b₁) + (-((z) * (-b₀))))))) + (-((z-1) * ((-((z-α) * ((-I₁) * (-b₁) + (-((z) * (-b₀*I₁))))))))))))))) := by
    rw [laplace6]
    change ((z) * m00.det) + (-((0) * (m0.submatrix Fin.succ (1 : Fin 6).succAbove).det)) + ((0) * (m0.submatrix Fin.succ (2 : Fin 6).succAbove).det) + (-((0) * (m0.submatrix Fin.succ (3 : Fin 6).succAbove).det)) + ((0) * (m0.submatrix Fin.succ (4 : Fin 6).succAbove).det) + (-((1) * m05.det)) = _
    rw [hm00, hm05]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm611111 : m611111.det = 0 := by rw [Matrix.det_fin_one]; rfl
  have hm61111 : m61111.det = 0 := by
    rw [laplace2]
    change ((0) * (m61111.submatrix Fin.succ (0 : Fin 2).succAbove).det) + (-((z) * m611111.det)) = _
    rw [hm611111]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm6111 : m6111.det = 0 := by
    rw [laplace3]
    change ((0) * (m6111.submatrix Fin.succ (0 : Fin 3).succAbove).det) + (-((z-α) * m61111.det)) + ((0) * (m6111.submatrix Fin.succ (2 : Fin 3).succAbove).det) = _
    rw [hm61111]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm611 : m611.det = 0 := by
    rw [laplace4]
    change ((0) * (m611.submatrix Fin.succ (0 : Fin 4).succAbove).det) + (-((z-1) * m6111.det)) + ((0) * (m611.submatrix Fin.succ (2 : Fin 4).succAbove).det) + (-((0) * (m611.submatrix Fin.succ (3 : Fin 4).succAbove).det)) = _
    rw [hm6111]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm61 : m61.det = 0 := by
    rw [laplace5]
    change ((0) * (m61.submatrix Fin.succ (0 : Fin 5).succAbove).det) + (-((z) * m611.det)) + ((0) * (m61.submatrix Fin.succ (2 : Fin 5).succAbove).det) + (-((0) * (m61.submatrix Fin.succ (3 : Fin 5).succAbove).det)) + ((0) * (m61.submatrix Fin.succ (4 : Fin 5).succAbove).det) = _
    rw [hm611]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  have hm6 : m6.det = 0 := by
    rw [laplace6]
    change ((0) * (m6.submatrix Fin.succ (0 : Fin 6).succAbove).det) + (-((z) * m61.det)) + ((0) * (m6.submatrix Fin.succ (2 : Fin 6).succAbove).det) + (-((0) * (m6.submatrix Fin.succ (3 : Fin 6).succAbove).det)) + ((0) * (m6.submatrix Fin.succ (4 : Fin 6).succAbove).det) + (-((0) * (m6.submatrix Fin.succ (5 : Fin 6).succAbove).det)) = _
    rw [hm61]
    simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  rw [laplace7 (physicalPencil z a b₀ b₁ kp I₀ I₁ α d)]
  have c0 : (physicalPencil z a b₀ b₁ kp I₀ I₁ α d) 0 0 = z := rfl
  have c1 : (physicalPencil z a b₀ b₁ kp I₀ I₁ α d) 0 1 = 0 := rfl
  have c2 : (physicalPencil z a b₀ b₁ kp I₀ I₁ α d) 0 2 = 0 := rfl
  have c3 : (physicalPencil z a b₀ b₁ kp I₀ I₁ α d) 0 3 = 0 := rfl
  have c4 : (physicalPencil z a b₀ b₁ kp I₀ I₁ α d) 0 4 = 0 := rfl
  have c5 : (physicalPencil z a b₀ b₁ kp I₀ I₁ α d) 0 5 = 0 := rfl
  have c6 : (physicalPencil z a b₀ b₁ kp I₀ I₁ α d) 0 6 = kp := rfl
  rw [c0,c1,c2,c3,c4,c5,c6]
  simp only [zero_mul, mul_zero, zero_add, add_zero, neg_zero]
  rw [hm0, hm6]
  ring

/-- Appendix B, equation (31). This uses the actual 7×7 determinant and
retains all zero modes, including poles concealed by transfer cancellation. -/
theorem matched_seven_state (z a b₀ b₁ kp I₀ I₁ α d f ζ t : ℝ)
    (h₀ : kp+I₀+d = f+ζ) (h₁ : -kp*(1+α)+I₁-α*I₀-2*d = -a*ζ)
    (h₂ : kp*α-I₁*α+d = 0) (hα : α = -ζ*b₁) (ht : t+ζ*(b₀+b₁)=1) :
    (physicalPencil z a b₀ b₁ kp I₀ I₁ α d).det =
      z^5*(z^2-(a+t-b₀*f)*z+(a*t+b₁*f)) := by
  rw [physical_determinant,h₀,h₁,h₂,hα]
  have ht' : t = 1-ζ*(b₀+b₁) := by linarith
  rw [ht']; ring


/-- The real state matrix of the zero-reference linear loop. -/
def physicalMatrix (a b₀ b₁ kp I₀ I₁ α d : ℝ) : Matrix (Fin 7) (Fin 7) ℝ :=
  -physicalPencil 0 a b₀ b₁ kp I₀ I₁ α d

theorem physical_pencil_eq (z a b₀ b₁ kp I₀ I₁ α d : ℝ) :
    physicalPencil z a b₀ b₁ kp I₀ I₁ α d =
      z • (1 : Matrix (Fin 7) (Fin 7) ℝ) - physicalMatrix a b₀ b₁ kp I₀ I₁ α d := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [physicalPencil, physicalMatrix, Matrix.one_apply]
  all_goals ring

private theorem eval_characteristic {ι : Type*} [Fintype ι] [DecidableEq ι]
    (z : ℝ) (M : Matrix ι ι ℝ) :
    M.charpoly.eval z = (z • (1 : Matrix ι ι ℝ) - M).det := by
  have h := (Polynomial.evalRingHom z).map_det M.charmatrix
  change M.charpoly.eval z = (M.charmatrix.map (Polynomial.evalRingHom z)).det at h
  rw [h]
  congr 1
  ext i j
  by_cases he : i=j
  · subst j; simp [Matrix.one_apply]
  · simp [Matrix.charmatrix_apply_ne,he,Matrix.one_apply]

open Polynomial in
/-- Polynomial form includes all roots over the complex numbers with multiplicity. -/
theorem physical_characteristic_polynomial (a b₀ b₁ kp I₀ I₁ α d f ζ t : ℝ)
    (h₀ : kp+I₀+d = f+ζ) (h₁ : -kp*(1+α)+I₁-α*I₀-2*d = -a*ζ)
    (h₂ : kp*α-I₁*α+d = 0) (hα : α = -ζ*b₁) (ht : t+ζ*(b₀+b₁)=1) :
    (physicalMatrix a b₀ b₁ kp I₀ I₁ α d).charpoly =
      X^5*(X^2-C (a+t-b₀*f)*X+C (a*t+b₁*f)) := by
  apply Polynomial.funext
  intro z
  rw [eval_characteristic, ← physical_pencil_eq,
    matched_seven_state z a b₀ b₁ kp I₀ I₁ α d f ζ t h₀ h₁ h₂ hα ht]
  simp

open Polynomial in
/-- Every branch realization constructed in Theorem 4.2 has the displayed
full characteristic polynomial. The two integral coefficients are κγ and κ(1−γ). -/
theorem matched_branch_characteristic (a b₀ b₁ kp κ γ α d f ζ t η b c : ℝ)
    (hc : Matching.channels α (Matching.realization kp κ d γ b c) =
       Matching.target α a f ζ η) (hα : α = -ζ*b₁) (ht : t+ζ*(b₀+b₁)=1) :
    (physicalMatrix a b₀ b₁ kp (κ*γ) (κ*(1-γ)) α d).charpoly =
      X^5*(X^2-C (a+t-b₀*f)*X+C (a*t+b₁*f)) := by
  have c₀ := congrArg (fun q : Matching.Channels => q.y.c0) hc
  have c₁ := congrArg (fun q : Matching.Channels => q.y.c1) hc
  have c₂ := congrArg (fun q : Matching.Channels => q.y.c2) hc
  simp only [Matching.channels, Matching.realization, Matching.target] at c₀ c₁ c₂
  apply physical_characteristic_polynomial _ _ _ _ _ _ _ _ _ _ _ _ _ _ hα ht
  · linarith only [c₀]
  · linear_combination c₁
  · linear_combination c₂

/-- The two conjugate roots in the example of §4.4, including their moduli. -/
theorem rational_pair (σ : ℝ) (hs : σ^2=1) :
    let z : ℂ := ⟨1/4, σ*Real.sqrt 3/4⟩
    z^2-z/2+1/4=0 ∧ ‖z‖=1/2 := by
  dsimp only
  have hroot := Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 3)
  have hs' : (σ*Real.sqrt 3)^2=3 := by rw [mul_pow,hs,hroot,one_mul]
  constructor
  · apply Complex.ext
    · simp [pow_two, Complex.mul_re, Complex.sub_re, Complex.div_ofNat_re]
      nlinarith only [hs']
    · simp [pow_two, Complex.mul_im, Complex.sub_im, Complex.div_ofNat_im]
      ring
  · have hn := Complex.sq_norm (⟨1/4,σ*Real.sqrt 3/4⟩ : ℂ)
    simp only [Complex.normSq_apply] at hn
    nlinarith only [hn, hs', norm_nonneg (⟨1/4,σ*Real.sqrt 3/4⟩ : ℂ)]

end MPCPID.Appendices
