import MPCPID.OperatorPhase
import MPCPID.Conditioned
import MPCPID.Predictive

/-! Readback of one integral/filter correction on the actual five registers,
and a positive alternating-clock example with a strictly convex one-step target. -/
namespace MPCPID.PhaseExample
open PhysicalLift OperatorPhase GainGraph
noncomputable section

/-- Only the two output memories receive a post-actuation correction. -/
def write (x : V 5) (a b : ℝ) : V 5 :=
  ![x 0, x 1 + a, x 2 + b, x 3, x 4]

theorem command_write (x : V 5) (a b : ℝ) :
    command (write x a b) = command x + a + b := by
  simp [command, write]
  ring

/-- Holding the filter preserves the entire correction in that register. -/
theorem tick_write (g : Coeff ℝ) (s : Flags) (v : V 2) (x : V 5) (a b : ℝ) :
    tick g s v (write x a b) =
      write (tick g s v x) a ((if s.d then g.α else 1) * b) := by
  obtain ⟨p,i,d⟩ := s
  funext j
  fin_cases j <;> cases d <;>
    simp [tick,Periodic.drivenBranches, write, bit] <;> ring

/-- The flags start at the first tick *after* the correction was written. -/
def events (s : ℕ → Flags) : ℕ → ℕ
  | 0 => 0
  | j+1 => events s j + (if (s j).d then 1 else 0)

theorem propagated_write (g : Coeff ℝ) (s : ℕ → Flags) (v : ℕ → V 2)
    (x : V 5) (a b : ℝ) (j : ℕ) :
    run g s v (write x a b) j =
      write (run g s v x j) a (g.α ^ events s j * b) := by
  induction j with
  | zero => simp [run, events]
  | succ j ih =>
    rw [run, ih, tick_write, run]
    cases h : (s j).d
    · simp [events,h]
    · simp [events,h,pow_succ,mul_left_comm,mul_comm]

/-- Exact difference between the physically updated commands for the same
measured reference/output history, for arbitrary phase order and initial memories. -/
theorem physical_impulse (g : Coeff ℝ) (s : ℕ → Flags) (v : ℕ → V 2)
    (x : V 5) (a b : ℝ) (j : ℕ) :
    command (run g s v (write x a b) j) - command (run g s v x j) =
      a + g.α ^ events s j * b := by
  rw [propagated_write, command_write]
  ring

/-- Feasibility of a unit readback kernel at the injecting phase. -/
def Fits (s₀ : Flags) (α : ℝ) (s : ℕ → Flags) (h : ℕ → ℝ) : Prop :=
  ∃ a b : ℝ, (s₀.i = false → a = 0) ∧ (s₀.d = false → b = 0) ∧
    a+b=1 ∧ ∀ j, h j = a + α ^ events s j * b

theorem held_iff (p : Bool) (α : ℝ) (s : ℕ → Flags) (h : ℕ → ℝ) :
    ¬ Fits ⟨p,false,false⟩ α s h := by
  rintro ⟨a,b,hi,hd,hs,_⟩
  have ha := hi rfl
  have hb := hd rfl
  linarith

theorem integral_only_iff (p : Bool) (α : ℝ) (s : ℕ → Flags) (h : ℕ → ℝ) :
    Fits ⟨p,true,false⟩ α s h ↔ ∀ j, h j = 1 := by
  constructor
  · rintro ⟨a,b,_,hb,hs,hj⟩ j
    have hb' := hb rfl
    simpa [hb',show a=1 by linarith] using hj j
  · intro allj
    exact ⟨1,0,by simp,by simp,by norm_num,by simpa using allj⟩

theorem derivative_only_iff (p : Bool) (α : ℝ) (s : ℕ → Flags) (h : ℕ → ℝ) :
    Fits ⟨p,false,true⟩ α s h ↔ ∀ j, h j = α ^ events s j := by
  constructor
  · rintro ⟨a,b,ha,_,hs,hj⟩ j
    have ha' := ha rfl
    simpa [ha',show b=1 by linarith] using hj j
  · intro allj
    exact ⟨0,1,by simp,by simp,by norm_num,by simpa using allj⟩

theorem both_iff (p : Bool) {α : ℝ} (hα : α ≠ 1) (s : ℕ → Flags)
    (h : ℕ → ℝ) (first : ℕ) (one : events s first = 1) :
    Fits ⟨p,true,true⟩ α s h ↔
      ∀ j, h j = 1 - (1-h first)/(1-α) + α ^ events s j * ((1-h first)/(1-α)) := by
  constructor
  · rintro ⟨a,b,_,_,hs,he⟩
    have hf := he first
    rw [one,pow_one] at hf
    have hb : (1-h first)/(1-α) = b := by
      apply (div_eq_iff (sub_ne_zero.mpr (Ne.symm hα))).2
      linarith only [hs, hf, mul_sub b 1 α, mul_comm b α, mul_one b]
    intro j
    rw [hb, he j]
    linarith only [hs]
  · intro he
    refine ⟨1 - (1-h first)/(1-α), (1-h first)/(1-α), by simp, by simp, ?_, he⟩
    ring

/-- The target tracks a nominal command q and its increment for a predictor
with manipulated variable u. The previous applied and nominal values are known. -/
def cost (q qold uold v : ℝ) :=
  (v-q)^2 + ((v-uold)-(q-qold))^2

def target (q qold uold : ℝ) := q + (uold-qold)/2

theorem gain_cost (q qold uold v : ℝ) :
    cost q qold uold v - cost q qold uold (target q qold uold) =
      2*(v - target q qold uold)^2 := by
  unfold cost target
  ring

theorem target_unique (q qold uold v : ℝ) :
    cost q qold uold v ≤ cost q qold uold (target q qold uold) ↔
      v=target q qold uold := by
  have H := gain_cost q qold uold v
  constructor
  · intro hv
    by_contra h
    have hpos := sq_pos_of_ne_zero (sub_ne_zero.mpr h)
    linarith
  · rintro rfl
    exact le_rfl

theorem projected_target {L H u : ℝ} (order : L ≤ H) (lower : L ≤ u) (upper : u ≤ H)
    (q qold uold : ℝ) (different : u ≠ Conditioned.clip L H (target q qold uold)) :
    cost q qold uold (Conditioned.clip L H (target q qold uold)) < cost q qold uold u := by
  have dist := Predictive.clip_strict order lower upper different
  change (Conditioned.clip L H (target q qold uold)-target q qold uold)^2 < _ at dist
  linarith only [gain_cost q qold uold u,
    gain_cost q qold uold (Conditioned.clip L H (target q qold uold)), dist]

theorem nominal_target (q qold : ℝ) : target q qold qold = q := by simp [target]

/-- In free operation the predictor follows every command history issued by the
nominal reference model, including those generated by the multirate hardware. -/
theorem all_nominal (q u : ℕ → ℝ) (init : u 0 = q 0)
    (move : ∀ k, u (k+1) = target (q (k+1)) (q k) (u k)) : ∀ k, u k = q k := by
  intro k
  induction k with
  | zero => exact init
  | succ k ih => rw [move, ih, nominal_target]

/-- Clock period two, with a fast proportional branch. -/
def integralTick : Flags := ⟨true,true,false⟩
def derivativeTick : Flags := ⟨true,false,true⟩
def controller : Physical := ⟨1,2,4,2,1/2,1,1/2,1/2⟩
def gains := rational 2 2 controller

theorem physical_choice : Admissible controller ∧ gains.α = 1/2 ∧ gains.β = 1 := by
  norm_num [controller,gains,rational,Admissible]

/-- Sample 1, following a rest sample, has r=1 and y=0. The plant
y[k+1]=u[k] still gives y[2]=0 after clipping to zero. -/
def peak := tick gains derivativeTick ![1,0] 0

theorem pulse_from_rest :
    tick gains integralTick ![0,0] 0 = 0 ∧ command peak = 1 := by
  constructor
  · funext j
    fin_cases j <;> norm_num [tick,integralTick,Periodic.drivenBranches,bit]
  · norm_num [peak,tick,derivativeTick,Periodic.drivenBranches,bit,command,
      gains,rational,controller,Matrix.cons_val_two,Matrix.cons_val_three,Matrix.cons_val_four]

/-- A singleton bound at sample 1 forces the unique admissible correction.
At the next sample [-1,1] leaves both proposals untouched, exposing the
disagreement of the actual applied commands. -/
theorem alternating_obstruction (a b : ℝ)
    (held : a = 0) (readback : command (write peak a b) = Conditioned.clip 0 0 (command peak)) :
    let q := command (tick gains integralTick ![0,0] peak)
    let v := command (tick gains integralTick ![0,0] (write peak a b))
    let z := target q (command peak) 0
    b = -1 ∧ q = 1/2 ∧ v = -1/2 ∧ z = 0 ∧
      Conditioned.clip (-1) 1 v ≠ Conditioned.clip (-1) 1 z := by
  have hpeak := pulse_from_rest.2
  rw [command_write,hpeak,held] at readback
  norm_num [Conditioned.clip] at readback
  have hb : b = -1 := by linarith
  subst a
  subst b
  norm_num [peak,tick,derivativeTick,integralTick,Periodic.drivenBranches,bit,
    command,gains,rational,controller,write,target,Conditioned.clip,Matrix.cons_val_two,Matrix.cons_val_three,Matrix.cons_val_four,min_def,max_def]

end
end MPCPID.PhaseExample
