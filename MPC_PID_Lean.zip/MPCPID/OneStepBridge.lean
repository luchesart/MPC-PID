import MPCPID.Matching
import MPCPID.Predictive
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic

/-! Connect the explicit MIACE optimizer in Theorem 8.1 to the full nominal
trajectory theorem for the positive controller family in Theorem 4.2. -/

namespace MPCPID.OneStepBridge
open MPCPID.Predictive MPCPID.Matching
open scoped Matrix
noncomputable section

/-- The coefficient construction realizes the unique unconstrained MIACE
first move and reproduces its nominal trajectories at every sample. The two
initial input slots include the common input history in the plant model. -/
theorem one_step_matched_trajectories (a b c l : ℝ) (ha₀ : 0 ≤ a) (ha : a < 1)
    (hb : 0 < b) (hc : 0 < c) (hl : max 0 (c^2-b^2) < l) :
    let ζ := zeta b c l
    let α := -ζ*c
    let η := eta a b c l
    let f := fy a b l
    (-1 < α ∧ α < 1) ∧ PositiveRealization α (target α a f ζ η) ∧
    ∀ (uP uM yP yM r : ℕ → ℝ),
      (∀ k, yP (k+1)=a*yP k+b*uP (k+1)+c*uP k) →
      (∀ k, yM (k+1)=a*yM k+b*uM (k+1)+c*uM k) →
      (∀ k, uP (k+2)-(1+α)*uP (k+1)+α*uP k-η*r k+
          (f+ζ)*yP (k+1)-a*ζ*yP k=0) →
      (∀ k, uM (k+2)=minimizer b l ((1-a)*r k/(b+c))
          (r k-a*yM (k+1)-c*uM (k+1))) →
      yP 0=yM 0 → uP 0=uM 0 → uP 1=uM 1 →
      ∀ k, yP k=yM k ∧ uP k=uM k ∧ uP (k+1)=uM (k+1) := by
  have hl' : 0 < l := (le_max_left _ _).trans_lt hl
  obtain ⟨hη,hζ,hα⟩ := realization_hypotheses a b c l ha hb hc hl
  obtain ⟨he,ht⟩ := equilibrium_gains a b c l hb hc hl'
  have ht' : memoryGain b c l + zeta b c l*(b+c)=1 := by
    rw [ht]
    field_simp [ne_of_gt (add_pos hb hc)]

  obtain ⟨h₁,h₂,h₃⟩ := constructive_nominal_matching ha₀ hζ hη hc hα he ht'
  refine ⟨h₁,h₂,?_⟩
  intro uP uM yP yM r pPlant mPlant pLaw mLaw
  apply h₃ uP uM yP yM r pPlant mPlant pLaw
  intro k
  rw [mLaw,first_move a b c l _ _ _ hb hc hl']

/-- Characteristic determinant of (67), evaluated at an arbitrary complex
spectral parameter; repeated zero poles are included. -/
theorem complex_target_spectrum (a b c l : ℝ) (hl : 0<l) (z : ℂ) :
    Matrix.det !![z - (a*l/(b^2+l):ℝ), -(c*l/(b^2+l):ℝ);
      (a*b/(b^2+l):ℝ), z+(b*c/(b^2+l):ℝ)] = 0 ↔
      z=0 ∨ z=(pole a b c l : ℝ) := by
  rw [Matrix.det_fin_two_of]
  have hD : b^2+l≠0 := ne_of_gt (add_pos_of_nonneg_of_pos (sq_nonneg _) hl)
  have hd : (a*l/(b^2+l):ℝ)*(b*c/(b^2+l))=(c*l/(b^2+l))*(a*b/(b^2+l)) := by
    field_simp
    ring
  have ht : a*l/(b^2+l)-b*c/(b^2+l)=pole a b c l := by
    unfold pole; ring
  have hdc : ((a*l/(b^2+l):ℝ):ℂ)*((b*c/(b^2+l):ℝ):ℂ) =
      ((c*l/(b^2+l):ℝ):ℂ)*((a*b/(b^2+l):ℝ):ℂ) := by exact_mod_cast hd
  have htc : ((a*l/(b^2+l):ℝ):ℂ)-((b*c/(b^2+l):ℝ):ℂ) =
      ((pole a b c l:ℝ):ℂ) := by exact_mod_cast ht
  have hfactor : (z-((a*l/(b^2+l):ℝ):ℂ))*(z+((b*c/(b^2+l):ℝ):ℂ)) -
      (-((c*l/(b^2+l):ℝ):ℂ))*((a*b/(b^2+l):ℝ):ℂ) =
      z*(z-((pole a b c l : ℝ):ℂ)) := by
    rw [← htc]
    linear_combination -hdc
  rw [hfactor,mul_eq_zero,sub_eq_zero]

end
end MPCPID.OneStepBridge
