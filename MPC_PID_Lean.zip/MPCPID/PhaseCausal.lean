import MPCPID.PhaseFeedback
import MPCPID.PhaseColumns

/-! End-to-end multirate physical criterion for arbitrary causal interval
policies, observable from applied commands alone. -/
namespace MPCPID.PhaseCausal
open PhysicalLift Periodic PhaseCorrection PhaseColumns
noncomputable section

def intervalPolicy {σ : Type*} (lo hi : ℕ → σ → ℝ) (step : ℕ → σ → ℝ → σ) :
    Actuator σ := ⟨fun k z => Conditioned.clip (lo k z) (hi k z), step⟩

/-- Policy state can carry every prior applied input and can reconstruct the
common measured plant state. The initial policy state is shared. -/
def CausalApplied {σ : Type*} {n t : ℕ} (S : Loop n) (T : Loop t)
    (x : Mat n 1) (y : Mat t 1) (z : σ) : Prop :=
  ∀ (lo hi : ℕ → σ → ℝ) (step : ℕ → σ → ℝ → σ), (∀ k w, lo k w ≤ hi k w) →
    let P := intervalPolicy lo hi step
    ∀ k, let p := S.coupled x P z k
         let q := T.coupled y P z k
         P.apply k p.2 (S.rawAt k p.1) = P.apply k q.2 (T.rawAt k q.1)

theorem causal_applied_iff_free {σ : Type*} {n t : ℕ} (S : Loop n) (T : Loop t)
    (x : Mat n 1) (y : Mat t 1) (z : σ) :
    CausalApplied S T x y z ↔ ∀ δ k, S.freeRaw x δ k = T.freeRaw y δ k := by
  constructor
  · intro h
    apply (applied_only_iff_free S T x y).1
    intro lo hi ordered act k
    let P : Actuator σ := intervalPolicy (fun k _ => lo k) (fun k _ => hi k) (fun _ w _ => w)
    have same {m : ℕ} (U : Loop m) (a : Mat m 1) (j : ℕ) :
        U.coupled a P z j = (U.closed a act j,z) := by
      induction j with
      | zero => rfl
      | succ j ih =>
        simp only [Loop.coupled,Loop.closed,ih]
        rfl
    have eq := h (fun j _ => lo j) (fun j _ => hi j) (fun _ w _ => w) (fun j _ => ordered j) k
    change P.apply k (S.coupled x P z k).2 (S.rawAt k (S.coupled x P z k).1) =
      P.apply k (T.coupled y P z k).2 (T.rawAt k (T.coupled y P z k).1) at eq
    rw [same S x k,same T y k] at eq
    exact eq
  · intro h lo hi step _ P k
    exact (causal_actuator_matching S T x y P z h k).2.2

/-- Causal policies may share any state type and initial state. Testing only
their applied commands for every such policy is already equivalent to the
finite post-discrepancy equations for the actual physical system. -/
theorem physical_causal_iff_columns {σ : Type*} {n t L : ℕ} (hL : 0 < L)
    (p : Plant ℝ n) (g : GainGraph.Coeff ℝ) (flags : ℕ → Flags)
    (i d r : ℕ → ℝ) (T : Loop t) (x : Mat (n+5) 1) (y : Mat t 1) (z : σ)
    (h0 : ∀ k, (physicalLoop p g flags i d r).freeRaw x 0 k = T.freeRaw y 0 k)
    (hf : ∀ k, flags (k+L)=flags k) (hi : ∀ k, i (k+L)=i k) (hd : ∀ k, d (k+L)=d k)
    (hA : ∀ k, T.A (k+L)=T.A k) (hC : ∀ k, T.C (k+L)=T.C k)
    (hE : ∀ k, T.E (k+L)=T.E k) :
    let S := physicalLoop p g flags i d r
    CausalApplied S T x y z ↔
    ∀ (s : Fin L) (q : Fin (n+5+t) × Fin L),
      let O := observationRows S T s
      observe O p.B (T.E s) 0 0 q + i s * observe O 0 0 1 0 q +
        d s * observe O 0 0 0 1 q = 0 := by
  let S := physicalLoop p g flags i d r
  exact (causal_applied_iff_free S T x y z).trans ((free_iff_all_intervals S T x y).trans
    (physical_projected_iff_columns hL p g flags i d r T x y h0 hf hi hd hA hC hE))

end
end MPCPID.PhaseCausal
