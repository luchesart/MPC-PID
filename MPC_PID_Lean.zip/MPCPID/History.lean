import MPCPID.Integration
import Mathlib.Tactic.NormNum

/-! Local memory identities with arbitrary compatible past samples. -/
namespace MPCPID.History
open Conditioned

/-- At a switching instant all earlier measurements and applied inputs may
be nonzero. The two most recent genuine branch updates determine the
coefficient equation; no zero prehistory is used. -/
theorem corrected_sample {K κ d g b c α a f ζ η : ℝ} (hα : α ≠ 1)
    (hfit : Matching.channels α (Matching.realization K κ d g b c) =
      Matching.target α a f ζ η)
    (r₀ r₁ r₂ y₀ y₁ y₂ i₀ df₀ δ₁ δ₂ : ℝ) :
    let i₁ := i₀+κ*g*(r₁-y₁)+κ*(1-g)*(r₀-y₀)+δ₁/(1-α)
    let i₂ := i₁+κ*g*(r₂-y₂)+κ*(1-g)*(r₁-y₁)+δ₂/(1-α)
    let d₁ := α*df₀+d*(c*r₁-y₁-c*r₀+y₀)-α*δ₁/(1-α)
    let d₂ := α*d₁+d*(c*r₂-y₂-c*r₁+y₁)-α*δ₂/(1-α)
    let u₀ := K*(b*r₀-y₀)+i₀+df₀
    let u₁ := K*(b*r₁-y₁)+i₁+d₁
    let u₂ := K*(b*r₂-y₂)+i₂+d₂
    u₂-(1+α)*u₁+α*u₀ = η*r₂-(f+ζ)*y₂+a*ζ*y₁+δ₂ := by
  let r : Signal := fun k => if k=0 then r₀ else if k=1 then r₁ else r₂
  let y : Signal := fun k => if k=0 then y₀ else if k=1 then y₁ else y₂
  obtain ⟨hr,hy⟩ := Integration.numerator_taps hfit r y 2
  norm_num [r,y,tap,lag] at hr hy
  dsimp only
  field_simp [sub_ne_zero.mpr (Ne.symm hα)]
  linear_combination (1-α)*hr - (1-α)*hy

/-- Samplewise nominal identity at an arbitrary compatible history. Together
with corrected_sample this gives the raw predictive move for every switch. -/
theorem corrected_raw_at {a b₀ b₁ η f t ζ α u₀ u₁ u₂ raw δ y₁ y₂ r : ℝ}
    (hpole : α = -ζ*b₁) (ht : t+ζ*(b₀+b₁)=1)
    (hplant : y₂ = a*y₁+b₀*u₁+b₁*u₀)
    (hden : u₂-(1+α)*u₁+α*u₀ = η*r-(f+ζ)*y₂+a*ζ*y₁+δ)
    (hd : δ=u₂-raw) :
    raw = η*r - f*y₂ + t*u₁ := by
  rw [hpole, hd] at hden
  linear_combination hden - ζ*hplant - u₁*ht

/-- Two prefix samples encode a compatible nonzero history. Every later
sample in this statement is obtained from the physical branch equations;
there is no requirement that the initial stored integral or filter be zero. -/
theorem all_compatible_samples {K κ d g b c α a f ζ η b₀ b₁ t : ℝ}
    (hα : α ≠ 1) (hpole : α = -ζ*b₁) (ht : t+ζ*(b₀+b₁)=1)
    (hfit : Matching.channels α (Matching.realization K κ d g b c) =
      Matching.target α a f ζ η)
    (r y u raw i df δ L H : Signal)
    (hu : ∀ n, u n = K*(b*r n-y n)+i n+df n)
    (hi : ∀ n, i (n+1) = i n+κ*g*(r (n+1)-y (n+1))+
       κ*(1-g)*(r n-y n)+δ (n+1)/(1-α))
    (hd : ∀ n, df (n+1) = α*df n+d*(c*r (n+1)-y (n+1)-c*r n+y n)
       -α*δ (n+1)/(1-α))
    (plant : ∀ n, y (n+2)=a*y (n+1)+b₀*u (n+1)+b₁*u n)
    (delta : ∀ n, δ (n+2)=u (n+2)-raw (n+2))
    (act : ∀ n, u (n+2)=clip (L (n+2)) (H (n+2)) (raw (n+2))) :
    ∀ n, raw (n+2)=η*r (n+2)-f*y (n+2)+t*u (n+1) ∧
      u (n+2)=clip (L (n+2)) (H (n+2)) (η*r (n+2)-f*y (n+2)+t*u (n+1)) := by
  intro n
  have hp := corrected_sample hα hfit (r n) (r (n+1)) (r (n+2))
    (y n) (y (n+1)) (y (n+2)) (i n) (df n) (δ (n+1)) (δ (n+2))
  dsimp only at hp
  rw [← hi n, ← hd n, ← hi (n+1), ← hd (n+1),
      ← hu (n+2), ← hu (n+1), ← hu n] at hp
  have hraw := corrected_raw_at hpole ht (plant n) hp (delta n)
  exact ⟨hraw, by rw [act n,hraw]⟩

noncomputable def unitBox : Box :=
  ⟨1/2, 1, 1, 1, 1, by norm_num, by norm_num, by norm_num, by norm_num, by norm_num, by norm_num⟩

theorem viable_counterexample :
    unitBox.upper 0 0 = 2/3 ∧
    clip 0 (unitBox.upper 0 0) (41/44) = 2/3 ∧
    unitBox.upper (2/3) (2/3) = 0 ∧ unitBox.next (2/3) (2/3) 0 = 1 ∧
    ¬ unitBox.safe (41/44) (41/44) := by
  norm_num [unitBox, Box.upper, Box.next, Box.safe, Box.inside, clip, min_def, max_def]

end MPCPID.History
