import MPCPID.PhysicalLift

/-! Actual PID operator semantics and chronological input selection.
The reference and measured output form two freely chosen scalar inputs.
An operator experiment does not impose a plant relation on them. -/
namespace MPCPID.OperatorPhase

open MPCPID.Periodic MPCPID.PhysicalLift
open MPCPID.GainGraph (Coeff)

abbrev V (n : ℕ) := Fin n → ℝ

/-- The five physical branches after evaluating a single phase. -/
def tick (g : Coeff ℝ) (s : Flags) (v : V 2) (x : V 5) : V 5 :=
  drivenBranches (bit s.p) (bit s.i) (bit s.d) g.K g.i0 g.i1 g.α g.β g.b g.c
    (v 0) (v 1) x

def command (x : V 5) := x 0 + x 1 + x 2

/-- Columns in the symbolic operator realization have the order (r,y). -/
theorem phase_state (g : Coeff ℝ) (s : Flags) (v : V 2) (x : V 5) :
    tick g s v x = (operatorPhase g s).A.mulVec x + (operatorPhase g s).B.mulVec v := by
  rw [tick,physicalPhaseMatrices]
  have col0 (j : Fin 5) : (operatorPhase g s).B j 0 = (Gr g s) j 0 := rfl
  have col1 (j : Fin 5) : (operatorPhase g s).B j 1 = (Gy g s) j 0 := rfl
  funext j
  change _ + v 1 * _ + v 0 * _ = _ + ((operatorPhase g s).B.mulVec v) j
  simp only [Matrix.mulVec, dotProduct, Fin.sum_univ_two, col0, col1]
  dsimp only [operatorPhase,F,Gy,Gr,column]
  ring

theorem read_updates (x : V 5) : (readBranches ℝ).mulVec x 0 = command x := by
  simp [readBranches,Matrix.mulVec,dotProduct,Fin.sum_univ_succ,command,add_assoc]

theorem phase_output (g : Coeff ℝ) (s : Flags) (v : V 2) (x : V 5) :
    command (tick g s v x) =
      ((operatorPhase g s).C.mulVec x + (operatorPhase g s).D.mulVec v) 0 := by
  rw [←read_updates,phase_state,Matrix.mulVec_add, Pi.add_apply]
  simp only [operatorPhase, Matrix.mulVec_mulVec, Pi.add_apply]

/-- The input vector stored in a frame in chronological order. -/
def stack {m L : ℕ} (v : Fin L → V m) : M ℝ (L*m) 1 :=
  fun j _ => let t := finProdFinEquiv.symm j; v t.1 t.2

theorem selector_reads_stack {L m : ℕ} (j : Fin L) (v : Fin L → V m) :
    selector L m j * stack v = column (v j) := by
  ext i k
  let s : Fin (L*m) := finProdFinEquiv (j,i)
  have hs : finProdFinEquiv.symm s = (j,i) := Equiv.symm_apply_apply _ _
  rw [Matrix.mul_apply, Finset.sum_eq_single s]
  · simp [selector,stack,column,hs]
  · intro k _ h
    have hNot : ¬ ((finProdFinEquiv.symm k : Fin L × Fin m).1.val = j.val ∧
        (finProdFinEquiv.symm k : Fin L × Fin m).2 = i) := by
      rintro ⟨h₁,h₂⟩
      exact h (finProdFinEquiv.symm.injective (hs ▸ Prod.ext (Fin.ext h₁) h₂))
    simp only [selector, if_neg hNot, zero_mul]
  · simp

theorem selector_one_reads {L : ℕ} (j : Fin L) (v : Fin L → ℝ) :
    (selector₁ L j : M ℝ 1 L) * column v = column (fun _ => v j) := by
  ext i k
  rw [Matrix.mul_apply, Finset.sum_eq_single j]
  · simp [selector₁,column]
  · intro e _ he
    have : e.val ≠ j.val := fun h => he (Fin.ext h)
    simp [selector₁,this]
  · simp

/-- Step through arbitrary independent signal streams without transforming them. -/
def run (g : Coeff ℝ) (flags : ℕ → Flags) (v : ℕ → V 2) (x : V 5) : ℕ → V 5
  | 0 => x
  | k+1 => tick g (flags k) (v k) (run g flags v x k)

private theorem column_mulVec {n m : ℕ} (A : M ℝ n m) (x : V m) :
    column (A.mulVec x) = A*column x := by
  ext i j
  rfl

theorem run_state (g : Coeff ℝ) (s : ℕ → Flags) (v : ℕ → V 2) (x : V 5) (k : ℕ) :
    column (run g s v x k) =
      frameState (fun j => (operatorPhase g (s j)).A) (fun j => (operatorPhase g (s j)).B)
        (fun j => column (v j)) (column x) k := by
  induction k with
  | zero => rfl
  | succ k ih =>
    simp only [run,frameState,phase_state]
    rw [←ih]
    rw [← column_mulVec,← column_mulVec]
    rfl

private theorem framed_state (g : Coeff ℝ) (s : ℕ → Flags) (v : ℕ → V 2)
    (x : V 5) (L k : ℕ) (hk : k ≤ L) :
      column (run g s v x k) =
      frameState (fun j => (operatorPhase g (s j)).A) (fun j => (operatorPhase g (s j)).B)
        (fun j => selector L 2 j * stack (fun t : Fin L => v t)) (column x) k := by
    induction k with
    | zero => rfl
    | succ k ih =>
      have ht := selector_reads_stack (m:=2) (⟨k,hk⟩ : Fin L) (fun t => v t)
      have hv : selector L 2 k * stack (fun t : Fin L => v t) = column (v k) := ht
      simp only [frameState,← ih (by omega),hv,run,phase_state]
      rw [←column_mulVec,←column_mulVec]
      rfl

theorem operator_frame_end (g : Coeff ℝ) (s : ℕ → Flags) (v : ℕ → V 2) (x : V 5) (L : ℕ) :
    column (run g s v x L) =
      (operatorFrame g s L).A * column x + (operatorFrame g s L).B * stack (fun j => v j) := by
  exact (framed_state g s v x L L le_rfl).trans (frameState_lift _ _ (selector L 2) _ _ L)

theorem operator_frame_command (g : Coeff ℝ) (s : ℕ → Flags)
    (v : ℕ → V 2) (x : V 5) {L : ℕ} (k : Fin L) :
    command (run g s v x (k+1)) =
    ((operatorFrame g s L).C * column x +
       (operatorFrame g s L).D * stack (fun j : Fin L => v j) : M ℝ (L*1) 1) (finProdFinEquiv (k,0)) 0 := by
  let t := fun j => operatorPhase g (s j)
  let allv := stack (fun j : Fin L => v j)
  have hsel : selector L 2 k * allv = column (v k) := selector_reads_stack k _
  have H := withinFrameOutput (fun j => (t j).A) (fun j => (t j).B)
    (fun j => (t j).C) (fun j => (t j).D) (selector L 2) allv (column x) k
  rw [←framed_state g s v x L k k.isLt.le, hsel] at H
  rw [←column_mulVec,←column_mulVec] at H
  have hr := congrFun (congrFun H 0) 0
  rw [run,phase_output,Pi.add_apply]
  change _ = ((operatorFrame g s L).C * column x : M ℝ (L*1) 1) (finProdFinEquiv (k,0)) 0 +
      ((operatorFrame g s L).D * allv : M ℝ (L*1) 1) (finProdFinEquiv (k,0)) 0
  refine hr.trans ?_
  simp only [Matrix.mul_apply,operatorFrame,frame,frameWith,Equiv.symm_apply_apply]
  rfl

private theorem run_append (g : Coeff ℝ) (s : ℕ → Flags) (v : ℕ → V 2)
    (x : V 5) (a b : ℕ) :
    run g s v x (a+b) =
      run g (fun k => s (a+k)) (fun k => v (a+k)) (run g s v x a) b := by
  induction b with
  | zero => rfl
  | succ b ih =>
    simp only [Nat.add_succ,run,←ih]
    rfl

/-- Iteration of the physical frame gives every boundary state and every command
of an infinite experiment with periodic flags and arbitrary input samples. -/
theorem operator_periodic_blocks (g : Coeff ℝ) (s : ℕ → Flags) (v : ℕ → V 2)
    (x : V 5) (L : ℕ) (hp : ∀ k, s (k+L) = s k) (q : ℕ) :
    let xq := column (run g s v x (q*L))
    let wq := stack (fun j : Fin L => v (q*L+j))
    let T := operatorFrame g s L
    column (run g s v x ((q+1)*L)) = T.A*xq + T.B*wq ∧
    ∀ k : Fin L, command (run g s v x (q*L+k+1)) =
      (T.C*xq + T.D*wq) (finProdFinEquiv (k,0)) 0 := by
  have hperiod (i k : ℕ) : s (i*L+k) = s k := by
    induction i with
    | zero => simp
    | succ i ih =>
      rw [Nat.succ_mul,show i*L+L+k = (i*L+k)+L by omega,hp,ih]
  have hflags : (fun k => s (q*L+k)) = s := funext (hperiod q)
  have hstart (b : ℕ) : run g s v x (q*L+b) =
      run g s (fun k => v (q*L+k)) (run g s v x (q*L)) b := by
    rw [run_append g s v x (q*L) b,hflags]
  dsimp only
  constructor
  · rw [Nat.succ_mul,hstart L]
    exact operator_frame_end g s _ _ L
  · intro k
    rw [Nat.add_assoc,hstart ((k : ℕ)+1)]
    exact operator_frame_command g s _ _ k
end MPCPID.OperatorPhase
