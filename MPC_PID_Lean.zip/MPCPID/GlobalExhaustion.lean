import MPCPID.GlobalSynthesis
import MPCPID.NoZeroTarget

/-! No exceptional zero transfer is left in the unrestricted nominal search.
A stable physical integrator supplies a nonzero target step-output sample;
Cayley–Hamilton locates a nonzero impulse coefficient among lags 1,...,t. -/
namespace MPCPID.GlobalExhaustion
open PhysicalLift PhysicalSchedule GainGraph GainReserve ClockCatalogue
open NominalLiftBridge GlobalSynthesis NoZeroTarget
open Periodic (Mat)
noncomputable section

/-- First-row output, retaining its matrix dimensions for the finite Markov test. -/
def firstRow {m o : ℕ} (X : Mat (o+1) m) : Mat 1 m := fun _ j => X 0 j

private theorem row_mul {m n o : ℕ} (X : Mat (o+1) n) (B : Mat n m) :
    firstRow (X*B) = firstRow X * B := by rfl

/-- Zero direct and first t dynamic coefficients force a zero step response on
the first output of an arbitrary t-state base-rate linear target. -/
theorem zero_step_of_finite_zeros {t : ℕ} (X : System ℝ t 1 2)
    (d0 : impulseOutput X 0 0 0 = 0)
    (dyn : ∀ j<t, impulseOutput X (j+1) 0 0=0) (n : ℕ) :
    (outputAt (fun _ => X) (fun _ => 1) n) 0 0 = 0 := by
  have zeroD : firstRow X.D = 0 := by
    ext i j
    fin_cases i; fin_cases j
    simpa [firstRow,impulseOutput_zero] using d0
  have marks (j : ℕ) : firstRow X.C * X.A^j * X.B = 0 := by
    apply Periodic.finiteMarkov
    intro k hk
    rw [← row_mul,← row_mul]
    ext i v
    fin_cases i; fin_cases v
    simpa [firstRow,impulseOutput_succ] using dyn k hk
  have all (k j : ℕ) :
      firstRow X.C * X.A^j * state (fun _ => X) (fun _ => 1) k = 0 := by
    induction k generalizing j with
    | zero => simp [state,Periodic.frameState]
    | succ k ih =>
      change firstRow X.C * X.A^j *
        (X.A * state (fun _ => X) (fun _ => 1) k + X.B * scalar 1) = 0
      rw [Matrix.mul_add,← Matrix.mul_assoc,← Matrix.mul_assoc,
        Matrix.mul_assoc (firstRow X.C) (X.A^j) X.A, ←pow_succ,ih,marks, Matrix.zero_mul,add_zero]
  have h := all n 0
  simp only [pow_zero,Matrix.mul_one] at h
  have out : firstRow (outputAt (fun _ => X) (fun _ => 1) n) = 0 := by
    change firstRow (X.C*state (fun _ => X) (fun _ => 1) n) +
      firstRow (X.D*scalar (1:ℝ)) = 0
    rw [row_mul,row_mul,h,zeroD,Matrix.zero_mul,add_zero]
  exact congrArg (fun x : Mat 1 1 => x 0 0) out

private theorem one_history (L q : ℕ) :
    history L (fun _ => 1) q = List.replicate q (ones L) := by
  induction q with
  | zero => rfl
  | succ q ih => rw [history,ih,List.replicate_succ]; rfl

/-- A realizable t-state target has some nonzero first-output coefficient among
the first t *positive* lags. This holds even for a nonminimal realization. -/
theorem feasible_nonzero_markov {n t : ℕ} (P : Plant ℝ n) (X : System ℝ t 1 2)
    {h R : ℝ} (hh : 0<h) (hR : 1≤R) (s : Pattern) (p : Physical)
    (ok : PhysicalDesign P X h R s p) :
    ∃ j : Fin t, impulseOutput X (j.val+1) 0 0 ≠ 0 := by
  obtain ⟨ad,mat,stable⟩ := ok
  let T := targetLift X (frameLength s)
  let g := rational ((clocks s).TI h) ((clocks s).TD h) p
  have hm := matches_impulse (clocks s) P g X mat
  have hy0 := (hm 0 0).1.symm
  have direct : impulseOutput X 0 0 0=0 := by
    simpa [NominalExecution.closedRun,NominalExecution.measure] using hy0
  have nominal := stable 1 ⟨le_rfl,hR⟩
  rw [scale_one] at nominal
  obtain ⟨q,k,step⟩ := matched_step_output_nonzero P p ad (clocks s) hh T nominal mat
  by_contra! onlyZero
  apply step
  let u : ℕ → ℝ := fun _ => 1
  have obs := output_from_lift (T := fun _ => X) (fun _ => rfl) u q k
  have hv : block (frameLength s) q u = ones (frameLength s) := rfl
  change outputAt (fun _ => X) u (q*frameLength s+k) =
    (T.C * Periodic.advance T.A T.B 0 (history (frameLength s) u q) + T.D*block (frameLength s) q u).submatrix
      (fun i => finProdFinEquiv (k,i)) id at obs
  rw [hv,show history (frameLength s) u q = _ from one_history _ q,← blocksAt_advance] at obs
  have found := congrArg (fun z : Mat 2 1 => z 0 0) obs
  exact found.symm.trans (zero_step_of_finite_zeros X direct (fun j hj => onlyZero ⟨j,hj⟩) _)

/-- Every feasible physical design lies in a single finite list derived just from
the dimension of its prescribed base-rate target, including targets with no
nonzero observed impulse response (which are infeasible). -/
theorem uniform_cutoff {n t : ℕ} (P : Plant ℝ n) (X : System ℝ t 1 2)
    {h R : ℝ} (hh : 0<h) (hr : 1≤R) (s : Pattern) (p : Physical)
    (ok : PhysicalDesign P X h R s p) : ∀ j, period s j ≤ 2*(max t 3)^2 := by
  obtain ⟨d,hd⟩ := feasible_nonzero_markov P X hh hr s p ok
  intro j
  have b := design_cutoff P X hh (Nat.succ_pos _) hd s p ok j
  apply b.trans
  have hmax : max (d.val+1) 3 ≤ max t 3 := max_le_max d.isLt le_rfl
  cases hd1 : (d.val+1 == 1) with
  | true =>
    have one : d.val+1=1 := beq_iff_eq.mp hd1
    simp [Bound,one]
    have h3 : 3 ≤ max t 3 := le_max_right _ _
    nlinarith [Nat.mul_le_mul h3 h3]
  | false =>
    have no : d.val+1≠1 := by intro e; simp [e] at hd1
    simpa only [Bound,if_neg no] using Nat.mul_le_mul_left 2 (Nat.pow_le_pow_left hmax 2)

theorem exhaustive_global_search {n t : ℕ} (P : Plant ℝ n) (X : System ℝ t 1 2)
    {h R : ℝ} (hh : 0<h) (hr : 1≤R) :
    (∃ k : Key (2*(max t 3)^2), Test P X h R (forget k)) ↔
      ∃ s p, UpdateOpt.Optimal clocks h (PhysicalDesign P X h R) s p :=
  globally_attained_iff h _ _ (fixed_test P X hh hr) (uniform_cutoff P X hh hr)

/-- Exact existence of a solution and identification of all globally minimizing
realizations, by bounded exclusions over integer schedule/phase keys. -/
theorem exhaustive_all_minimizers {n t : ℕ} (P : Plant ℝ n) (X : System ℝ t 1 2)
    {h R : ℝ} (hh : 0<h) (hr : 1≤R) (s : Pattern) (p : Physical) :
    UpdateOpt.Optimal clocks h (PhysicalDesign P X h R) s p ↔
    PhysicalDesign P X h R s p ∧ ∀ k : Key (2*(max t 3)^2),
      UpdateOpt.cheaper (clocks (forget k)) (clocks s) → ¬ Test P X h R (forget k) :=
  rate_optimal_iff hh _ _ (fixed_test P X hh hr) (uniform_cutoff P X hh hr) s p

end
end MPCPID.GlobalExhaustion
