import MPCPID.GainGraph

/-! Rigidity of all three clocks when a time-invariant measurement operator
with a persistent impulse response is prescribed. No bound on periods is used. -/
namespace MPCPID.RateFrontier
open Periodic Filter
open scoped Topology
noncomputable section
attribute [local instance] Classical.propDecidable

/-- Command at chronological sample k in the unit-measurement experiment at s. -/
def response (P I D : ℕ → Prop) (K b₀ b₁ α β : ℝ) (s k : ℕ) : ℝ :=
  let x := memory P I D K b₀ b₁ α β (impulse s) (k+1)
  x.p+x.i+x.d

/-- A missed integral sample cannot generate a nonzero limiting response
even for a filtered derivative whose stand-alone pole is outside the disk.
At arbitrarily late derivative events its remaining command scales by α. -/
theorem skipped_limit {P I D : ℕ → Prop} (K b₀ b₁ α β : ℝ) {s : ℕ}
    (hs : ¬ I s) (hp : ∀ k, ∃ j, k ≤ j ∧ P j)
    (hd : ∀ k, ∃ j, k ≤ j ∧ D j) {L : ℝ}
    (ht : Tendsto (response P I D K b₀ b₁ α β s) atTop (𝓝 L)) :
    L = α*L := by
  classical
  let x := memory P I D K b₀ b₁ α β (impulse s)
  have hz (k : ℕ) : (x k).i = 0 ∧ (x k).eI = 0 := by
    induction k with
    | zero => exact ⟨rfl,rfl⟩
    | succ k ih =>
      change (update _ _ _ _ _ _ _ _ _ (x k)).i = 0 ∧
        (update _ _ _ _ _ _ _ _ _ (x k)).eI = 0
      by_cases hi : I k
      · simp [update,hi,impulse,show k ≠ s from fun h => hs (h ▸ hi),ih]
      · simp [update,hi,ih]
  obtain ⟨a,ha,hpa⟩ := hp (s+1)
  obtain ⟨b,hb,hdb⟩ := hd (s+1)
  have hP (k : ℕ) (hk : a+1 ≤ k) : (x k).p = 0 := by
    induction k,hk using Nat.le_induction with
    | base => simp [x,memory,update,hpa,impulse,show a ≠ s by omega]
    | succ k h ih =>
      change (update _ _ _ _ _ _ _ _ _ (x k)).p = 0
      simp [update,impulse,show k ≠ s by omega,ih]
  have hD (k : ℕ) (hk : b+1 ≤ k) : (x k).eD = 0 := by
    induction k,hk using Nat.le_induction with
    | base => simp [x,memory,update,hdb,impulse,show b ≠ s by omega]
    | succ k h ih =>
      change (update _ _ _ _ _ _ _ _ _ (x k)).eD = 0
      simp [update,impulse,show k ≠ s by omega,ih]
  choose j hj hit using fun n : ℕ => hd (n+a+b+2)
  have hjlim : Tendsto j atTop atTop := by
    apply tendsto_atTop.2
    intro v
    filter_upwards [eventually_ge_atTop v] with n hn
    have := hj n
    omega
  have hprev : Tendsto (fun n => j n-1) atTop atTop := by
    apply tendsto_atTop.2
    intro v
    filter_upwards [eventually_ge_atTop v] with n hn
    have := hj n
    omega
  have he (n : ℕ) : response P I D K b₀ b₁ α β s (j n) =
      α * response P I D K b₀ b₁ α β s (j n-1) := by
    have h := hj n
    change (x (j n+1)).p+(x (j n+1)).i+(x (j n+1)).d =
      α*((x (j n-1+1)).p+(x (j n-1+1)).i+(x (j n-1+1)).d)
    rw [show j n-1+1=j n by omega,hP _ (by omega),hP _ (by omega),(hz _).1,(hz _).1]
    change 0+0+(update _ _ _ _ _ _ _ _ _ (x (j n))).d = _
    simp [update,hit n,impulse,show j n ≠ s by omega,hD (j n) (by omega)]
  exact tendsto_nhds_unique (ht.comp hjlim)
    ((tendsto_const_nhds.mul (ht.comp hprev)).congr (fun n => (he n).symm))

private theorem pre_rest (P I D : ℕ → Prop) (K b₀ b₁ α β : ℝ) (s k : ℕ) (h : k ≤ s) :
    memory P I D K b₀ b₁ α β (impulse s) k = rest := by
  classical
  induction k with
  | zero => rfl
  | succ k ih =>
    simp [memory,ih (by omega),update,rest,impulse,show k ≠ s by omega]

private theorem direct (P I D : ℕ → Prop) (K b₀ b₁ α β : ℝ) (s : ℕ) (hi : I s) :
    response P I D K b₀ b₁ α β s s =
      (if P s then -K else 0) - b₀ + (if D s then -β else 0) := by
  classical
  simp [response,memory,pre_rest _ _ _ _ _ _ _ _ _ _ le_rfl,update,rest,impulse,hi,sub_eq_add_neg]

private theorem lag_two (P I D : ℕ → Prop) (K b₀ b₁ α β : ℝ) (s : ℕ)
    (hi : ∀ n, I n)
    (hP : P s) (hp₁ : ¬P (s+1)) (hp₂ : P (s+2))
    (hD : ¬D s) (hd₁ : D (s+1)) (hd₂ : ¬D (s+2)) :
    response P I D K b₀ b₁ α β s (s+2) = -(b₀+b₁) := by
  classical
  simp [response,memory,pre_rest _ _ _ _ _ _ _ _ _ _ le_rfl,update,rest,impulse,hi,hP,hp₁,hp₂,hD,hd₁,hd₂]
  ring

private theorem lag_two' (P I D : ℕ → Prop) (K b₀ b₁ α β : ℝ) (s : ℕ)
    (hi : ∀ n, I n)
    (hP : ¬P s) (hp₁ : P (s+1)) (hp₂ : ¬P (s+2))
    (hD : D s) (hd₁ : ¬D (s+1)) (hd₂ : D (s+2)) :
    response P I D K b₀ b₁ α β s (s+2) = -(b₀+b₁)+(1-α)*β := by
  classical
  simp [response,memory,pre_rest _ _ _ _ _ _ _ _ _ _ le_rfl,update,rest,impulse,hi,hP,hp₁,hp₂,hD,hd₁,hd₂]
  ring

private theorem no_adjacent {m φ k : ℕ} (hm : 1 < m) (hh : φ < m)
    (h : atPhase m φ k) : ¬atPhase m φ (k+1) := by
  change (k+1)%m ≠ φ
  change k%m=φ at h
  rw [Nat.add_mod, h, Nat.mod_eq_of_lt hm]
  by_cases hend : φ+1=m
  · rw [hend,Nat.mod_self]
    omega
  · rw [Nat.mod_eq_of_lt (by omega : φ+1<m)]
    omega

/-- A persistent measurement impulse and two phase-independent Markov
coefficients force every branch to run at the base rate. -/
theorem clock_rigidity {mP mI mD φP φI φD : ℕ}
    (hp : φP < mP) (hi : φI < mI) (hd : φD < mD)
    {K b₀ b₁ α β L : ℝ} (hK : 0 < K) (hβ : 0 < β) (hα : α ≠ 1) (hL : L ≠ 0)
    (tail : ∀ s, Tendsto (response (atPhase mP φP) (atPhase mI φI)
      (atPhase mD φD) K b₀ b₁ α β s) atTop (𝓝 L))
    (constant : ∀ s t, ∀ j ∈ ({0,2} : Finset ℕ),
      response (atPhase mP φP) (atPhase mI φI) (atPhase mD φD) K b₀ b₁ α β s (s+j) =
      response (atPhase mP φP) (atPhase mI φI) (atPhase mD φD) K b₀ b₁ α β t (t+j)) :
    mP = 1 ∧ mI = 1 ∧ mD = 1 := by
  classical
  let P := atPhase mP φP
  let I := atPhase mI φI
  let D := atPhase mD φD
  have mi : mI = 1 := by
    apply Classical.byContradiction
    intro no
    obtain ⟨s,hs⟩ := integralHasSkip (φ := φI) (show 1 < mI by omega)
    have e := skipped_limit K b₀ b₁ α β hs (phaseCofinal hp) (phaseCofinal hd) (tail s)
    exact hα ((mul_eq_zero.mp (show (α-1)*L=0 by linarith)).resolve_right hL |> sub_eq_zero.mp)
  have allI (n : ℕ) : I n := by
    have he : φI=0 := by omega
    simp [I,atPhase,mi,he,Nat.mod_one]
  have same (s t : ℕ) : (if P s then -K else 0) - b₀ + (if D s then -β else 0) =
                          (if P t then -K else 0) - b₀ + (if D t then -β else 0) := by
    have e := constant s t 0 (by simp)
    change response P I D K b₀ b₁ α β s s = response P I D K b₀ b₁ α β t t at e
    rw [direct P I D K b₀ b₁ α β s (allI s), direct P I D K b₀ b₁ α β t (allI t)] at e
    exact e
  have period_one {m φ : ℕ} (all : ∀ t, atPhase m φ t) (h : φ < m) : m=1 := by
    apply Classical.byContradiction
    intro no
    obtain ⟨t,miss⟩ := integralHasSkip (φ := φ) (show 1 < m by omega)
    exact miss (all t)
  by_cases both : ∃ t, P t ∧ D t
  · obtain ⟨t,pt,dt⟩ := both
    have all (s : ℕ) : P s ∧ D s := by
      have e := same s t
      by_cases ps : P s <;> by_cases ds : D s
      · exact ⟨ps,ds⟩
      all_goals
        simp [ps,ds,pt,dt] at e
        exfalso
        linarith
    exact ⟨period_one (fun s => (all s).1) hp,mi,period_one (fun s => (all s).2) hd⟩
  · obtain ⟨a,_,pa⟩ := phaseCofinal hp 0
    obtain ⟨b,_,db⟩ := phaseCofinal hd 0
    change P a at pa
    change D b at db
    have apart (s : ℕ) (ps : P s) : ¬ D s := fun ds => both ⟨s,ps,ds⟩
    have complement (s : ℕ) (ns : ¬ P s) : D s := by
      apply Classical.byContradiction
      intro nd
      have e := same s a
      rw [if_neg ns,if_neg nd,if_pos pa,if_neg (apart a pa)] at e
      linarith
    have hmP : 1 < mP := by
      apply Classical.byContradiction
      intro e
      have h1 : mP=1 := by omega
      have h0 : φP=0 := by omega
      exact both ⟨b,by simp [P,atPhase,h1,h0,Nat.mod_one],db⟩
    have hmD : 1 < mD := by
      apply Classical.byContradiction
      intro e
      have h1 : mD=1 := by omega
      have h0 : φD=0 := by omega
      exact both ⟨a,pa,by simp [D,atPhase,h1,h0,Nat.mod_one]⟩
    have p₁ : ¬ P (a+1) := no_adjacent hmP hp pa
    have d₁ := complement _ p₁
    have d₂ : ¬ D (a+2) := no_adjacent hmD hd d₁
    have p₂ : P (a+2) := Classical.byContradiction (fun e => d₂ (complement _ e))
    have p₃ : ¬P (a+3) := no_adjacent hmP hp p₂
    have h₁ := lag_two P I D K b₀ b₁ α β a allI pa p₁ p₂ (apart a pa) d₁ d₂
    have h₂ := lag_two' P I D K b₀ b₁ α β (a+1) allI p₁ p₂ p₃ d₁ d₂ (complement _ p₃)
    have e := constant a (a+1) 2 (by simp)
    rw [h₁,h₂] at e
    exact False.elim ((mul_ne_zero (sub_ne_zero.mpr hα.symm) hβ.ne') (by linarith))

/-- For actual physical parameters the derivative coefficient is positive
and the pole differs from one for every positive derivative period. -/
theorem physical_clock_rigidity {mP mI mD φP φI φD : ℕ}
    (hp : φP < mP) (hi : φI < mI) (hd : φD < mD)
    (p : GainGraph.Physical) (adm : GainGraph.Admissible p) {h L : ℝ}
    (hh : 0 < h) (hL : L ≠ 0) :
    let g := GainGraph.rational ((mI:ℝ)*h) ((mD:ℝ)*h) p
    let R := response (atPhase mP φP) (atPhase mI φI) (atPhase mD φD) g.K g.i0 g.i1 g.α g.β
    (∀ s, Tendsto (R s) atTop (𝓝 L)) →
    (∀ s t, ∀ j ∈ ({0,2} : Finset ℕ), R s (s+j) = R t (t+j)) →
    mP=1 ∧ mI=1 ∧ mD=1 := by
  let TD : ℝ := (mD:ℝ)*h
  have hTD : 0 < TD := mul_pos (by exact_mod_cast (show 0 < mD by omega)) hh
  rcases adm with ⟨hk,_,htd,htf,_,hγ,_,_⟩
  have den : 0 < p.Tf + p.γD * TD := add_pos_of_pos_of_nonneg htf (mul_nonneg hγ.1 hTD.le)
  have hpos := div_pos hTD den
  dsimp only
  intro tail direct
  exact clock_rigidity hp hi hd hk (div_pos (mul_pos hk htd) den)
    (show 1 - TD/(p.Tf+p.γD*TD) ≠ 1 by linarith) hL tail direct


/-- A common-rate filtered PID has identical zero- and two-sample Markov
coefficients at every possible impulse phase. -/
private theorem common_two_taps (K b₀ b₁ α β : ℝ) (s t j : ℕ) (hj : j ∈ ({0,2} : Finset ℕ)) :
    response (fun _ => True) (fun _ => True) (fun _ => True) K b₀ b₁ α β s (s+j) =
    response (fun _ => True) (fun _ => True) (fun _ => True) K b₀ b₁ α β t (t+j) := by
  simp only [Finset.mem_insert,Finset.mem_singleton] at hj
  rcases hj with rfl|rfl <;>
    simp [response,memory,pre_rest _ _ _ _ _ _ _ _ _ _ le_rfl,update,rest,impulse]

/-- If the physical PID reproduces the zero-reference measurement impulses
of a common-rate PID with a stable filtered pole and nonzero integral residue,
its full schedule is forced. Any additional constraint on the plant or on
loop gain can only restrict the remaining common-rate parameter search. -/
theorem common_target_forces_unit_clocks {mP mI mD φP φI φD : ℕ}
    (hp : φP < mP) (hi : φI < mI) (hd : φD < mD)
    (p : GainGraph.Physical) (adm : GainGraph.Admissible p) {h : ℝ} (hh : 0<h)
    (K' i₀ i₁ α' β' : ℝ) (stable : |α'|<1) (integral : i₀+i₁ ≠ 0) :
    let g := GainGraph.rational ((mI:ℝ)*h) ((mD:ℝ)*h) p
    (∀ s k, response (atPhase mP φP) (atPhase mI φI) (atPhase mD φD)
      g.K g.i0 g.i1 g.α g.β s k =
      response (fun _ => True) (fun _ => True) (fun _ => True) K' i₀ i₁ α' β' s k) →
    mP=1 ∧ mI=1 ∧ mD=1 := by
  dsimp only
  intro heq
  apply physical_clock_rigidity hp hi hd p adm hh (neg_ne_zero.mpr integral)
  · intro s
    exact (commonImpulseLimit K' i₀ i₁ α' β' stable s).congr (fun n => (heq s n).symm)
  · intro s t j hj
    rw [heq,heq]
    exact common_two_taps K' i₀ i₁ α' β' s t j hj

end
end MPCPID.RateFrontier
