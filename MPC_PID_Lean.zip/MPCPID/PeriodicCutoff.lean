import MPCPID.ClockBound
import Mathlib.Data.Fintype.Pigeonhole

/-! Uniform clock bounds for target-periodic observations. -/
namespace MPCPID.PeriodicCutoff
open ClockBound

def GridRigid (H d : ℕ) (m φ : Triple) : Prop :=
  ∀ k l : ℕ, k % H = l % H →
    (∀ i, m i ≤ d → (Fires m φ i k ↔ Fires m φ i l)) →
    (∀ i, Fires m φ i k → Fires m φ i l) →
    ∀ i, Fires m φ i l → Fires m φ i k

private theorem gap {m φ k d : ℕ} (a : k % m = φ) (b : (k+d) % m = φ) : m ∣ d := by
  have he : k ≡ k+d [MOD m] := a.trans b.symm
  simpa using (Nat.modEq_iff_dvd' (Nat.le_add_right k d)).mp he

private theorem repeats {m k d : ℕ} (hd : m ∣ d) : (k+d) % m = k % m := by
  simp [Nat.add_mod k d m,Nat.mod_eq_zero_of_dvd hd]

private theorem ordered {H d : ℕ} (hH : 0<H) (m φ : Triple) (bound : ∀ i, φ i < m i)
    (rigid : GridRigid H d m φ) (h01 : m 0 ≤ m 1) (h12 : m 1 ≤ m 2) :
    m 0 ≤ max d (3*H) ∧ m 1 ≤ max d (2*(H*m 0)) ∧
      (m 2 ≤ d ∨ m 2 ∣ H*m 0*m 1) := by
  have pos (i : Fin 3) : 0 < m i := Nat.zero_lt_of_lt (bound i)
  have least (i : Fin 3) : m 0 ≤ m i := by
    fin_cases i
    · exact le_rfl
    · exact h01
    · exact h01.trans h12
  have first : m 0 ≤ max d (3*H) := by
    apply Nat.le_of_not_gt
    intro big
    have h0 : d < m 0 := (le_max_left _ _).trans_lt big
    let t (j : Fin 4) := φ 0 + j.val * H
    have cov (j : Fin 4) : ∃ i, Fires m φ i (t j) := by
      by_contra! hn
      have eq := repeats (k := φ 0) (dvd_mul_left H j.val)
      have sub (i : Fin 3) : Fires m φ i (t j) → Fires m φ i (φ 0) := fun hi => (hn i hi).elim
      have hs (i : Fin 3) (hi : m i ≤ d) : Fires m φ i (t j) ↔ Fires m φ i (φ 0) :=
        False.elim ((not_le_of_gt (h0.trans_le (least i))) hi)
      exact hn 0 (rigid (t j) (φ 0) eq hs sub 0 (Nat.mod_eq_of_lt (bound 0)))
    choose clock fired using cov
    obtain ⟨a,b,hab,same⟩ := Fintype.exists_ne_map_eq_of_card_lt clock (by decide)
    have contrad (u v : Fin 4) (hlt : u < v) (eq : clock u=clock v) : False := by
      have e := fired v
      rw [← eq] at e
      have sub : t u < t v := by
        exact Nat.add_lt_add_left (Nat.mul_lt_mul_of_pos_right hlt hH) _
      have D : m (clock u) ∣ t v - t u := (Nat.modEq_iff_dvd' sub.le).mp ((fired u).trans e.symm)
      have small : t v - t u ≤ 3*H := by
        have hv : v.val≤3 := by omega
        have upper := Nat.mul_le_mul_right H hv
        dsimp [t]
        omega
      have h := (least _).trans ((Nat.le_of_dvd (Nat.sub_pos_of_lt sub) D).trans small)
      exact (not_le_of_gt ((le_max_right _ _).trans_lt big)) h
    exact (lt_or_gt_of_ne hab).elim (fun h => contrad a b h same) (fun h => contrad b a h same.symm)
  have second : m 1 ≤ max d (2*(H*m 0)) := by
    apply Nat.le_of_not_gt
    intro big
    have h1 : d < m 1 := (le_max_left _ _).trans_lt big
    have h2 : 2*(H*m 0)< m 1 := (le_max_right _ _).trans_lt big
    let D := H*m 0
    have hD : 0<D := Nat.mul_pos hH (pos 0)
    have pair (q : ℕ) :
        Fires m φ 1 (φ 1+q*D) ∨ Fires m φ 2 (φ 1+q*D) := by
      by_contra hn
      have n1 : ¬Fires m φ 1 (φ 1+q*D) := fun hh => hn (Or.inl hh)
      have n2 : ¬Fires m φ 2 (φ 1+q*D) := fun hh => hn (Or.inr hh)
      have r0 := repeats (k := φ 1) (dvd_mul_of_dvd_right (dvd_mul_left (m 0) H) q)
      have rH := repeats (k := φ 1) (dvd_mul_of_dvd_right (dvd_mul_right H (m 0)) q)
      have sub (i : Fin 3) : Fires m φ i (φ 1+q*D) → Fires m φ i (φ 1) := by
        fin_cases i
        · exact fun h => r0.symm.trans h
        · exact fun h => (n1 h).elim
        · exact fun h => (n2 h).elim
      have hs (i : Fin 3) (hi : m i ≤ d) : Fires m φ i (φ 1+q*D) ↔ Fires m φ i (φ 1) := by
        fin_cases i
        · exact ⟨fun h => r0.symm.trans h,fun h => r0.trans h⟩
        · exact ((not_le_of_gt h1) hi).elim
        · exact ((not_le_of_gt (h1.trans_le h12)) hi).elim
      exact n1 (rigid _ _ rH hs sub 1 (Nat.mod_eq_of_lt (bound 1)))
    have orig : φ 1 % m 1 = φ 1 := Nat.mod_eq_of_lt (bound 1)
    have miss (e : ℕ) (he : 0 < e) (hb : e ≤ 2*D) : ¬ Fires m φ 1 (φ 1+e) := by
      intro hit
      exact (not_le_of_gt h2) ((Nat.le_of_dvd he (gap orig hit)).trans hb)
    have p : Fires m φ 1 (φ 1+D) ∨ Fires m φ 2 (φ 1+D) := by simpa using pair 1
    have p1 := p.resolve_left (miss _ hD (by omega))
    have p2 := (pair 2).resolve_left (miss _ (by omega) le_rfl)
    have next : (φ 1 + D + D) % m 2 = φ 2 := by
      simpa only [Fires,two_mul,Nat.add_assoc] using p2
    have hl := Nat.le_of_dvd hD (gap p1 next)
    change 2*D < m 1 at h2
    omega
  refine ⟨first,second,?_⟩
  by_cases small : m 2 ≤ d
  · exact Or.inl small
  right
  let e := H*m 0*m 1
  have r0 := repeats (k := φ 2) (dvd_mul_of_dvd_left (dvd_mul_left (m 0) H) (m 1))
  have r1 := repeats (k := φ 2) (dvd_mul_left (m 1) (H*m 0))
  have rH := repeats (k := φ 2) (dvd_mul_of_dvd_left (dvd_mul_right H (m 0)) (m 1))
  have at2 : Fires m φ 2 (φ 2) := Nat.mod_eq_of_lt (bound 2)
  have sub (i : Fin 3) : Fires m φ i (φ 2+e) → Fires m φ i (φ 2) := by
    fin_cases i
    · exact fun hh => r0.symm.trans hh
    · exact fun hh => r1.symm.trans hh
    · exact fun _ => at2
  have hs (i : Fin 3) (hi : m i ≤ d) : Fires m φ i (φ 2+e) ↔ Fires m φ i (φ 2) := by
    fin_cases i
    · exact ⟨fun hh => r0.symm.trans hh,fun hh => r0.trans hh⟩
    · exact ⟨fun hh => r1.symm.trans hh,fun hh => r1.trans hh⟩
    · exact (small hi).elim
  exact gap at2 (rigid _ _ rH hs sub 2 at2)

theorem grid_period_bound {H d : ℕ} (hH : 0<H) (m φ : Triple) (B : ∀ i, φ i<m i)
    (rigid : GridRigid H d m φ) : ∀ i, m i ≤ 2*H^2*(max d (3*H))^2 := by
  let e := Tuple.sort m
  let M := m ∘ e
  let G := max d (3*H)
  have hr : GridRigid H d M (φ ∘ e) := by
    intro k l grid agree sub i hi
    apply rigid k l grid _ _ (e i) hi
    · intro j hj
      simpa [M,Fires] using agree (e.symm j) (by simpa [M] using hj)
    · intro j
      simpa [M,Fires] using sub (e.symm j)
  have hm := Tuple.monotone_sort m
  obtain ⟨a,b,c⟩ := ordered hH M (φ ∘ e) (fun i => B (e i)) hr
    (hm (by decide : (0 : Fin 3)≤1)) (hm (by decide : (1 : Fin 3)≤2))
  change M 0 ≤ G at a
  have hd : d ≤ G := le_max_left _ _
  have hg : 0 < G := (by dsimp [G]; omega)
  have hG : G ≤ H*G := by simpa using Nat.mul_le_mul_right G hH
  have mid : M 1 ≤ 2*(H*G) := by
    apply b.trans (max_le _ _)
    · omega
    · exact Nat.mul_le_mul_left 2 (Nat.mul_le_mul_left H a)
  have hp := Nat.mul_le_mul (Nat.mul_le_mul_left H a) mid
  have hpos (i : Fin 3) : 0<M i := Nat.zero_lt_of_lt (B (e i))
  have last : M 2 ≤ 2*H^2*G^2 := by
    rcases c with c|c
    · have ge2 : G ≤ G^2 := by nlinarith
      have hh2 : 1 ≤ 2*H^2 := by nlinarith
      exact (c.trans hd).trans (ge2.trans (by simpa using Nat.mul_le_mul_right (G^2) hh2))
    · have le := Nat.le_of_dvd (Nat.mul_pos (Nat.mul_pos hH (hpos 0)) (hpos 1)) c
      calc
        _ ≤ _ := le
        _ ≤ _ := hp
        _ = _ := by ring
  intro i
  have ht := hm (Fin.le_last (e.symm i))
  change m (e (e.symm i)) ≤ M 2 at ht
  rw [Equiv.apply_symm_apply] at ht
  exact ht.trans last

end MPCPID.PeriodicCutoff
