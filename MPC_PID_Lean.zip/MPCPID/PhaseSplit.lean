import MPCPID.PhysicalLift
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.LinearCombination

/-! Classification of the two branch corrections at a clock phase. The
columns are the chronological responses of the raw command after a unit
actuator defect. The branch mask constrains which memories may change. -/
namespace MPCPID.PhaseSplit
open PhysicalLift
noncomputable section

/-- Internally store a unit actuator discrepancy using only updating I,D branches. -/
def Supported (s : Flags) (θ : ℝ) : Prop :=
  (s.i = false → θ = 0) ∧ (s.d = false → 1-θ = 0)

/-- The full affine column for a unit discrepancy vanishes. The coordinates can
enumerate any finite stack of phase and period observations. -/
def Fits {ι : Type*} (s : Flags) (base direction : ι → ℝ) (θ : ℝ) : Prop :=
  Supported s θ ∧ ∀ j, base j + θ*direction j = 0

theorem support_cases (s : Flags) (θ : ℝ) :
    Supported s θ ↔ match s.i, s.d with
      | false, false => False
      | false, true => θ = 0
      | true, false => θ = 1
      | true, true => True := by
  obtain ⟨p,i,d⟩ := s
  cases i <;> cases d <;> simp [Supported, sub_eq_zero] <;> aesop

/-- If some pulse-response coefficient distinguishes the two resets, that
coordinate determines the unique possible split, and every other row must
confirm it. A coordinate test avoids forming a possibly singular Gram matrix. -/
theorem pivot_characterization {ι : Type*} (s : Flags) (b u : ι → ℝ)
    (j : ι) (hj : u j ≠ 0) (θ : ℝ) :
    Fits s b u θ ↔ θ = -b j/u j ∧ Supported s (-b j/u j) ∧
      ∀ q, b q * u j = b j * u q := by
  constructor
  · rintro ⟨hmask,hrows⟩
    have hx : θ = -b j/u j := (eq_div_iff hj).2 (by linarith only [hrows j])
    refine ⟨hx,hx ▸ hmask,fun q => ?_⟩
    linear_combination u j * hrows q - u q * hrows j
  · rintro ⟨rfl,hmask,hrows⟩
    refine ⟨hmask,fun q => ?_⟩
    field_simp [hj]
    linear_combination hrows q

theorem zero_direction {ι : Type*} (s : Flags) (b u : ι → ℝ)
    (hu : ∀ j, u j = 0) (θ : ℝ) :
    Fits s b u θ ↔ Supported s θ ∧ ∀ j, b j = 0 := by
  simp [Fits,hu]

/-- If the actuator clamps externally, the two per-phase memory increments
may instead be chosen without requiring their sum to equal the defect. -/
def FreeFits {ι : Type*} (s : Flags) (b u w : ι → ℝ) (a d : ℝ) : Prop :=
  (s.i = false → a = 0) ∧ (s.d = false → d = 0) ∧
  ∀ q, b q + a*u q + d*w q = 0

def enabled {ι : Type*} (flag : Bool) (v : ι → ℝ) : ι → ℝ :=
  if flag then v else 0

/-- A memory pair exists exactly when the negative uncorrected pulse column
lies in the span of the columns of the updating branches. -/
theorem free_iff_span {ι : Type*} (s : Flags) (b u w : ι → ℝ) :
    (∃ a d, FreeFits s b u w a d) ↔
    -b ∈ Submodule.span ℝ {enabled s.i u, enabled s.d w} := by
  rw [Submodule.mem_span_pair]
  constructor
  · rintro ⟨a,d,hi,hd,heq⟩
    refine ⟨a,d,?_⟩
    funext q
    have row := heq q
    cases h₁ : s.i <;> cases h₂ : s.d <;>
      simp [enabled,h₁,h₂,Pi.add_apply,Pi.neg_apply,Pi.smul_apply]
    · rw [hi h₁,hd h₂] at row
      linarith
    · rw [hi h₁] at row
      linarith
    · rw [hd h₂] at row
      linarith
    · linarith
  · rintro ⟨a,d,heq⟩
    refine ⟨if s.i then a else 0, if s.d then d else 0,?_,?_,?_⟩
    · intro hi
      simp [hi]
    · intro hd
      simp [hd]
    · intro q
      have h := congrFun heq q
      cases h₁ : s.i <;> cases h₂ : s.d <;>
        simp [enabled,h₁,h₂,Pi.add_apply,Pi.neg_apply,Pi.smul_apply] at h ⊢ <;> linarith

/-- Adding current stored-output consistency leaves precisely the one-dimensional
split solved by `pivot_characterization` and `zero_direction`. -/
theorem stored_iff {ι : Type*} (s : Flags) (b u w : ι → ℝ) (a d : ℝ) :
    FreeFits s b u w a d ∧ a+d=1 ↔
      d=1-a ∧ Fits s (fun q => b q+w q) (fun q => u q-w q) a := by
  constructor
  · rintro ⟨⟨hi,hd,rows⟩,hs⟩
    have h : d=1-a := by linarith
    refine ⟨h,⟨hi,fun hd' => h ▸ hd hd'⟩,fun q => ?_⟩
    rw [h] at rows
    linear_combination rows q
  · rintro ⟨rfl,⟨hi,hd⟩,rows⟩
    exact ⟨⟨hi,hd,fun q => by linear_combination rows q⟩,by ring⟩

/-- The physical state increment left by storing a unit discrepancy. The
two measured-error samples and the proportional branch remain unchanged. -/
def reset (θ : ℝ) : Fin 5 → ℝ := ![0,θ,1-θ,0,0]

/-- Decay of a derivative-memory perturbation in the next phase. -/
def decay (s : Flags) (α : ℝ) : ℝ := if s.d then α else 1

theorem next_free_branches (g : GainGraph.Coeff ℝ) (s : Flags) (θ : ℝ) :
    (F g s).mulVec (reset θ) = ![0,θ,(decay s g.α)*(1-θ),0,0] := by
  obtain ⟨p,i,d⟩ := s
  funext k
  fin_cases k <;> cases p <;> cases i <;> cases d <;>
    simp [F,Periodic.phaseF,reset,decay,bit,Matrix.mulVec, dotProduct,Fin.sum_univ_succ]

/-- Free feedthrough from a measured-output change to the present raw command. -/
def measurementGain (g : GainGraph.Coeff ℝ) (s : Flags) : ℝ :=
  -bit s.p * g.K - bit s.i * g.i0 - bit s.d * g.β

/-- At the first sample after the defect both measured and branch-memory
increments contribute to the proposal. This calculation uses the actual five
states and preserves the sample ordering (plant output before the update). -/
theorem next_physical_command (g : GainGraph.Coeff ℝ) (s : Flags) (β₀ θ : ℝ) :
    (readBranches ℝ).mulVec
      ((F g s).mulVec (reset θ) + (fun k => Gy g s k 0 * β₀)) 0 =
      θ+(1-θ)*decay s g.α + measurementGain g s * β₀ := by
  rw [next_free_branches]
  simp [readBranches, Gy, column, Periodic.phaseGy, measurementGain, Matrix.mulVec,
    dotProduct, Fin.sum_univ_succ]
  ring

/-- The target reads the perturbed plant output β₀ and the applied previous
command 1. At a following derivative update there is a single possible split.
At a derivative hold the measured target response must pass a scalar test. -/
theorem first_sample_criterion (g : GainGraph.Coeff ℝ) (s : Flags) (hα : g.α ≠ 1)
    (β₀ f t θ : ℝ) :
    (readBranches ℝ).mulVec
      ((F g s).mulVec (reset θ) + (fun k => Gy g s k 0 * β₀)) 0 = t - f*β₀ ↔
    if s.d then θ = ((t - β₀*(f+measurementGain g s))-g.α)/(1-g.α)
    else t-β₀*(f+measurementGain g s) = 1 := by
  rw [next_physical_command]
  cases hd : s.d
  · simp only [Bool.false_eq_true,↓reduceIte,decay,hd]
    constructor <;> intro h <;> linarith only [h]
  · simp only [↓reduceIte,decay,hd]
    rw [eq_div_iff (sub_ne_zero.mpr (Ne.symm hα))]
    constructor <;> intro h <;> linarith only [h]

/-- On the matched common-rate branch the first-sample formula specializes
to the correction of Theorem 8.6. -/
theorem recovers_common_rate {α β₀ β₁ f t ζ J : ℝ} (hJ : J=-(f+ζ))
    (ht : t+ζ*(β₀+β₁)=1) (hα : α= -ζ*β₁) :
    (t-β₀*(f+J)-α)/(1-α) = 1/(1-α) := by
  congr 1
  rw [hJ,hα]
  linear_combination ht

end
end MPCPID.PhaseSplit
