import MPCPID.NominalProbe
import Mathlib.Data.Nat.ModEq

/-! A compact nominal experiment forces the integral branch to sample every tick. -/
namespace MPCPID.NominalProbe
open Periodic
noncomputable section

private theorem shifted_cofinal {m φ : ℕ} (h : φ<m) (s k : ℕ) :
    ∃ j, k ≤ j ∧ atPhase m φ (s+j) := by
  obtain ⟨j,hj,he⟩ := phaseCofinal h (s+k)
  exact ⟨j-s,by omega,by rwa [show s+(j-s)=j by omega]⟩

private theorem erase_at_event (fire : ℕ → Prop) [DecidablePred fire] (z : ℕ → ℝ)
    (h : ∀ k, 3 ≤ k → z (k+1) = if fire k then 0 else z k)
    (j : ℕ) (hj : 3 ≤ j) (hit : fire j) : ∀ k ≥ j+1, z k = 0 := by
  intro k hk
  induction k, hk using Nat.le_induction with
  | base => simp [h j hj,hit]
  | succ k hk ih => simp [h k (by omega),ih]

private theorem no_second_hit {m s : ℕ} (hs : s<m) (hm : 1<m) :
    ¬atPhase m s (s+1) := by
  intro he
  have hx : s+1 ≡ s+0 [MOD m] := by
    simpa [Nat.ModEq,atPhase,Nat.mod_eq_of_lt hs] using he
  have : 1 ≡ 0 [MOD m] := Nat.ModEq.add_left_cancel' s hx
  simp [Nat.ModEq,Nat.mod_eq_of_lt hm] at this

/-- At the integral firing phase, the nominal compact error has taps
1, θ−1, −θ. If the period exceeds one, the second tap is missed. The
post-event bias i+i₁eI captures the remaining signed sampled area, which
cannot vanish. The proportional and derivative outputs cannot sustain
the opposite constant once all external signals vanish. -/
theorem integral_clock_is_one {mP mI mD φP φI φD : ℕ}
    (hp : φP<mP) (hi : φI<mI) (hd : φD<mD)
    (K i0 i1 α β b c p B θ η a : ℝ) (hα : α ≠ 1)
    (hg : 0 < i0+i1) (hθ : θ<1)
    (hm : Matches (atPhase mP φP) (atPhase mI φI) (atPhase mD φD)
      K i0 i1 α β b c p B θ η a) : mI=1 := by
  classical
  by_contra hI
  have hmI : 1<mI := by omega
  let P := atPhase mP φP
  let I := atPhase mI φI
  let D := atPhase mD φD
  let s := φI
  let x := regs P I D K i0 i1 α β b c p B θ s
  have rec (k : ℕ) :
      x (k+1) = advance (P (s+k)) (I (s+k)) (D (s+k)) K i0 i1 α β
        (b*refProbe p k-outProbe B θ k) (refProbe p k-outProbe B θ k)
        (c*refProbe p k-outProbe B θ k) (x k) := rfl
  have hfirst : I (s+0) := by simp [I,s,atPhase,Nat.mod_eq_of_lt hi]
  have hsecond : ¬I (s+1) := no_second_hit hi hmI
  let area (k : ℕ) := (x k).i + i1*(x k).eI
  have inc (k : ℕ) : area (k+1) = area k +
      (if I (s+k) then (i0+i1)*(refProbe p k-outProbe B θ k) else 0) := by
    dsimp only [area]
    rw [rec k]
    by_cases he : I (s+k)
    · simp [advance,he]
      ring
    · simp [advance,he]
  have hzero : area 0 = 0 := by simp [area,x,regs,rest]
  have hpos3 : 0 < area 3 := by
    rw [inc 2,inc 1,inc 0,hzero,if_pos hfirst,if_neg hsecond]
    by_cases he : I (s+2)
    · simp [he,refProbe,outProbe,pulse]
      nlinarith [mul_pos hg (sub_pos.mpr hθ)]
    · simpa [he,refProbe,outProbe,pulse] using hg
  have no_input (k : ℕ) (hk : 3≤k) : refProbe p k=0 ∧ outProbe B θ k=0 := by
    simp [refProbe,outProbe,pulse,show 0≠k by omega,show 1≠k by omega,show 2≠k by omega]
  have hpos (k : ℕ) (hk : 3≤k) : 0<area k := by
    induction k, hk using Nat.le_induction with
    | base => exact hpos3
    | succ k hk ih => simpa [inc k,(no_input k hk).1,(no_input k hk).2] using ih
  have tail (k : ℕ) (hk : 3≤k) :
      x (k+1) = advance (P (s+k)) (I (s+k)) (D (s+k)) K i0 i1 α β 0 0 0 (x k) := by
    simp [rec k,(no_input k hk).1,(no_input k hk).2]
  obtain ⟨jP,hjP,hPe⟩ := shifted_cofinal hp s 3
  obtain ⟨jI,hjI,hIe⟩ := shifted_cofinal hi s 3
  obtain ⟨jD,hjD,hDe⟩ := shifted_cofinal hd s 3
  have clearP := erase_at_event (fun k => P (s+k)) (fun k => (x k).p)
    (fun k hk => by simp [tail k hk,advance]) jP hjP hPe
  have clearI := erase_at_event (fun k => I (s+k)) (fun k => (x k).eI)
    (fun k hk => by simp [tail k hk,advance]) jI hjI hIe
  have clearD := erase_at_event (fun k => D (s+k)) (fun k => (x k).eD)
    (fun k hk => by simp [tail k hk,advance]) jD hjD hDe
  obtain ⟨j,hj,hitD⟩ := shifted_cofinal hd s (jP+jI+jD+1)
  have p0 : (x j).p = 0 := clearP j (by omega)
  have p1 : (x (j+1)).p = 0 := clearP (j+1) (by omega)
  have eI0 : (x j).eI = 0 := clearI j (by omega)
  have eD0 : (x j).eD = 0 := clearD j (by omega)
  have sameI : (x (j+1)).i = (x j).i := by
    by_cases h : I (s+j) <;> simp [tail j (by omega),advance,h,eI0]
  have stepD : (x (j+1)).d = α * (x j).d := by
    have hit : D (s+j) := hitD
    simp [tail j (by omega),advance,hit,eD0]
  have sum (k : ℕ) (hk : 3≤k) : (x k).p+(x k).i+(x k).d=0 := by
    obtain ⟨k,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (show k≠0 by omega)
    simpa [x,P,I,D,s,cmdProbe,pulse,show 0≠k by omega,show 1≠k by omega] using hm s k
  have now := sum j (by omega)
  have hnext := sum (j+1) (by omega)
  rw [p0,zero_add] at now
  rw [p1,zero_add,sameI,stepD] at hnext
  have kill : (α-1)*(x j).d=0 := by linear_combination hnext - now
  have d0 := (mul_eq_zero.mp kill).resolve_left (sub_ne_zero.mpr hα)
  have pos := hpos j (by omega)
  simp [area,eI0] at pos
  linarith

end
end MPCPID.NominalProbe
