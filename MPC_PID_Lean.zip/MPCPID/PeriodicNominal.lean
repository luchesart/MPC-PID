import MPCPID.PeriodicCutoff
import MPCPID.NominalBound

/-! The phase-dependent time-domain form of the cutoff. Y and U are the
prescribed strictly proper output and commanded-input impulse responses,
indexed by the start phase and the lag of the experiment. -/
namespace MPCPID.PeriodicNominal
open ClockBound PeriodicCutoff NominalColumns NominalBound PhysicalSchedule GainGraph
open scoped BigOperators
noncomputable section

/-- Starting phase of an impulse observed at the given phase and lag. -/
def origin (H phase lag : ℕ) := (phase + lag*(H-1))%H

private theorem add_period (phase lag M : ℕ) (hm : 0<M) :
    phase+lag*(M-1)+lag = phase+lag*M := by
  obtain ⟨u,rfl⟩ := Nat.exists_eq_succ_of_ne_zero hm.ne'
  simp [Nat.mul_succ,Nat.add_assoc]

private theorem same_mod {m k d : ℕ} (hd : m∣d) : (k+d)%m = k%m := by
  simp [Nat.add_mod k d m,Nat.mod_eq_zero_of_dvd hd]

theorem phase_columns {H L : ℕ} (hH : 0<H) (s : Clocks L) (g : Coeff ℝ)
    (Y U : ℕ → ℕ → ℝ)
    (matchImpulse : ∀ start k, output s g (Y (start%H)) start (k+1) = U (start%H) k)
    (phase lag : ℕ) :
    (∑ j ∈ support (periods s) (phases s) phase,
       col s g (Y (origin H phase lag)) lag j) = diff (U (origin H phase lag)) lag := by
  let start := phase + lag*(L*H-1)
  have finish : start+lag = phase+lag*(L*H) := add_period _ _ _ (Nat.mul_pos s.frame_pos hH)
  have orig : start%H=origin H phase lag := by
    apply Nat.ModEq.add_right_cancel' lag
    change (start+lag)%H = (phase+lag*(H-1)+lag)%H
    rw [finish,add_period _ _ _ hH,same_mod (dvd_mul_of_dvd_right (dvd_mul_left H L) lag),
      same_mod (dvd_mul_left H lag)]
  have absolute {m : ℕ} (dvd : m∣L) : (start+lag)%m = phase%m := by
    rw [finish,same_mod (dvd_mul_of_dvd_right (dvd_mul_of_dvd_left dvd H) lag)]
  let y := Y (origin H phase lag)
  have hu (k : ℕ) : output s g y start (k+1) = U (origin H phase lag) k := by
    simpa only [orig,y] using matchImpulse start k
  have curr : diff (U (origin H phase lag)) lag =
      output s g y start (lag+1) - output s g y start lag := by
    cases lag with
    | zero => rw [hu 0]; simp [diff,output,state]
    | succ k => simp only [diff,hu]
  have hp := shifted_increment (pStep g y) s.mP s.φP start lag
  have hi := shifted_increment (iStep g y) s.mI s.φI start lag
  have hd := shifted_increment (dStep g y) s.mD s.φD start lag
  dsimp only at hp hi hd
  rw [absolute s.p_dvd] at hp
  rw [absolute s.i_dvd] at hi
  rw [absolute s.d_dvd] at hd
  rw [curr]
  unfold support
  rw [Finset.sum_filter]
  simp only [periods,phases,col,Fin.sum_univ_succ,Matrix.cons_val_zero,Matrix.cons_val_succ,
    Finset.univ_eq_empty,Finset.sum_empty,add_zero]
  change (if phase%s.mP=s.φP then column (pStep g y) s.mP lag else 0) +
      ((if phase%s.mI=s.φI then column (iStep g y) s.mI lag else 0) +
      (if phase%s.mD=s.φD then column (dStep g y) s.mD lag else 0)) = _
  unfold output
  linarith

/-- Each observation phase has a detectable, bounded positive lag, allowing
the launching phase to depend on that lag. Quantification over every start
is exactly the time-domain nominal impulse requirement of the periodic target. -/
theorem rigid_of_phase_impulses {H L d : ℕ} (hH : 0<H) (s : Clocks L) (g : Coeff ℝ)
    (Y U : ℕ → ℕ → ℝ) (hy : ∀ q, Y q 0=0)
    (observable : ∀ p : Fin H, ∃ lag, 0 < lag ∧ lag ≤ d ∧ Y (origin H p lag) lag ≠ 0)
    (hK : 0 < g.K) (hb : 0 < g.β) (hi : 0 ≤ g.i0) (hiSum : 0 < g.i0+g.i1)
    (matchImpulse : ∀ start k, output s g (Y (start%H)) start (k+1)=U (start%H) k) :
    GridRigid H d (periods s) (phases s) := by
  classical
  let A := support (periods s) (phases s)
  intro k l same agree sub j hj
  by_contra hnot
  have subset : A k ⊆ A l := fun i h => (mem_support ..).2 (sub i ((mem_support ..).1 h))
  let D := A l \ A k
  have dj : j ∈ D := Finset.mem_sdiff.mpr ⟨(mem_support ..).2 hj,
    fun h => hnot ((mem_support ..).1 h)⟩
  have matchOrigin (lag : ℕ) : origin H k lag = origin H l lag :=
    Nat.ModEq.add_right _ same
  have zeroSum (lag : ℕ) : ∑ i ∈ D, col s g (Y (origin H k lag)) lag i = 0 := by
    change ∑ i ∈ A l \ A k, _ = 0
    rw [Finset.sum_sdiff_eq_sub subset,sub_eq_zero]
    have hl := phase_columns hH s g Y U matchImpulse l lag
    rw [← matchOrigin lag] at hl
    exact hl.trans (phase_columns hH s g Y U matchImpulse k lag).symm
  have slow {i} (hh : i ∈ D) : d < periods s i := by
    obtain ⟨present,absent⟩ := Finset.mem_sdiff.mp hh
    by_contra! fast
    exact absent ((mem_support ..).2 ((agree i fast).2 ((mem_support ..).1 present)))
  obtain ⟨q,hq,hqd,hY⟩ := observable ⟨k%H,Nat.mod_lt _ hH⟩
  have originMod : origin H (k%H) q = origin H k q :=
    Nat.ModEq.add_right _ (Nat.mod_mod k H)
  change Y (origin H (k%H) q) q ≠ 0 at hY
  rw [originMod] at hY
  let y := Y (origin H k q)
  have hc {i} (h : i∈D) : col s g y q i = amps g i * (-y q) := by
    have pr := slow_columns g y hq (hqd.trans_lt (slow h))
    fin_cases i
    · simpa [col,amps] using pr.1
    · simpa [col,amps] using pr.2.1
    · simpa [col,amps] using pr.2.2
  have scal : (∑ i ∈ D, amps g i) * (-y q) = 0 := by
    rw [Finset.sum_mul]
    exact (Finset.sum_congr rfl (fun i h => (hc h).symm)).trans (zeroSum q)
  have van := (mul_eq_zero.mp scal).resolve_right (neg_ne_zero.mpr hY)
  have nonneg (i : Fin 3) : 0 ≤ amps g i := by
    fin_cases i
    · exact hK.le
    · exact hi
    · exact hb.le
  have zero (i) (h : i∈D) : amps g i = 0 :=
    (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => nonneg i)).mp van i h
  have onlyI (i) (h : i∈D) : i=1 := by
    have hz := zero i h
    fin_cases i
    · exact False.elim (hK.ne' hz)
    · rfl
    · exact False.elim (hb.ne' hz)
  have Ds : D={1} := Finset.eq_singleton_iff_unique_mem.mpr ⟨(onlyI j dj) ▸ dj,onlyI⟩
  have hi0 : g.i0=0 := zero 1 (Ds ▸ Finset.mem_singleton_self _)
  have last := zeroSum s.mI
  rw [Ds,Finset.sum_singleton] at last
  change column (iStep g (Y (origin H k s.mI))) s.mI s.mI = 0 at last
  rw [integral_period_column _ _ (hy _) hi0 (Nat.zero_lt_of_lt s.phaseI)] at last
  linarith

theorem physical_periodic_cutoff {H L d : ℕ} (hH : 0<H) (s : Clocks L)
    (p : Physical) (h : ℝ) (hh : 0<h) (hp : Admissible p)
    (Y U : ℕ → ℕ → ℝ) (hy : ∀ q, Y q 0=0)
    (observable : ∀ q : Fin H, ∃ lag, 0<lag ∧ lag≤d ∧ Y (origin H q lag) lag ≠ 0)
    (matchImpulse : ∀ start k,
      output s (rational (s.TI h) (s.TD h) p) (Y (start%H)) start (k+1) = U (start%H) k) :
    ∀ j, periods s j ≤ 2*H^2*(max d (3*H))^2 := by
  rcases hp with ⟨hK,hTi,hTd,hTf,hI,hD,_,_⟩
  have ti : 0<s.TI h := mul_pos (by exact_mod_cast Nat.zero_lt_of_lt s.phaseI) hh
  have td : 0<s.TD h := mul_pos (by exact_mod_cast Nat.zero_lt_of_lt s.phaseD) hh
  have den := add_pos_of_pos_of_nonneg hTf (mul_nonneg hD.1 td.le)
  have kpos := div_pos (mul_pos hK ti) hTi
  have hr := rigid_of_phase_impulses hH s (rational (s.TI h) (s.TD h) p) Y U hy observable hK
    (div_pos (mul_pos hK hTd) den) (mul_nonneg kpos.le hI.1)
    (by dsimp [rational]; linarith only [kpos]) matchImpulse
  exact grid_period_bound hH (periods s) (phases s) (phase_bounds s) hr

end
end MPCPID.PeriodicNominal
