import MPCPID.PhysicalSchedule

/-! Phase-resolved command increments for a shifted nominal impulse.
The sample clock is absolute, but the reference impulse and the strictly
proper plant output are indexed relative to the start of each experiment. -/
namespace MPCPID.NominalColumns

open PhysicalSchedule GainGraph
noncomputable section

abbrev State := ℝ × ℝ
abbrev Step := ℕ → State → State

def pulse (k : ℕ) : ℝ := if k=0 then 1 else 0

def pStep (g : Coeff ℝ) (Y : ℕ → ℝ) : Step :=
  fun k _ => (g.K*(g.b*pulse k-Y k),0)

def iStep (g : Coeff ℝ) (Y : ℕ → ℝ) : Step :=
  fun k z => let e := pulse k-Y k
             (z.1+g.i0*e+g.i1*z.2,e)

def dStep (g : Coeff ℝ) (Y : ℕ → ℝ) : Step :=
  fun k z => let e := g.c*pulse k-Y k
             (g.α*z.1+g.β*(e-z.2),e)

/-- Before tick k, with the output in the first coordinate and the last sampled
error in the second coordinate. The proportional branch uses only its output. -/
def state (a : Step) (fire : ℕ → Bool) : ℕ → State
  | 0 => 0
  | k+1 => let z := state a fire k
           if fire k then a k z else z

def drive (m φ start k : ℕ) := decide ((start+k)%m=φ)

/-- Value of an increment when this branch updates at lag k; all its earlier
updates then occurred at lags congruent to k modulo the same branch period. -/
def column (a : Step) (m k : ℕ) : ℝ :=
  let z := state a (fun j => decide (j%m=k%m)) k
  (a k z).1-z.1

theorem shifted_increment (a : Step) (m φ start k : ℕ) :
    let z := state a (drive m φ start)
    (z (k+1)).1-(z k).1 =
      if (start+k)%m=φ then column a m k else 0 := by
  by_cases hit : (start+k)%m=φ
  · have fire : drive m φ start = fun j => decide (j%m=k%m) := by
      funext j
      have eqv : (start+j)%m=φ ↔ j%m=k%m := by
        rw [← hit]
        exact ⟨Nat.ModEq.add_left_cancel' start, Nat.ModEq.add_left start⟩
      simp only [drive,eqv]
    simp only [state, drive, hit, decide_true, Bool.true_eq, if_true]
    change ((a k (state a (drive m φ start) k)).1 - (state a (drive m φ start) k).1) = _
    rw [fire]
    rfl
  · simp [state, drive, hit]

/-- Command on the physical branches driven by the target impulse pair, with
all stores at zero before the impulse and arbitrary absolute experiment start. -/
def output {L : ℕ} (s : Clocks L) (g : Coeff ℝ) (Y : ℕ → ℝ) (start k : ℕ) : ℝ :=
  (state (pStep g Y) (drive s.mP s.φP start) k).1 +
  (state (iStep g Y) (drive s.mI s.φI start) k).1 +
  (state (dStep g Y) (drive s.mD s.φD start) k).1

def diff (U : ℕ → ℝ) : ℕ → ℝ
  | 0 => U 0
  | k+1 => U (k+1)-U k

/-- Any exact nominal law must pass these physical impulse experiments at
every absolute start time. The result is the same column sum for all phases. -/
theorem phase_signature {L : ℕ} (s : Clocks L) (g : Coeff ℝ) (Y U : ℕ → ℝ)
    (matchImpulse : ∀ start k, output s g Y start (k+1)=U k) (phase lag : ℕ) :
    diff U lag =
      (if phase%s.mP=s.φP then column (pStep g Y) s.mP lag else 0) +
      (if phase%s.mI=s.φI then column (iStep g Y) s.mI lag else 0) +
      (if phase%s.mD=s.φD then column (dStep g Y) s.mD lag else 0) := by
  let start := phase+lag*(L-1)
  have hL := s.frame_pos
  have endTime : start+lag=phase+lag*L := by
    dsimp [start]
    obtain ⟨n,rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hL)
    simp [Nat.mul_succ,Nat.add_assoc]
  have phaseMod {m : ℕ} (dv : m ∣ L) : (start+lag)%m=phase%m := by
    rw [endTime, Nat.add_mod, Nat.mod_eq_zero_of_dvd (dvd_mul_of_dvd_right dv lag),
      Nat.add_zero, Nat.mod_mod]
  have dh : diff U lag=output s g Y start (lag+1)-output s g Y start lag := by
    cases lag with
    | zero =>
      rw [matchImpulse start 0]
      simp [diff,output,state]
    | succ k => simp only [diff,matchImpulse]
  rw [dh]
  have hp := shifted_increment (pStep g Y) s.mP s.φP start lag
  have hi := shifted_increment (iStep g Y) s.mI s.φI start lag
  have hd := shifted_increment (dStep g Y) s.mD s.φD start lag
  dsimp only at hp hi hd
  rw [phaseMod s.p_dvd] at hp
  rw [phaseMod s.i_dvd] at hi
  rw [phaseMod s.d_dvd] at hd
  unfold output
  linarith

/-- Strictly proper plant (Y₀=0), first two columns of any slow branch. -/
theorem first_columns (g : Coeff ℝ) (Y : ℕ → ℝ) (hy : Y 0=0) (m : ℕ) (hm : 1<m) :
    column (pStep g Y) m 0 = g.K*g.b ∧
    column (iStep g Y) m 0 = g.i0 ∧
    column (dStep g Y) m 0 = g.β*g.c ∧
    column (pStep g Y) m 1 = -g.K*Y 1 ∧
    column (iStep g Y) m 1 = -g.i0*Y 1 ∧
    column (dStep g Y) m 1 = -g.β*Y 1 := by
  simp [column,state,pStep,iStep,dStep,pulse,hy,Nat.mod_eq_of_lt hm]

/-- Before a positive lag shorter than the branch period there have been no
updates of the branch whose terminal phase is that lag. Earlier plant outputs
may be arbitrary. -/
theorem slow_columns (g : Coeff ℝ) (Y : ℕ → ℝ) {m lag : ℕ}
    (hk : 0<lag) (hm : lag<m) :
    column (pStep g Y) m lag = -g.K*Y lag ∧
    column (iStep g Y) m lag = -g.i0*Y lag ∧
    column (dStep g Y) m lag = -g.β*Y lag := by
  have hz (a : Step) (k : ℕ) (hkl : k≤lag) :
      state a (fun j => decide (j%m=lag%m)) k = 0 := by
    induction k with
    | zero => rfl
    | succ k ih =>
      have kl : k<lag := by omega
      have miss : k%m ≠ lag%m := by simpa only [Nat.mod_eq_of_lt (kl.trans hm),Nat.mod_eq_of_lt hm] using kl.ne
      simpa only [state,decide_eq_true_eq,if_neg miss] using ih (by omega)
  simp [column,hz _ _ le_rfl,pStep,iStep,dStep,pulse,ne_of_gt hk]

/-- With zero instantaneous integral weight, the previously sampled initial
error appears at lag m and its coefficient is i₁. -/
theorem integral_period_column (g : Coeff ℝ) (Y : ℕ → ℝ) (hy : Y 0=0)
    (hi : g.i0=0) {m : ℕ} (hm : 0<m) : column (iStep g Y) m m = g.i1 := by
  let fire := fun j => decide (j%m=m%m)
  have mem (k : ℕ) (hk : 0<k) (hkm : k≤m) : (state (iStep g Y) fire k).2=1 := by
    induction k with
    | zero => omega
    | succ j ih =>
      cases j with
      | zero => simp [fire,state,iStep,pulse,hy]
      | succ j =>
        have hs : j+1<m := by omega
        have miss : fire (j+1)=false := by simp [fire,Nat.mod_eq_of_lt hs]
        simp only [state,miss,Bool.false_eq_true,if_false]
        exact ih (by omega) (by omega)
  have := mem m hm le_rfl
  change (state (iStep g Y) fire m).1+g.i0*(pulse m-Y m)+
    g.i1*(state (iStep g Y) fire m).2-(state (iStep g Y) fire m).1 = _
  rw [this,hi]
  ring

end
end MPCPID.NominalColumns
