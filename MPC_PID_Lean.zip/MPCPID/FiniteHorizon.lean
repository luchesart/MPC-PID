import MPCPID.Predictive

/-! Finite-window sensitivity and full feasibility on a regular KKT region. -/

namespace MPCPID.FiniteHorizon

open Finset MPCPID.Predictive

/-- Proposition 7.2, with assumptions only on the samples inside the horizon.
The sequences outside this prefix are unrestricted. -/
theorem rollout_sensitivity_on_horizon
    {X U Y : Type*} [PseudoMetricSpace X] [PseudoMetricSpace U] [PseudoMetricSpace Y]
    {n : ℕ} {l h Lx Lu Lg Le Lt : ℝ} (hl : 0 ≤ l) (hh : 0 ≤ h)
    (hLx : 0 ≤ Lx) (hLg : 0 ≤ Lg) (hLe : 0 ≤ Le) (hLt : 0 ≤ Lt)
    (F : X → U → X) (g : X → Y) (x x' : ℕ → X) (u u' : ℕ → U)
    (r : Y) (s : U) (φe φu : X → ℝ) (hx : x 0=x' 0)
    (hd : ∀ k < n, x (k+1)=F (x k) (u k)) (hd' : ∀ k < n, x' (k+1)=F (x' k) (u' k))
    (hF : ∀ k < n, dist (F (x k) (u k)) (F (x' k) (u' k)) ≤
      Lx*dist (x k) (x' k)+Lu*dist (u k) (u' k))
    (hg : ∀ k < n, dist (g (x (k+1))) (g (x' (k+1))) ≤ Lg*dist (x (k+1)) (x' (k+1)))
    (he : |φe (x n)-φe (x' n)| ≤ Le*dist (x n) (x' n))
    (ht : |φu (x n)-φu (x' n)| ≤ Lt*dist (x n) (x' n)) :
    let d := fun k => dist (u k) (u' k)
    let D := delta Lx Lu d
    let err := fun (t : ℕ → X) => (∑ k ∈ range n, h*dist (g (t (k+1))) r)+φe (t n)
    let effort := fun (t : ℕ → X) (v : ℕ → U) => (∑ k ∈ range n, h*dist (v k) s)+φu (t n)
    |miace l (err x) (effort x u) - miace l (err x') (effort x' u')| ≤
      Real.sqrt (((∑ k ∈ range n, h*(Lg*D (k+1)))+Le*D n)^2+
        l*((∑ k ∈ range n, h*d k)+Lt*D n)^2) := by
  let d := fun k => dist (u k) (u' k)
  let D := delta Lx Lu d
  have hstates : ∀ k ≤ n, dist (x k) (x' k) ≤ D k := by
    intro k
    induction k with
    | zero => intro _; simp [hx,D,delta]
    | succ k ih =>
      intro hkn
      have hk : k < n := hkn
      change dist (x (k+1)) (x' (k+1)) ≤ Lx*D k+Lu*d k
      rw [hd k hk,hd' k hk]
      exact (hF k hk).trans (add_le_add_right (mul_le_mul_of_nonneg_left (ih hk.le) hLx) _)
  have hae (k : ℕ) (hk : k < n) : |h*dist (g (x (k+1))) r - h*dist (g (x' (k+1))) r| ≤
      h*(Lg*D (k+1)) := by
    rw [← mul_sub,abs_mul,abs_of_nonneg hh]
    exact mul_le_mul_of_nonneg_left ((abs_dist_sub_le _ _ _).trans
      ((hg k hk).trans (mul_le_mul_of_nonneg_left (hstates (k+1) hk) hLg))) hh
  have hau (k : ℕ) : |h*dist (u k) s - h*dist (u' k) s| ≤ h*d k := by
    rw [← mul_sub,abs_mul,abs_of_nonneg hh]
    exact mul_le_mul_of_nonneg_left (abs_dist_sub_le _ _ _) hh
  exact finite_horizon_sensitivity hl _ _ _ _ _ _ _ _ _ _ _ _
    hae (fun i _ => hau i)
    (he.trans (mul_le_mul_of_nonneg_left (hstates n le_rfl) hLe))
    (ht.trans (mul_le_mul_of_nonneg_left (hstates n le_rfl) hLt))

/-- The candidate selected by the invertible KKT block satisfies every
constraint and is an optimizer of the full problem, provided its remaining
inequalities and the sign conditions on the multipliers hold. -/
theorem regular_kkt_full_feasible
    {E : Type*} [AddCommGroup E] [Module ℝ E] {ι J : Type*} [Fintype ι]
    (K : (E × (ι → ℝ)) ≃ₗ[ℝ] ((E →ₗ[ℝ] ℝ) × (ι → ℝ)))
    (H : E →ₗ[ℝ] E →ₗ[ℝ] ℝ) (G : J → E →ₗ[ℝ] ℝ) (active : ι → J)
    (upper : ∀ (d : E) (v : ι → ℝ) (w : E), (K (d,v)).1 w =
      H d w + ∑ i, v i * G (active i) w)
    (lower : ∀ (d : E) (v : ι → ℝ) (i : ι), (K (d,v)).2 i = G (active i) d)
    (hsym : ∀ x y, H x y = H y x) (hpsd : ∀ x, 0 ≤ H x x)
    (q : E →ₗ[ℝ] ℝ) (bound : J → ℝ) :
    let c := kktCandidate K q (fun i => bound (active i))
    let F : Set E := {x | ∀ j, G j x ≤ bound j}
    (∀ j ∉ Set.range active, G j c.1 ≤ bound j) →
    (∀ i, 0 ≤ c.2 i) →
      c.1 ∈ F ∧ IsMinOn (qp H q) F c.1 ∧
      ((∀ i, 0 < c.2 i) → ∀ x ∈ F, qp H q x ≤ qp H q c.1 → x = c.1) := by
  dsimp only
  intro inactive nonneg
  obtain ⟨heq, hmin, hunique⟩ := regular_kkt K H (fun i => G (active i))
    upper lower hsym hpsd q (fun i => bound (active i))
  refine ⟨?_, ?_, ?_⟩
  · intro j
    by_cases hj : j ∈ Set.range active
    · obtain ⟨i, rfl⟩ := hj
      exact (heq i).le
    · exact inactive j hj
  · intro x hx
    exact hmin nonneg x (fun i => hx (active i))
  · intro pos x hx hcost
    exact hunique pos x (fun i => hx (active i)) hcost

end MPCPID.FiniteHorizon
