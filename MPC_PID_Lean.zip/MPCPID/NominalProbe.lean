import MPCPID.Periodic

/-! Compactly supported nominal first-move probes from zero history.
The phase offset is the absolute sample index of the first nonzero reference. -/
namespace MPCPID.NominalProbe
open Periodic
noncomputable section
def pulse (d k : ℕ) : ℝ := if d=k then 1 else 0
def refProbe (p : ℝ) (k : ℕ) : ℝ := pulse 0 k - p*pulse 1 k
def outProbe (B θ : ℝ) (k : ℕ) : ℝ := B*pulse 1 k + θ*pulse 2 k
def cmdProbe (η a : ℝ) (k : ℕ) : ℝ := η*pulse 0 k - a*η*pulse 1 k

def advance (P I D : Prop) (K i0 i1 α β ep ei ed : ℝ) (x : Memory) : Memory := by
  classical
  exact ⟨if P then K*ep else x.p, if I then x.i+i0*ei+i1*x.eI else x.i,
    if D then α*x.d+β*(ed-x.eD) else x.d, if I then ei else x.eI, if D then ed else x.eD⟩

def regs (P I D : ℕ → Prop) (K i0 i1 α β b c p B θ : ℝ) (s : ℕ) : ℕ → Memory
  | 0 => rest
  | k+1 => let r := refProbe p k; let y := outProbe B θ k
           advance (P (s+k)) (I (s+k)) (D (s+k)) K i0 i1 α β
             (b*r-y) (r-y) (c*r-y) (regs P I D K i0 i1 α β b c p B θ s k)

def Matches (P I D : ℕ → Prop) (K i0 i1 α β b c p B θ η a : ℝ) : Prop :=
  ∀ s k, let x := regs P I D K i0 i1 α β b c p B θ s (k+1)
         x.p+x.i+x.d = cmdProbe η a k

end
end MPCPID.NominalProbe
