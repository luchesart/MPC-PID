import MPCPID.History
import MPCPID.Implementation

/-! Execution of the clipped PID with arbitrary stored history. -/
namespace MPCPID.NonzeroRun
open Implementation Conditioned
noncomputable section

/-- Run the exact same physical tick from any values in the six registers. -/
def run (G : Gains) (act : Actuator) (refs : Signal) (start : Registers) :
    ℕ → Registers
  | 0 => start
  | k+1 => G.tick act k (refs k) (run G act refs start k)

/-- Current corrected branch outputs sum to the actual actuator output. -/
private theorem applied_sum (G : Gains) (ha : G.α≠1) (act : Actuator)
    (k : ℕ) (r : ℝ) (s : Registers) :
    let v := G.measure act k r s
    v.u = G.kp*(G.b*r-s.y)+v.i+v.d := by
  dsimp only [Gains.measure]
  field_simp [sub_ne_zero.mpr (Ne.symm ha)]
  ring

/-- Take an arbitrary nonzero initial register vector. The first two samples
are a genuine physical prehistory, with freely chosen references, bounds and
initial integral and derivative memories. At every subsequent sample the
computed proposal and applied input are exactly the predictive and projected
predictive commands. The result is unconditional on future signal histories. -/
theorem projected_from_nonzero_history
    {a b₀ b₁ η f t ζ α K κ d g b c : ℝ}
    (hα : α ≠ 1) (hpole : α = -ζ*b₁) (ht : t+ζ*(b₀+b₁)=1)
    (hfit : Matching.channels α (Matching.realization K κ d g b c) =
      Matching.target α a f ζ η)
    (start : Registers) (low high : ℕ → ℝ → ℝ → ℝ) (r : Signal) :
    let G : Gains := ⟨a,b₀,b₁,α,K,b,c,κ*g,κ*(1-g),d⟩
    let act := boundActuator low high
    let states := run G act r start
    ∀ n, let k := n+2
         let s := states k
         let v := G.measure act k (r k) s
         let target := η*r k-f*s.y+t*s.prevU
         v.raw = target ∧ v.u = clip (low k s.y s.prevU) (high k s.y s.prevU) target := by
  let G : Gains := ⟨a,b₀,b₁,α,K,b,c,κ*g,κ*(1-g),d⟩
  let act := boundActuator low high
  let s := run G act r start
  let p := fun k => G.measure act k (r k) (s k)
  let y := fun k => (s k).y
  let u := fun k => (p k).u
  have hu (k : ℕ) : u k=K*(b*r k-y k)+(p k).i+(p k).d :=
    applied_sum G hα act k (r k) (s k)
  have equalities := History.all_compatible_samples hα hpole ht hfit
    r y u (fun k => (p k).raw) (fun k => (p k).i) (fun k => (p k).d)
    (fun k => (p k).delta) (fun k => low k (y k) (s k).prevU)
    (fun k => high k (y k) (s k).prevU) hu
    (by intro n; rfl) (by intro n; rfl) (by intro n; rfl)
    (by intro n; rfl) (by intro n; rfl)
  exact equalities


/-- A restart is compatible when its six registers are those reached after
two genuine preceding ticks of the prescribed plant and branch realization.
The witnesses (past registers, input values and branch states) may be nonzero.
From the first sample of the restart onward no warm-up is needed. -/
theorem projected_from_compatible_restart
    {a b₀ b₁ η f t ζ α K κ d g b c : ℝ}
    (hα : α ≠ 1) (hpole : α = -ζ*b₁) (ht : t+ζ*(b₀+b₁)=1)
    (hfit : Matching.channels α (Matching.realization K κ d g b c) =
      Matching.target α a f ζ η)
    (start : Registers) (low high : ℕ → ℝ → ℝ → ℝ) (r : Signal) :
    let G : Gains := ⟨a,b₀,b₁,α,K,b,c,κ*g,κ*(1-g),d⟩
    let act := boundActuator low high
    (∃ past, run G act r past 2 = start) →
    let states := run G (fun n => act (n+2)) (fun n => r (n+2)) start
    ∀ n, let s := states n
         let v := G.measure act (n+2) (r (n+2)) s
         let target := η*r (n+2)-f*s.y+t*s.prevU
         v.raw = target ∧
           v.u = clip (low (n+2) s.y s.prevU) (high (n+2) s.y s.prevU) target := by
  let G : Gains := ⟨a,b₀,b₁,α,K,b,c,κ*g,κ*(1-g),d⟩
  let act := boundActuator low high
  dsimp only
  rintro ⟨past,hpast⟩
  have advance (n : ℕ) :
      run G act r past (n+2) =
        run G (fun n => act (n+2)) (fun n => r (n+2)) start n := by
    induction n with
    | zero => exact hpast
    | succ n ih =>
      change G.tick act (n+2) _ (run G act r past (n+2)) = _
      rw [ih]
      rfl
  intro n
  have eq := projected_from_nonzero_history hα hpole ht hfit past low high r n
  change (let s := run G act r past (n+2)
          let v := G.measure act (n+2) (r (n+2)) s
          let target := η*r (n+2)-f*s.y+t*s.prevU
          v.raw = target ∧
            v.u = clip (low (n+2) s.y s.prevU) (high (n+2) s.y s.prevU) target) at eq
  rw [advance n] at eq
  exact eq

end
end MPCPID.NonzeroRun
