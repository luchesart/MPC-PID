import Mathlib.Topology.Algebra.InfiniteSum.Real
import Mathlib.Topology.Order.Compact
import Mathlib.Data.Real.Sqrt
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.NormNum

/-! Terminal feasibility and the two accumulated areas (Sections 9 and 10).
Lists are control sequences; states are obtained by applying the plant, including at
the appended terminal move. All costs and plant coefficients are real. -/

noncomputable section

namespace MPCPID.Terminal

open Filter Topology

variable {X U : Type*}

structure Model (X U : Type*) where
  step : X → U → X
  admissible : X → U → Prop
  terminal : X → Prop
  feedback : X → U
  feedback_admissible : ∀ x, terminal x → admissible x (feedback x)
  invariant : ∀ x, terminal x → terminal (step x (feedback x))

variable (m : Model X U)

/-- Every stage is admissible and the final predicted state is in the terminal set. -/
def Feasible (x : X) : List U → Prop
  | [] => m.terminal x
  | u :: us => m.admissible x u ∧ Feasible (m.step x u) us

/-- Extend a rollout with the terminal control evaluated at its own final state. -/
def extendPlan (x : X) : List U → List U
  | [] => [m.feedback x]
  | u :: us => u :: extendPlan (m.step x u) us

theorem extend_length (x : X) (v : List U) :
    (extendPlan m x v).length = v.length + 1 := by
  induction v generalizing x with
  | nil => rfl
  | cons u us ih => simp [extendPlan, ih]

theorem extend_feasible (x : X) (v : List U) (h : Feasible m x v) :
    Feasible m x (extendPlan m x v) := by
  induction v generalizing x with
  | nil => exact ⟨m.feedback_admissible _ h, m.invariant _ h⟩
  | cons u us ih => exact ⟨h.1, ih _ h.2⟩

/-- Equations (79) and (88), feasibility part. -/
theorem shifted_feasible (x : X) (u : U) (us : List U)
    (h : Feasible m x (u :: us)) :
    Feasible m (m.step x u) (extendPlan m (m.step x u) us) ∧
      (extendPlan m (m.step x u) us).length = (u :: us).length :=
  ⟨extend_feasible m _ us h.2, extend_length m _ us⟩

structure Budget (m : Model X U) where
  stage : X → U → ℝ
  tail : X → ℝ
  stage_nonneg : ∀ x u, 0 ≤ stage x u
  tail_nonneg : ∀ x, m.terminal x → 0 ≤ tail x
  step_le : ∀ x, m.terminal x →
    stage x (m.feedback x) + tail (m.step x (m.feedback x)) ≤ tail x

variable {m} (b : Budget m)

def area (x : X) : List U → ℝ
  | [] => b.tail x
  | u :: us => b.stage x u + area (m.step x u) us

theorem area_nonneg (x : X) (v : List U) (h : Feasible m x v) : 0 ≤ area b x v := by
  induction v generalizing x with
  | nil => exact b.tail_nonneg _ h
  | cons u us ih => exact add_nonneg (b.stage_nonneg _ _) (ih _ h.2)

theorem extended_area_le (x : X) (v : List U) (h : Feasible m x v) :
    area b x (extendPlan m x v) ≤ area b x v := by
  induction v generalizing x with
  | nil => exact b.step_le _ h
  | cons u us ih => exact add_le_add_left (ih _ h.2) _

theorem shifted_area_le (x : X) (u : U) (us : List U)
    (h : Feasible m x (u :: us)) :
    area b (m.step x u) (extendPlan m (m.step x u) us) + b.stage x u ≤
      area b x (u :: us) := by
  have ht := extended_area_le b _ us h.2
  change _ ≤ b.stage x u + area b (m.step x u) us
  linarith

def score (e c : Budget m) (l : ℝ) (x : X) (v : List U) : ℝ :=
  area e x v ^ 2 + l * area c x v ^ 2

def Optimal (e c : Budget m) (l : ℝ) (x : X) (v : List U) : Prop :=
  Feasible m x v ∧ ∀ w, w.length = v.length → Feasible m x w →
    score e c l x v ≤ score e c l x w

private theorem square_drop {a a' d : ℝ} (ha : 0 ≤ a') (hd : 0 ≤ d)
    (h : a' + d ≤ a) : a' ^ 2 + d ^ 2 ≤ a ^ 2 := by
  have := mul_self_le_mul_self (add_nonneg ha hd) h
  nlinarith [mul_nonneg ha hd]

/-- The shifted-plan bound also applies to any feasible proposal no more
expensive than the fallback, even when produced by a local optimizer. -/
theorem proposal_shift_descent (e c : Budget m) {l q : ℝ} (hl : 0 ≤ l)
    (x : X) (u : U) (us : List U) (ho : Feasible m x (u :: us))
    (hm : q ≤ score e c l (m.step x u) (extendPlan m (m.step x u) us)) :
    q + e.stage x u ^ 2 + l * c.stage x u ^ 2 ≤ score e c l x (u :: us) := by
  have hf := (shifted_feasible m x u us ho).1
  have he := square_drop (area_nonneg e _ _ hf) (e.stage_nonneg _ _)
    (shifted_area_le e _ _ _ ho)
  have hc := square_drop (area_nonneg c _ _ hf) (c.stage_nonneg _ _)
    (shifted_area_le c _ _ _ ho)
  dsimp [score] at hm ⊢
  linarith [mul_le_mul_of_nonneg_left hc hl]

/-- Theorem 9.1. A next optimal plan is compared with the constructed feasible
shift of the old plan. This only requires feasibility of the old plan. -/
theorem optimal_shift_descent (e c : Budget m) {l : ℝ} (hl : 0 ≤ l)
    (x : X) (u : U) (us w : List U) (ho : Feasible m x (u :: us))
    (hn : Optimal e c l (m.step x u) w) (hlen : w.length = (u :: us).length) :
    score e c l (m.step x u) w + e.stage x u ^ 2 + l * c.stage x u ^ 2 ≤
      score e c l x (u :: us) := by
  obtain ⟨hf, hlen'⟩ := shifted_feasible m x u us ho
  exact proposal_shift_descent e c hl x u us ho (hn.2 _ (hlen'.trans hlen.symm) hf)

/-- At every feasible state the fallback is an admissible candidate for rule (91). -/
theorem componentwise_fallback (e c : Budget m) (x : X) (u : U) (us : List U)
    (h : Feasible m x (u :: us)) :
    ∃ w, w.length = (u :: us).length ∧ Feasible m (m.step x u) w ∧
      area e (m.step x u) w + e.stage x u ≤ area e x (u :: us) ∧
      area c (m.step x u) w + c.stage x u ≤ area c x (u :: us) := by
  obtain ⟨hf, hl⟩ := shifted_feasible m _ _ _ h
  exact ⟨_, hl, hf, shifted_area_le e _ _ _ h, shifted_area_le c _ _ _ h⟩

/-- Terminal-controller rollout, used for the local upper bound (90). -/
def terminalRollout (m : Model X U) : ℕ → X → List U
  | 0, _ => []
  | n+1, x => m.feedback x :: terminalRollout m n (m.step x (m.feedback x))

theorem terminal_rollout_bound (b : Budget m) (n : ℕ) (x : X) (h : m.terminal x) :
    Feasible m x (terminalRollout m n x) ∧
      (terminalRollout m n x).length = n ∧ area b x (terminalRollout m n x) ≤ b.tail x := by
  induction n generalizing x with
  | zero => exact ⟨h, rfl, le_rfl⟩
  | succ n ih =>
    obtain ⟨hf, hl, hb⟩ := ih _ (m.invariant _ h)
    refine ⟨⟨m.feedback_admissible _ h, hf⟩, ?_, ?_⟩
    · simp [terminalRollout, hl]
    · exact (add_le_add_left hb _).trans (b.step_le _ h)

/-- Both the optimal envelope (86) and the accepted-plan budgets (91)
telescope with an explicit residual budget at the finite endpoint. -/
theorem telescope (A f : ℕ → ℝ) (h : ∀ k, A (k+1) + f k ≤ A k) (n : ℕ) :
    (∑ k ∈ Finset.range n, f k) + A n ≤ A 0 := by
  induction n with
  | zero => simp
  | succ n ih => rw [Finset.sum_range_succ]; linarith [h n]

theorem total_budget (A f : ℕ → ℝ) (hA : ∀ k, 0 ≤ A k)
    (hf : ∀ k, 0 ≤ f k) (hh : ∀ k, A (k+1) + f k ≤ A k) :
    Summable f ∧ ∑' k, f k ≤ A 0 := by
  have hb : ∀ n, ∑ k ∈ Finset.range n, f k ≤ A 0 := by
    intro n
    linarith [telescope A f hh n, hA n]
  have hs : Summable f := summable_of_sum_range_le hf hb
  exact ⟨hs, le_of_tendsto' hs.hasSum.tendsto_sum_nat hb⟩

theorem realized_areas (A B e c : ℕ → ℝ) {l : ℝ} (hl : 0 ≤ l)
    (hA : ∀ k, 0 ≤ A k) (hB : ∀ k, 0 ≤ B k)
    (he : ∀ k, 0 ≤ e k) (hc : ∀ k, 0 ≤ c k)
    (ha : ∀ k, A (k+1) + e k ≤ A k) (hb : ∀ k, B (k+1) + c k ≤ B k) :
    Summable e ∧ Summable c ∧ (∑' k, e k) ≤ A 0 ∧ (∑' k, c k) ≤ B 0 ∧
    Real.sqrt ((∑' k, e k)^2 + l * (∑' k, c k)^2) ≤ Real.sqrt (A 0 ^ 2 + l * B 0 ^ 2) := by
  obtain ⟨se, be⟩ := total_budget A e hA he ha
  obtain ⟨sc, bc⟩ := total_budget B c hB hc hb
  refine ⟨se, sc, be, bc, Real.sqrt_le_sqrt ?_⟩
  have be' := mul_self_le_mul_self (tsum_nonneg he) be
  have bc' := mul_self_le_mul_self (tsum_nonneg hc) bc
  simpa [sq] using add_le_add be' (mul_le_mul_of_nonneg_left bc' hl)

/-- Equation (87) and asymptotic disappearance of the total squared stage. -/
theorem squared_summability (W e c : ℕ → ℝ) {l : ℝ} (hl : 0 ≤ l)
    (hW : ∀ k, 0 ≤ W k)
    (hd : ∀ k, W (k+1) + (e k ^ 2 + l * c k ^ 2) ≤ W k) :
    Summable (fun k => e k ^ 2 + l * c k ^ 2) ∧
      (∑' k, (e k ^ 2 + l * c k ^ 2)) ≤ W 0 ∧
      Tendsto (fun k => e k ^ 2 + l * c k ^ 2) atTop (𝓝 0) := by
  obtain ⟨hs, hb⟩ := total_budget W _ hW (fun k => by positivity) hd
  exact ⟨hs, hb, hs.tendsto_atTop_zero⟩

/-- The scalar dynamics (93), its terminal controller (94), and (95)–(96). -/
def scalarStep (x u : ℝ) := x + (1/10 : ℝ) * (1 + x^2) * (u-x)
def contraction (x : ℝ) := 1 - (1/5 : ℝ) * (1 + x^2)
def inTerminal (x : ℝ) : Prop := 4/5 ≤ x ∧ x ≤ 6/5

theorem scalar_factor (x : ℝ) :
    scalarStep x (2-x) - 1 = contraction x * (x-1) := by
  unfold scalarStep contraction
  ring

theorem scalar_factor_bounds {x : ℝ} (h : inTerminal x) :
    64/125 ≤ contraction x ∧ contraction x ≤ 84/125 := by
  obtain ⟨h0,h1⟩ := h
  have hpos : 0 ≤ x := by linarith
  have hx1 := mul_self_le_mul_self hpos h1
  have hx0 := mul_self_le_mul_self (by norm_num : (0:ℝ) ≤ 4/5) h0
  unfold contraction
  constructor <;> nlinarith

theorem scalar_contract {x : ℝ} (h : inTerminal x) :
    |scalarStep x (2-x) - 1| ≤ (84/125) * |x-1| := by
  obtain ⟨hq, hu⟩ := scalar_factor_bounds h
  rw [scalar_factor, abs_mul, abs_of_nonneg (show 0 ≤ contraction x by linarith)]
  exact mul_le_mul_of_nonneg_right hu (abs_nonneg _)

theorem scalar_invariant {x : ℝ} (h : inTerminal x) : inTerminal (scalarStep x (2-x)) := by
  have hh := scalar_contract h
  obtain ⟨hl,hr⟩ := h
  have hx : |x-1| ≤ (1/5:ℝ) := abs_le.mpr ⟨by linarith, by linarith⟩
  have hz : |scalarStep x (2-x) - 1| ≤ (1/5:ℝ) := by linarith
  obtain ⟨lo,hi⟩ := abs_le.mp hz
  exact ⟨by linarith, by linarith⟩

def scalarModel : Model ℝ ℝ where
  step := scalarStep
  admissible x u := 0 ≤ x ∧ x ≤ 6/5 ∧ 0 ≤ u ∧ u ≤ 2
  terminal := inTerminal
  feedback x := 2-x
  feedback_admissible := by
    intro x hx
    obtain ⟨hl,hr⟩ := hx
    exact ⟨by linarith, hr, by linarith, by linarith⟩
  invariant := fun _ h => scalar_invariant h

def scalarErrorBudget : Budget scalarModel where
  stage x u := |scalarStep x u - 1|/10
  tail x := (42/205) * |x-1|
  stage_nonneg := by intros; positivity
  tail_nonneg := by intros; positivity
  step_le := by
    intro x hx
    change |scalarStep x (2-x) - 1|/10 + 42/205 * |scalarStep x (2-x) - 1| ≤ 42/205 * |x-1|
    linarith [scalar_contract hx]

def scalarInputBudget : Budget scalarModel where
  stage _ u := |u-1|/10
  tail x := (25/82) * |x-1|
  stage_nonneg := by intros; positivity
  tail_nonneg := by intros; positivity
  step_le := by
    intro x hx
    change |(2-x)-1|/10 + 25/82 * |scalarStep x (2-x) - 1| ≤ 25/82 * |x-1|
    rw [show (2-x)-1 = -(x-1) by ring, abs_neg]
    linarith [scalar_contract hx]

/-- A division-free completed square gives the first inequality in (97). -/
theorem detection_square (z v b l : ℝ) (hl : 0 < l) :
    l*(1-b)^2*z^2 / (l+b^2) ≤ ((1-b)*z+b*v)^2+l*v^2 := by
  have hD : 0 < l+b^2 := by positivity
  apply (div_le_iff₀ hD).2
  nlinarith only [sq_nonneg (b*(1-b)*z+(l+b^2)*v)]


/-- The uniform bound in (97) on the whole scalar state constraint interval. -/
theorem scalar_detection {x u l : ℝ} (hx : 0 ≤ x) (hu : x ≤ 6/5) (hl : 0 < l) :
    (1/100 : ℝ)*l*(189/250)^2*(x-1)^2/(l+(61/250)^2) ≤
      (|scalarStep x u-1|/10)^2 + l*(|u-1|/10)^2 := by
  let b : ℝ := (1+x^2)/10
  have hb : 0 ≤ b := by dsimp [b]; positivity
  have hbu : b ≤ 61/250 := by
    dsimp [b]; nlinarith [mul_self_le_mul_self hx hu]
  have hn : (189/250:ℝ)^2 ≤ (1-b)^2 := by
    have := mul_self_le_mul_self (by norm_num : (0:ℝ) ≤ 189/250)
      (show 189/250 ≤ 1-b by linarith)
    nlinarith
  have hden : l+b^2 ≤ l+(61/250)^2 := by nlinarith [mul_self_le_mul_self hb hbu]
  have hnu : l*(189/250)^2*(x-1)^2 ≤ l*(1-b)^2*(x-1)^2 :=
    mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hn hl.le) (sq_nonneg _)
  have hfrac := div_le_div_of_nonneg_right hnu (show 0 ≤ l+(61/250:ℝ)^2 by positivity)
  have hd := div_le_div_of_nonneg_left (show 0 ≤ l*(1-b)^2*(x-1)^2 by positivity)
    (show 0 < l+b^2 by positivity) hden
  have hfinal := (hfrac.trans hd).trans (detection_square (x-1) (u-1) b l hl)
  have hid : scalarStep x u-1 = (1-b)*(x-1)+b*(u-1) := by unfold scalarStep; dsimp [b]; ring
  rw [hid, div_pow (abs ((1-b)*(x-1)+b*(u-1))) 10 2, div_pow (abs (u-1)) 10 2, sq_abs, sq_abs]
  calc
    _ = (1/100 : ℝ)*(l*(189/250)^2*(x-1)^2/(l+(61/250)^2)) := by ring
    _ ≤ _ := by linarith only [hfinal]

/-- A single closed-loop trajectory of optimizing plans, with actual plant successors.
The horizon is preserved, and the cumulative squared costs are bounded. -/
theorem optimal_trajectory (e c : Budget m) {l : ℝ} (hl : 0 ≤ l)
    (x : ℕ → X) (u : ℕ → U) (tail : ℕ → List U)
    (dyn : ∀ k, x (k+1) = m.step (x k) (u k))
    (fixed : ∀ k, (tail (k+1)).length = (tail k).length)
    (opt : ∀ k, Optimal e c l (x k) (u k :: tail k)) :
    Summable (fun k => e.stage (x k) (u k)^2 + l*c.stage (x k) (u k)^2) ∧
    (∑' k, (e.stage (x k) (u k)^2 + l*c.stage (x k) (u k)^2)) ≤
       score e c l (x 0) (u 0 :: tail 0) ∧
    Tendsto (fun k => e.stage (x k) (u k)^2 + l*c.stage (x k) (u k)^2) atTop (𝓝 0) := by
  apply squared_summability (fun k => score e c l (x k) (u k :: tail k))
      (fun k => e.stage (x k) (u k)) (fun k => c.stage (x k) (u k)) hl
  · intro k; unfold score; positivity
  · intro k
    have ho := opt (k+1)
    rw [dyn k] at ho ⊢
    have hd := optimal_shift_descent e c hl (x k) (u k) (tail k)
      (u (k+1) :: tail (k+1)) (opt k).1 ho (by simp [fixed k])
    linarith

/-- Condition (89) implies convergence to the equilibrium in any metric state space. -/
theorem detected_convergence {S : Type*} [PseudoMetricSpace S]
    (xs : S) (x : ℕ → S) (f : ℕ → ℝ) (chi : ℝ → ℝ)
    (hc : StrictMono chi) (h0 : chi 0 = 0)
    (hd : ∀ k, chi (dist (x k) xs) ≤ f k)
    (hf : Tendsto f atTop (𝓝 0)) : Tendsto x atTop (𝓝 xs) := by
  apply Metric.tendsto_nhds.2
  intro eps he
  have pos : 0 < chi eps := by simpa [h0] using hc he
  filter_upwards [hf.eventually_lt_const pos] with k hk
  exact hc.lt_iff_lt.mp ((hd k).trans_lt hk)

/-- Lyapunov stability from a dominating positive comparison function and
a decreasing storage bounded initially below the prescribed threshold. -/
theorem lyapunov_radius {S : Type*} [PseudoMetricSpace S]
    (xs : S) (x : ℕ → S) (W : ℕ → ℝ) (chi : ℝ → ℝ)
    (hc : StrictMono chi) {eps : ℝ} (hinit : W 0 < chi eps)
    (lower : ∀ k, chi (dist (x k) xs) ≤ W k) (dec : ∀ k, W (k+1) ≤ W k) :
    ∀ k, dist (x k) xs < eps := by
  have hm : Antitone W := antitone_nat_of_succ_le dec
  intro k
  exact hc.lt_iff_lt.mp (((lower k).trans (hm (Nat.zero_le k))).trans_lt hinit)

/-- Uniform geometric estimate on an invariant neighborhood. -/
theorem exponential_estimate (W r : ℕ → ℝ) (c C : ℝ) (hC : 0 < C)
    (hc : 0 ≤ c) (hle : c ≤ C) (hu : ∀ k, W k ≤ C * r k ^ 2)
    (hd : ∀ k, W (k+1) + c * r k ^ 2 ≤ W k) (n : ℕ) :
    W n ≤ (1-c/C)^n * W 0 := by
  have hfac : 0 ≤ 1-c/C := by apply sub_nonneg.mpr; exact (div_le_one hC).mpr hle
  induction n with
  | zero => simp
  | succ n ih =>
    have hb : (c/C)*W n ≤ c*r n ^ 2 := by
      calc
        _ ≤ (c/C)*(C*r n ^ 2) := mul_le_mul_of_nonneg_left (hu n) (div_nonneg hc hC.le)
        _ = _ := by field_simp; ring
    calc
      W (n+1) ≤ (1-c/C)*W n := by nlinarith only [hd n, hb]
      _ ≤ (1-c/C)*((1-c/C)^n*W 0) := mul_le_mul_of_nonneg_left ih hfac
      _ = _ := by ring

/-- The two-step MIACE example in Section 10.1. All real input pairs are compared. -/
def twoError (u v : ℝ) := |1-u/2| + |1-u/4-v/2|
def twoEffort (u v : ℝ) := |u-1| + |v-1|
def twoScore (u v : ℝ) := twoError u v ^ 2 + twoEffort u v ^ 2
def twoQuadratic (u v : ℝ) := (1-u/2)^2 + (1-u/4-v/2)^2 + (u-1)^2 + (v-1)^2

theorem two_step_miace_min (u v : ℝ) :
    twoScore (34/25) 1 = 9/25 ∧ twoScore (34/25) 1 ≤ twoScore u v := by
  have hm : twoScore (34/25) 1 = 9/25 := by norm_num [twoScore, twoError, twoEffort, abs_div]
  refine ⟨hm, ?_⟩
  have h : 3 ≤ 4 * twoError u v + 3 * twoEffort u v := by
    unfold twoError twoEffort
    linarith only [le_abs_self (1-u/2), le_abs_self (1-u/4-v/2),
      le_abs_self (u-1), le_abs_self (v-1), abs_nonneg (v-1)]
  rw [hm]
  unfold twoScore
  nlinarith only [mul_self_le_mul_self (by norm_num : (0:ℝ) ≤ 3) h,
    sq_nonneg (3*twoError u v - 4*twoEffort u v)]

theorem two_step_quadratic_min (u v : ℝ) :
    twoQuadratic (16/13) (14/13) ≤ twoQuadratic u v ∧
      twoScore (34/25) 1 < twoScore (16/13) (14/13) := by
  constructor
  · unfold twoQuadratic
    nlinarith only [sq_nonneg (u-16/13), sq_nonneg (v-14/13),
      sq_nonneg ((u-16/13)/2), sq_nonneg ((u-16/13)/4+(v-14/13)/2)]
  · norm_num [twoScore, twoError, twoEffort, abs_div]


/-- Compactness argument following (85). Parameters may be the vectors in
a finite product of compact input sets. Each stage constraint and the
terminal condition is pulled back along its continuous prediction map. -/
theorem finite_horizon_attainment {P Z T : Type*} [TopologicalSpace P]
    [CompactSpace P] [TopologicalSpace Z] [TopologicalSpace T] {n : ℕ}
    (prediction : Fin n → P → Z) (endpoint : P → T)
    (closedStage : Fin n → Set Z) (closedEnd : Set T)
    (hstage : ∀ j, IsClosed (closedStage j)) (hend : IsClosed closedEnd)
    (cp : ∀ j, Continuous (prediction j)) (ce : Continuous endpoint)
    (cost : P → ℝ)
    (good : Set P)
    (hg : good = {p | (∀ j, prediction j p ∈ closedStage j) ∧ endpoint p ∈ closedEnd})
    (existsFeasible : good.Nonempty) (continuousCost : ContinuousOn cost good) :
    ∃ p ∈ good, IsMinOn cost good p := by
  have hclosed : IsClosed good := by
    rw [hg]
    have left : IsClosed {p | ∀ j, prediction j p ∈ closedStage j} := by
      have heq : {p | ∀ j, prediction j p ∈ closedStage j} =
          ⋂ j, (prediction j) ⁻¹' (closedStage j) := by ext p; simp
      rw [heq]
      exact isClosed_iInter fun j => (hstage j).preimage (cp j)
    exact left.inter (hend.preimage ce)
  exact hclosed.isCompact.exists_isMinOn existsFeasible continuousCost

/-- Output and input convergence for the sampled norm stages (78). -/
theorem tracking_and_input_converge {Y V : Type*} [PseudoMetricSpace Y] [PseudoMetricSpace V]
    (y : ℕ → Y) (u : ℕ → V) (r : Y) (us : V) {h l : ℝ} (hh : 0 < h) (hl : 0 < l)
    (hf : Tendsto (fun k => (h * dist (y k) r)^2 + l*(h*dist (u k) us)^2)
      atTop (𝓝 0)) :
    Tendsto y atTop (𝓝 r) ∧ Tendsto u atTop (𝓝 us) := by
  constructor
  · apply Metric.tendsto_nhds.2
    intro eps he
    have hpos : 0 < (h*eps)^2 := by positivity
    filter_upwards [hf.eventually_lt_const hpos] with k hk
    by_contra! bad
    have bound := mul_self_le_mul_self (mul_nonneg hh.le he.le)
      (mul_le_mul_of_nonneg_left bad hh.le)
    nlinarith only [hk, bound, mul_nonneg hl.le (sq_nonneg (h*dist (u k) us))]
  · apply Metric.tendsto_nhds.2
    intro eps he
    have hpos : 0 < l*(h*eps)^2 := by positivity
    filter_upwards [hf.eventually_lt_const hpos] with k hk
    by_contra! bad
    have bound := mul_self_le_mul_self (mul_nonneg hh.le he.le)
      (mul_le_mul_of_nonneg_left bad hh.le)
    have bound' := mul_le_mul_of_nonneg_left bound hl.le
    nlinarith only [hk, bound', sq_nonneg (h*dist (y k) r)]


/-- A physical trajectory can use an arbitrary proposer. Whenever it declines,
the stored terminal extension is substituted; the two infinite totals are bounded. -/
theorem accepted_trajectory (e c : Budget m) {l : ℝ} (hl : 0 ≤ l)
    (x : ℕ → X) (u : ℕ → U) (tail : ℕ → List U)
    (dyn : ∀ k, x (k+1) = m.step (x k) (u k))
    (initial : Feasible m (x 0) (u 0 :: tail 0))
    (rule : ∀ k,
      (Feasible m (x (k+1)) (u (k+1) :: tail (k+1)) ∧
       area e (x (k+1)) (u (k+1) :: tail (k+1)) + e.stage (x k) (u k) ≤
          area e (x k) (u k :: tail k) ∧
       area c (x (k+1)) (u (k+1) :: tail (k+1)) + c.stage (x k) (u k) ≤
          area c (x k) (u k :: tail k)) ∨
       (u (k+1) :: tail (k+1)) = extendPlan m (x (k+1)) (tail k)) :
    (∀ k, Feasible m (x k) (u k :: tail k)) ∧
    Summable (fun k => e.stage (x k) (u k)) ∧ Summable (fun k => c.stage (x k) (u k)) ∧
    (∑' k, e.stage (x k) (u k)) ≤ area e (x 0) (u 0 :: tail 0) ∧
    (∑' k, c.stage (x k) (u k)) ≤ area c (x 0) (u 0 :: tail 0) ∧
    Real.sqrt ((∑' k, e.stage (x k) (u k))^2 + l*(∑' k, c.stage (x k) (u k))^2) ≤
      Real.sqrt (score e c l (x 0) (u 0 :: tail 0)) := by
  have hstep : ∀ k, Feasible m (x k) (u k :: tail k) →
      Feasible m (x (k+1)) (u (k+1) :: tail (k+1)) ∧
      area e (x (k+1)) (u (k+1) :: tail (k+1)) + e.stage (x k) (u k) ≤
        area e (x k) (u k :: tail k) ∧
      area c (x (k+1)) (u (k+1) :: tail (k+1)) + c.stage (x k) (u k) ≤
        area c (x k) (u k :: tail k) := by
    intro k hk
    rcases rule k with hp | hp
    · exact hp
    · rw [hp, dyn k]
      exact ⟨(shifted_feasible m _ _ _ hk).1, shifted_area_le e _ _ _ hk,
        shifted_area_le c _ _ _ hk⟩
  have hfeas : ∀ k, Feasible m (x k) (u k :: tail k) := by
    intro k
    induction k with
    | zero => exact initial
    | succ k ih => exact (hstep k ih).1
  refine ⟨hfeas, ?_⟩
  exact realized_areas (fun k => area e (x k) (u k :: tail k))
    (fun k => area c (x k) (u k :: tail k)) _ _ hl
    (fun k => area_nonneg e _ _ (hfeas k)) (fun k => area_nonneg c _ _ (hfeas k))
    (fun k => e.stage_nonneg (x k) (u k)) (fun k => c.stage_nonneg (x k) (u k))
    (fun k => (hstep k (hfeas k)).2.1) (fun k => (hstep k (hfeas k)).2.2)


/-- Equation (90) for any minimizing plan, by comparison with the rollout
of the same terminal feedback for both areas. -/
theorem optimal_terminal_upper (e c : Budget m) {l : ℝ} (hl : 0 ≤ l)
    (x : X) (v : List U) (hx : m.terminal x) (hv : Optimal e c l x v) :
    score e c l x v ≤ e.tail x ^ 2 + l*c.tail x ^ 2 := by
  obtain ⟨hf, hn, he⟩ := terminal_rollout_bound e v.length x hx
  have hc := (terminal_rollout_bound c v.length x hx).2.2
  have em := mul_self_le_mul_self (area_nonneg e _ _ hf) he
  have cm := mul_self_le_mul_self (area_nonneg c _ _ hf) hc
  apply (hv.2 _ hn hf).trans
  simpa [score, sq] using add_le_add em (mul_le_mul_of_nonneg_left cm hl)

/-- Epsilon-delta Lyapunov stability, allowing an arbitrary feasible state domain. -/
theorem lyapunov_stability {S : Type*} [PseudoMetricSpace S] (xs : S)
    (domain : Set S) (W : S → ℝ) (chi : ℝ → ℝ)
    (hcont : ContinuousWithinAt W domain xs) (hWeq : W xs = 0)
    (hchi : StrictMono chi) (hzero : chi 0 = 0) :
    ∀ eps > 0, ∃ delta > 0, ∀ (x : ℕ → S), x 0 ∈ domain →
      dist (x 0) xs < delta → (∀ k, chi (dist (x k) xs) ≤ W (x k)) →
      (∀ k, W (x (k+1)) ≤ W (x k)) → ∀ k, dist (x k) xs < eps := by
  intro eps he
  have ht : 0 < chi eps := by simpa [hzero] using hchi he
  obtain ⟨delta, hdelta, hd⟩ := Metric.continuousWithinAt_iff.mp hcont _ ht
  refine ⟨delta, hdelta, ?_⟩
  intro x hx hnear hlo hdec
  have hw := hd hx hnear
  rw [hWeq, Real.dist_eq, sub_zero] at hw
  exact lyapunov_radius xs x (fun k => W (x k)) chi hchi
    ((le_abs_self _).trans_lt hw) hlo hdec

/-- Continuity of the squared cost on the restricted feasible parameter set.
The terminal costs only need to be continuous along feasible endpoints. -/
theorem score_continuous_on {P : Type*} [TopologicalSpace P] {n : ℕ} (good : Set P)
    (a b : Fin n → P → ℝ) (te tu : P → ℝ) (l : ℝ)
    (ha : ∀ j, ContinuousOn (a j) good) (hb : ∀ j, ContinuousOn (b j) good)
    (ht : ContinuousOn te good) (hu : ContinuousOn tu good) :
    ContinuousOn (fun p => ((∑ j, a j p) + te p)^2 +
      l*((∑ j, b j p) + tu p)^2) good := by
  have ea := continuousOn_finset_sum Finset.univ (fun j _ => ha j)
  have ua := continuousOn_finset_sum Finset.univ (fun j _ => hb j)
  exact ((ea.add ht).pow 2).add (continuousOn_const.mul ((ua.add hu).pow 2))


/-- Prediction from a finite input vector. The modulo extension only affects
indices beyond the optimization horizon. -/
def vectorState (F : X → U → X) (x : X) {n : ℕ} (hn : 0 < n)
    (v : Fin n → U) : ℕ → X
  | 0 => x
  | k+1 => F (vectorState F x hn v k) (v ⟨k % n, Nat.mod_lt _ hn⟩)

theorem continuous_vector_state [TopologicalSpace X] [TopologicalSpace U]
    (F : X → U → X) (x : X) (cf : Continuous (Function.uncurry F)) {n : ℕ}
    (hn : 0 < n) (k : ℕ) : Continuous (fun v => vectorState F x hn v k) := by
  induction k with
  | zero => exact continuous_const
  | succ k ih => exact cf.comp (ih.prodMk (continuous_apply _))

/-- Compact-input existence assertion at (85), with the actual finite vector
rollout, state/input constraints and terminal functions continuous on Xf. -/
theorem compact_mpc_minimizer [TopologicalSpace X] [TopologicalSpace U] [CompactSpace U]
    (F : X → U → X) (x : X) (cf : Continuous (Function.uncurry F))
    {n : ℕ} (hn : 0 < n) (stageSet : Set (X × U)) (terminalSet : Set X)
    (cs : IsClosed stageSet) (ct : IsClosed terminalSet)
    (e c : X × U → ℝ) (ce : Continuous e) (cc : Continuous c)
    (te tu : X → ℝ) (cte : ContinuousOn te terminalSet) (ctu : ContinuousOn tu terminalSet)
    (l : ℝ) :
    let pair := fun (j : Fin n) (v : Fin n → U) => (vectorState F x hn v j, v j)
    let last := fun v => vectorState F x hn v n
    let good : Set (Fin n → U) := {v | (∀ j, pair j v ∈ stageSet) ∧ last v ∈ terminalSet}
    let J := fun v => ((∑ j, e (pair j v)) + te (last v))^2 +
       l*((∑ j, c (pair j v)) + tu (last v))^2
    good.Nonempty → ∃ v ∈ good, IsMinOn J good v := by
  dsimp only
  intro hgood
  let pair := fun (j : Fin n) (v : Fin n → U) => (vectorState F x hn v j, v j)
  let last := fun (v : Fin n → U) => vectorState F x hn v n
  let good : Set (Fin n → U) := {v | (∀ j, pair j v ∈ stageSet) ∧ last v ∈ terminalSet}
  have cp : ∀ j, Continuous (pair j) :=
    fun j => (continuous_vector_state F x cf hn j.val).prodMk (continuous_apply j)
  have cl : Continuous last := continuous_vector_state F x cf hn n
  have hm : Set.MapsTo last good terminalSet := fun _ hv => hv.2
  apply finite_horizon_attainment pair last (fun _ => stageSet) terminalSet
    (fun _ => cs) ct cp cl _ good rfl hgood
  exact score_continuous_on good (fun j v => e (pair j v)) (fun j v => c (pair j v))
    (fun v => te (last v)) (fun v => tu (last v)) l
    (fun j => (ce.comp (cp j)).continuousOn) (fun j => (cc.comp (cp j)).continuousOn)
    (cte.comp cl.continuousOn hm) (ctu.comp cl.continuousOn hm)


/-- The scalar example, with the actual optimal control and plant applied at
every sample: state convergence and input convergence from arbitrary feasible starts. -/
theorem scalar_optimal_convergence {l : ℝ} (hl : 0 < l)
    (x u : ℕ → ℝ) (us : ℕ → List ℝ)
    (dyn : ∀ k, x (k+1) = scalarStep (x k) (u k))
    (hlen : ∀ k, (us (k+1)).length = (us k).length)
    (opt : ∀ k, Optimal scalarErrorBudget scalarInputBudget l (x k) (u k :: us k)) :
    Tendsto x atTop (𝓝 1) ∧ Tendsto u atTop (𝓝 1) := by
  have hv := (optimal_trajectory scalarErrorBudget scalarInputBudget hl.le x u us dyn hlen opt).2.2
  let kappa := (1/100:ℝ)*l*(189/250)^2/(l+(61/250)^2)
  have hp : 0 < kappa := by dsimp [kappa]; positivity
  constructor
  · apply Metric.tendsto_nhds.2
    intro eps he
    filter_upwards [hv.eventually_lt_const (show 0 < kappa*eps^2 by positivity)] with k hk
    have hadm := (opt k).1.1
    have hs := scalar_detection (u := u k) hadm.1 hadm.2.1 hl
    change (|scalarStep (x k) (u k) - 1| /10)^2 + l*(|u k-1|/10)^2 < kappa*eps^2 at hk
    have hd : kappa*(x k-1)^2 < kappa*eps^2 := by
      calc
        _ = (1/100 : ℝ)*l*(189/250)^2*(x k-1)^2/(l+(61/250)^2) := by dsimp [kappa]; ring
        _ < _ := hs.trans_lt hk
    have hd' := (mul_lt_mul_left hp).mp hd
    rw [Real.dist_eq]
    by_contra! bad
    have bh := mul_self_le_mul_self he.le bad
    simpa only [← sq, sq_abs] using (not_le_of_gt hd' (by simpa only [← sq, sq_abs] using bh))
  · apply Metric.tendsto_nhds.2
    intro eps he
    filter_upwards [hv.eventually_lt_const (show 0 < l*(eps/10)^2 by positivity)] with k hk
    change (|scalarStep (x k) (u k)-1|/10)^2+l*(|u k-1|/10)^2 < l*(eps/10)^2 at hk
    rw [Real.dist_eq]
    by_contra! bad
    have hb := mul_self_le_mul_self (show 0 ≤ eps/10 by positivity)
      (div_le_div_of_nonneg_right bad (by norm_num : (0:ℝ) ≤ 10))
    nlinarith only [mul_le_mul_of_nonneg_left hb hl.le, hk,
      sq_nonneg (|scalarStep (x k) (u k)-1|/10)]

/-- Strengthening of the local upper bound: for the scalar example a sufficiently
small initial state error keeps the predicted value and the state uniformly small. -/
theorem scalar_optimal_local_bound {l : ℝ} (hl : 0 < l)
    (x u : ℕ → ℝ) (us : ℕ → List ℝ)
    (dyn : ∀ k, x (k+1) = scalarStep (x k) (u k))
    (hlen : ∀ k, (us (k+1)).length = (us k).length)
    (opt : ∀ k, Optimal scalarErrorBudget scalarInputBudget l (x k) (u k :: us k))
    (initial : inTerminal (x 0)) (k : ℕ) :
    ((1/100:ℝ)*l*(189/250)^2/(l+(61/250)^2))*(x k-1)^2 ≤
      ((42/205)^2 + l*(25/82)^2)*(x 0-1)^2 := by
  let W := fun j => score scalarErrorBudget scalarInputBudget l (x j) (u j :: us j)
  have hdec : ∀ j, W (j+1) + scalarErrorBudget.stage (x j) (u j)^2 +
      l*scalarInputBudget.stage (x j) (u j)^2 ≤ W j := by
    intro j
    dsimp only [W]; rw [dyn j]
    have hnext := opt (j+1); rw [dyn j] at hnext
    exact optimal_shift_descent _ _ hl.le _ _ _ _ (opt j).1 hnext (by simp [hlen j])
  have hW : ∀ j, 0 ≤ W j := by intro j; dsimp [W,score]; positivity
  have ha : Antitone W := antitone_nat_of_succ_le (fun j => by
    linarith [hdec j, sq_nonneg (scalarErrorBudget.stage (x j) (u j)),
      mul_nonneg hl.le (sq_nonneg (scalarInputBudget.stage (x j) (u j)))])
  have hoff := (opt k).1.1
  have hdet := scalar_detection (u := u k) hoff.1 hoff.2.1 hl
  have hs : (|scalarStep (x k) (u k)-1|/10)^2+l*(|u k-1|/10)^2 ≤ W k := by
    have hd := hdec k
    change W (k+1) + (|scalarStep (x k) (u k)-1|/10)^2+l*(|u k-1|/10)^2 ≤ W k at hd
    linarith [hW (k+1)]
  have hterm := optimal_terminal_upper scalarErrorBudget scalarInputBudget hl.le _ _ initial (opt 0)
  calc
    _ = (1/100:ℝ)*l*(189/250)^2*(x k-1)^2/(l+(61/250)^2) := by ring
    _ ≤ _ := hdet.trans (hs.trans (ha (Nat.zero_le k)))
    _ ≤ _ := by
      apply hterm.trans
      change ((42/205)*|x 0-1|)^2+l*((25/82)*|x 0-1|)^2 ≤ _
      rw [mul_pow, mul_pow, sq_abs]
      nlinarith


/-- A scalar acceptance filter can compare a feasible proposal with the fallback
in just the squared objective. Its stage guarantee is summability of squares. -/
theorem scalar_acceptance_trajectory (e c : Budget m) {l : ℝ} (hl : 0 ≤ l)
    (x : ℕ → X) (u : ℕ → U) (tail : ℕ → List U)
    (dyn : ∀ k, x (k+1) = m.step (x k) (u k))
    (initial : Feasible m (x 0) (u 0 :: tail 0))
    (rule : ∀ k, (Feasible m (x (k+1)) (u (k+1) :: tail (k+1)) ∧
      score e c l (x (k+1)) (u (k+1) :: tail (k+1)) ≤
      score e c l (x (k+1)) (extendPlan m (x (k+1)) (tail k))) ∨
      (u (k+1) :: tail (k+1)) = extendPlan m (x (k+1)) (tail k)) :
    (∀ k, Feasible m (x k) (u k :: tail k)) ∧
    Summable (fun k => e.stage (x k) (u k)^2 + l*c.stage (x k) (u k)^2) ∧
    (∑' k, (e.stage (x k) (u k)^2 + l*c.stage (x k) (u k)^2)) ≤
       score e c l (x 0) (u 0 :: tail 0) ∧
    Tendsto (fun k => e.stage (x k) (u k)^2 + l*c.stage (x k) (u k)^2) atTop (𝓝 0) := by
  have hh : ∀ k, Feasible m (x k) (u k :: tail k) →
      Feasible m (x (k+1)) (u (k+1) :: tail (k+1)) ∧
      score e c l (x (k+1)) (u (k+1) :: tail (k+1)) ≤
      score e c l (m.step (x k) (u k)) (extendPlan m (m.step (x k) (u k)) (tail k)) := by
    intro k hx
    rcases rule k with h | h
    · exact ⟨h.1, by simpa only [dyn k] using h.2⟩
    · rw [h, dyn k]
      exact ⟨(shifted_feasible m _ _ _ hx).1, le_rfl⟩
  have hf : ∀ k, Feasible m (x k) (u k :: tail k) := by
    intro k; induction k with
    | zero => exact initial
    | succ k ih => exact (hh k ih).1
  refine ⟨hf, ?_⟩
  apply squared_summability (fun k => score e c l (x k) (u k :: tail k))
    (fun k => e.stage (x k) (u k)) (fun k => c.stage (x k) (u k)) hl
  · intro k; unfold score; positivity
  · intro k
    linarith only [proposal_shift_descent e c hl _ _ _ (hf k) (hh k (hf k)).2]

/-- Both published two-step area pairs, hence the quoted square-root values. -/
theorem two_step_exact_areas :
    twoError (34/25) 1 = 12/25 ∧ twoEffort (34/25) 1 = 9/25 ∧
    twoError (16/13) (14/13) = 7/13 ∧ twoEffort (16/13) (14/13) = 4/13 ∧
    twoScore (16/13) (14/13) = 5/13 := by
  norm_num [twoError, twoEffort, twoScore, abs_div]

/-- The terminal feedback approaches the reference monotonically from either side. -/
theorem scalar_terminal_monotone {x : ℝ} (hx : inTerminal x) :
    (x ≤ 1 → x ≤ scalarStep x (2-x) ∧ scalarStep x (2-x) ≤ 1) ∧
    (1 ≤ x → 1 ≤ scalarStep x (2-x) ∧ scalarStep x (2-x) ≤ x) := by
  obtain ⟨hlo,hhi⟩ := scalar_factor_bounds hx
  have h0 : 0 ≤ contraction x := by linarith
  have h1 : 0 ≤ 1-contraction x := by linarith
  have eq := scalar_factor x
  constructor <;> intro h
  · constructor <;> nlinarith [mul_nonneg h0 (sub_nonneg.mpr h),
      mul_nonneg h1 (sub_nonneg.mpr h)]
  · constructor <;> nlinarith [mul_nonneg h0 (sub_nonneg.mpr h),
      mul_nonneg h1 (sub_nonneg.mpr h)]

/-- Initial feasibility for the implemented experiment can already be certified
on the whole lower interval. Its feedback contraction factor there is at most 4/5. -/
theorem scalar_rollout_from_below (n : ℕ) {x : ℝ} (hx : 0 ≤ x) (hu : x ≤ 1)
    (horizon : (4/5:ℝ)^n*(1-x) ≤ 1/5) :
    Feasible scalarModel x (terminalRollout scalarModel n x) := by
  induction n generalizing x with
  | zero =>
    simp only [pow_zero, one_mul] at horizon
    exact ⟨by linarith, by linarith⟩
  | succ n ih =>
    have hq0 : 0 ≤ contraction x := by
      unfold contraction; nlinarith [mul_self_le_mul_self hx hu]
    have hq1 : contraction x ≤ 4/5 := by unfold contraction; nlinarith [sq_nonneg x]
    have eq := scalar_factor x
    have hnn : 0 ≤ 1-x := sub_nonneg.mpr hu
    have non := mul_nonneg hq0 hnn
    have hu1 := mul_le_mul_of_nonneg_right hq1 hnn
    have hdec : 1-scalarStep x (2-x) ≤ (4/5)*(1-x) := by nlinarith
    refine ⟨⟨hx, by linarith, (show 0 ≤ 2-x by linarith), (show 2-x ≤ 2 by linarith)⟩,
      ih (x := scalarStep x (2-x)) (by nlinarith) (by nlinarith) ?_⟩
    calc
      _ ≤ (4/5:ℝ)^n*((4/5)*(1-x)) := mul_le_mul_of_nonneg_left hdec (by positivity)
      _ = (4/5:ℝ)^(n+1)*(1-x) := by ring
      _ ≤ _ := horizon

theorem scalar_twelve_step_feasible :
    Feasible scalarModel 0 (terminalRollout scalarModel 12 0) :=
  scalar_rollout_from_below 12 (by norm_num) (by norm_num) (by norm_num)


/-- Existence of an entire receding-horizon optimizing trajectory from a *single*
feasible initial state. Attainment is requested only on the feasible domain.
The successor stays in that domain by the explicit terminal extension. -/
theorem exists_optimal_trajectory (e c : Budget m) (l : ℝ) (n : ℕ) (x₀ : X)
    (h₀ : ∃ v : List U, v.length = n+1 ∧ Feasible m x₀ v)
    (attainment : ∀ x, (∃ v : List U, v.length = n+1 ∧ Feasible m x v) →
      ∃ v : List U, v.length = n+1 ∧ Optimal e c l x v) :
    ∃ (x : ℕ → X) (u : ℕ → U) (tail : ℕ → List U), x 0 = x₀ ∧
      (∀ k, (tail k).length = n) ∧ (∀ k, x (k+1) = m.step (x k) (u k)) ∧
      ∀ k, Optimal e c l (x k) (u k :: tail k) := by
  classical
  let D := {x : X // ∃ v : List U, v.length = n+1 ∧ Feasible m x v}
  have hg : ∀ x : D, ∃ p : U × List U,
      p.2.length = n ∧ Optimal e c l x.val (p.1 :: p.2) := by
    intro x
    obtain ⟨v, hv, ho⟩ := attainment _ x.property
    cases v with
    | nil => simp at hv
    | cons u vs => exact ⟨(u,vs), by simpa using hv, ho⟩
  let proposal (x : D) := Classical.choose (hg x)
  have hp (x : D) := Classical.choose_spec (hg x)
  let after (x : D) : D := ⟨m.step x.val (proposal x).1, by
    have hplan : Optimal e c l x.val ((proposal x).1 :: (proposal x).2) := (hp x).2
    obtain ⟨hf, hs⟩ := shifted_feasible m _ _ _ hplan.1
    exact ⟨_, hs.trans (by simp [proposal, (hp x).1]), hf⟩⟩
  let path : ℕ → D := fun k => (after^[k]) ⟨x₀,h₀⟩
  refine ⟨fun k => (path k).val, fun k => (proposal (path k)).1, fun k => (proposal (path k)).2,
    rfl, fun k => (hp (path k)).1, ?_, fun k => (hp (path k)).2⟩
  intro k
  dsimp only [path]
  rw [Function.iterate_succ_apply']

end MPCPID.Terminal
