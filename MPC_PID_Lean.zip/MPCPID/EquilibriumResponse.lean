import MPCPID.NoZeroTarget
import Mathlib.LinearAlgebra.FiniteDimensional.Basic

/-! Each output phase of a stable nominal loop responds to a reference step.
The feedback equilibrium imposes tracking at every phase. -/
namespace MPCPID.EquilibriumResponse
open PhysicalLift PhysicalSchedule Periodic NoZeroTarget
noncomputable section

def memory (g : GainGraph.Coeff ℝ) (r u : ℝ) : Fin 5 → ℝ :=
  ![g.K*(g.b*r-r),u-g.K*(g.b*r-r),0,0,g.c*r-r]

private theorem read_memory (g : GainGraph.Coeff ℝ) (r u : ℝ) :
    readBranches ℝ * column (memory g r u) = scalar u := by
  ext i j
  fin_cases i
  simp [readBranches,column,scalar,Matrix.mul_apply,Fin.sum_univ_succ,memory]

private theorem unchanged (g : GainGraph.Coeff ℝ) (s : Flags) (r u : ℝ) :
    drivenBranches (bit s.p) (bit s.i) (bit s.d) g.K g.i0 g.i1 g.α
      g.β g.b g.c r r (memory g r u) = memory g r u := by
  funext i
  fin_cases i <;> simp [drivenBranches,memory] <;> ring

theorem phase_equilibrium {n : ℕ} (P : Plant ℝ n) (g : GainGraph.Coeff ℝ)
    (s : Flags) (x : Mat n 1) (r u : ℝ) (plant : P.A*x+P.B*scalar u=x)
    (output : P.C*x=scalar r) :
    let ph := physicalPhase P g s
    let X := rows x (column (memory g r u))
    ph.A*X+ph.B*scalar r=X ∧ ph.C*X+ph.D*scalar r=rows (scalar r) (scalar u) := by
  have next := nextBranches g s (memory g r u) r r
  rw [unchanged] at next
  have act := physicalPhase_action P g s x (column (memory g r u)) (scalar r)
  dsimp only at act ⊢
  rw [output,←next,read_memory,plant] at act
  exact act

private theorem coordinate {n : ℕ} (i : Fin n) : ∃ e : Mat n 1 →ₗ[ℝ] ℝ,
    ∀ x, e x = x i 0 := by
  exact ⟨⟨⟨fun x => x i 0,by simp⟩,by simp⟩, fun _ => rfl⟩

theorem fixed_zero {n : ℕ} (A : Mat n n) (X : Mat n 1) (stable : ScheduleCertificate.Stable A)
    (hx : A*X=X) : X=0 := by
  ext i j
  fin_cases j
  by_contra h
  obtain ⟨e,he⟩ := coordinate i
  apply constant_observation A X e h _ stable
  intro q
  rw [he]
  have p (k : ℕ) : A^k*X=X := by
    induction k with
    | zero => simp
    | succ k ih => rw [pow_succ',Matrix.mul_assoc,ih,hx]
  rw [p]
  rfl

def rosen {n : ℕ} (P : Plant ℝ n) : (Mat n 1 × ℝ) →ₗ[ℝ] (Mat n 1 × ℝ) where
  toFun z := (z.1-(P.A*z.1+P.B*scalar z.2),(P.C*z.1) 0 0)
  map_add' := by
    intro x y
    have hs : scalar (x.2+y.2)=scalar x.2+scalar y.2 := rfl
    change ((x.1+y.1)-(P.A*(x.1+y.1)+P.B*scalar (x.2+y.2)),(P.C*(x.1+y.1)) 0 0) = _
    rw [hs,Matrix.mul_add,Matrix.mul_add,Matrix.mul_add]
    apply Prod.ext
    · change _ = (_-_)+(_-_)
      abel
    · rfl
  map_smul' := by
    intro a x
    have hs : scalar (a*x.2)=a • scalar x.2 := rfl
    change (a • x.1-(P.A*(a • x.1)+P.B*scalar (a*x.2)),(P.C*(a • x.1)) 0 0) = _
    simp [hs,Matrix.mul_smul,smul_sub,smul_add]

theorem plant_equilibrium {n L : ℕ} (P : Plant ℝ n) (g : GainGraph.Coeff ℝ)
    (s : ℕ → Flags)
    (st : ScheduleCertificate.Stable (physicalFrame P g s L).A) (r : ℝ) :
    ∃ (x : Mat n 1) (u : ℝ), P.A*x+P.B*scalar u=x ∧ P.C*x=scalar r := by
  have eqzero : Function.Injective (rosen P) := LinearMap.ker_eq_bot.mp
    (LinearMap.ker_eq_bot'.mpr (by
      rintro ⟨x,u⟩ h
      have hx : x-(P.A*x+P.B*scalar u)=0 := congrArg Prod.fst h
      have hy : (P.C*x) 0 0=0 := congrArg Prod.snd h
      have hp := (sub_eq_zero.mp hx).symm
      have hout : P.C*x=scalar (0:ℝ) := by ext i j; fin_cases i; fin_cases j; exact hy
      let X := rows x (column (memory g 0 u))
      let F := physicalFrame P g s L
      have fixed (k : ℕ) : (physicalPhase P g (s k)).A*X=X := by
        have H := (phase_equilibrium P g (s k) x 0 u hp hout).1
        have zero : scalar (0:ℝ)=(0 : Mat 1 1) := rfl
        simpa only [zero,Matrix.mul_zero,add_zero] using H
      have hf : F.A*X=X := by
        change liftedPhi (fun k => (physicalPhase P g (s k)).A) L * X = X
        generalize L = k
        induction k with
        | zero => simp [liftedPhi]
        | succ k ih => rw [liftedPhi, Matrix.mul_assoc, ih, fixed]
      have full := fixed_zero F.A X st hf
      have xp : x=0 := by
        ext i j
        have hj := congrArg (fun t : Mat (n+5) 1 => t (finSumFinEquiv (Sum.inl i)) j) full
        simpa [X,rows,Matrix.submatrix_apply] using hj
      have up : u=0 := by
        have hj := congrArg (fun t : Mat (n+5) 1 => t (finSumFinEquiv (Sum.inr (1:Fin 5))) 0) full
        simpa [X,rows,column,Matrix.submatrix_apply,memory] using hj
      exact Prod.ext xp up))
  obtain ⟨⟨x,u⟩,he⟩ := (LinearMap.injective_iff_surjective.mp eqzero) (0,r)
  have hx : x-(P.A*x+P.B*scalar u)=0 := congrArg Prod.fst he
  have hy : (P.C*x) 0 0=r := congrArg Prod.snd he
  exact ⟨x,u,(sub_eq_zero.mp hx).symm,by ext i j; fin_cases i; fin_cases j; exact hy⟩

private theorem units {L : ℕ} (k : Fin L) :
    (selector₁ L k : Mat 1 L) * ones L = scalar (1:ℝ) := by
  ext i j
  rw [Matrix.mul_apply, Finset.sum_eq_single k]
  · simp [selector₁,ones,scalar]
  · intro a _ h
    simp [selector₁,show a.val ≠ k.val from fun e => h (Fin.ext e)]
  · simp

theorem frame_equilibrium {n L : ℕ} (P : Plant ℝ n) (g : GainGraph.Coeff ℝ)
    (s : ℕ → Flags) (x : Mat n 1) (u : ℝ) (hp : P.A*x+P.B*scalar u=x)
    (ho : P.C*x=scalar (1:ℝ)) :
    let X := rows x (column (memory g 1 u))
    let F := physicalFrame P g s L
    F.A*X+F.B*ones L=X ∧ ∀ k : Fin L, (F.C*X+F.D*ones L) (finProdFinEquiv (k,0)) 0=1 := by
  let X := rows x (column (memory g 1 u))
  let t := fun k => physicalPhase P g (s k)
  let y := frameState (fun k => (t k).A) (fun k => (t k).B)
     (fun k => (selector₁ L k : Mat 1 L)*ones L) X
  have iden (k : ℕ) (hk : k ≤ L) : y k=X := by
    induction k with
    | zero => rfl
    | succ k ih =>
      change (t k).A*y k + (t k).B*((selector₁ L k : Mat 1 L)*ones L)=_
      rw [ih (by omega), units (⟨k,by omega⟩ : Fin L)]
      exact (phase_equilibrium P g (s k) x 1 u hp ho).1
  constructor
  · have he := frameWith_state t (selector₁ L) L X (ones L)
    exact he.symm.trans (iden L le_rfl)
  · intro k
    have he := frameWith_output t (selector₁ L) L X (ones L) k
    have eq := congrArg (fun B : Mat 2 1 => B 0 0) he
    change _ = ((t k).C*y k + (t k).D*((selector₁ L k : Mat 1 L)*ones L)) 0 0 at eq
    rw [iden k k.isLt.le,units] at eq
    exact eq.trans (congrArg (fun B : Mat 2 1 => B 0 0) (phase_equilibrium P g (s k) x 1 u hp ho).2)

theorem every_phase_output {n L : ℕ} (P : Plant ℝ n) (g : GainGraph.Coeff ℝ)
    (s : ℕ → Flags) (st : ScheduleCertificate.Stable (physicalFrame P g s L).A) (k : Fin L) :
    let F := physicalFrame P g s L
    ∃ q, (F.C*blocksAt F (ones L) q + F.D*ones L) (finProdFinEquiv (k,0)) 0 ≠ 0 := by
  classical
  let F := physicalFrame P g s L
  let m : Fin (L*2) := finProdFinEquiv (k,(0:Fin 2))
  obtain ⟨x,u,he,ho⟩ := plant_equilibrium P g s st 1
  let X := rows x (column (memory g 1 u))
  obtain ⟨hf,hy⟩ := frame_equilibrium P g s x u he ho (L:=L)
  have fixed : F.A*X+F.B*ones L=X := hf
  have hout : (F.C*X+F.D*ones L) m 0=1 := hy k
  let f : Mat (n+5) 1 →ₗ[ℝ] ℝ :=
    ⟨⟨fun z => (F.C*z) m 0,by intro a b; simp [Matrix.mul_add]⟩,
      by intro a z; simp [Matrix.mul_smul]⟩
  have dif (q : ℕ) : F.A^q*X=X-blocksAt F (ones L) q := by
    induction q with
    | zero => simp [blocksAt]
    | succ q ih =>
      rw [pow_succ', Matrix.mul_assoc,ih,blocksAt,Matrix.mul_sub]
      conv_rhs => rw [←fixed]
      abel
  dsimp only
  by_contra! hz
  apply constant_observation F.A X f one_ne_zero _ st
  intro q
  rw [dif]
  change (F.C*(X-blocksAt F (ones L) q)) m 0 = 1
  rw [Matrix.mul_sub,Matrix.sub_apply]
  have zero : (F.C*blocksAt F (ones L) q + F.D*ones L) m 0=0 := hz q
  simp only [Matrix.add_apply] at hout zero
  linarith

theorem every_matched_phase {n L t : ℕ} (P : Plant ℝ n) (g : GainGraph.Coeff ℝ)
    (s : ℕ → Flags) (T : System ℝ t L (L*2))
    (st : ScheduleCertificate.Stable (physicalFrame P g s L).A)
    (hm : MatchSys (physicalFrame P g s L) T) (k : Fin L) :
    ∃ q, (T.C*blocksAt T (ones L) q + T.D*ones L) (finProdFinEquiv (k,0)) 0 ≠ 0 := by
  obtain ⟨q,hq⟩ := every_phase_output P g s st k
  have eq := hm (ones L) (List.replicate q (ones L))
  rw [←blocksAt_advance,←blocksAt_advance] at eq
  exact ⟨q,by rwa [← eq]⟩

end
end MPCPID.EquilibriumResponse
