import MPCPID.ClosedLoopOptimal

/-! Absolute coordinates and synchronized stored states for a reference step
between two arbitrary equilibria (Theorems 8.4 and 8.5). -/
noncomputable section
namespace MPCPID.EquilibriumShift

open ClosedLoopOptimal PhysicalOptimal Conditioned

/-- Offsetting the equilibrium reference changes the proportional branch by
K(b−1)old. The integral branch supplies the balance of the steady command.
The derivative branch at equilibrium has zero output. -/
def storedBias (P : Optimal.Model) (G : Gains) (old : ℝ) :=
  equilibriumInput P old - G.K*(G.b-1)*old

def translate (P : Optimal.Model) (G : Gains) (old : ℝ) (x : State) : State :=
  ⟨x.y+old, x.oldY+old, x.oldU+equilibriumInput P old, x.oldR+old,
    x.integral+storedBias P G old, x.diff⟩

theorem translated_branches (P : Optimal.Model) (G : Gains) (old r : ℝ) (x : State) :
    G.I (translate P G old x) (r+old) = G.I x r + storedBias P G old ∧
    G.D (translate P G old x) (r+old) = G.D x r ∧
    G.U (translate P G old x) (r+old) = G.U x r + equilibriumInput P old := by
  have hI : G.I (translate P G old x) (r+old) = G.I x r + storedBias P G old := by
    unfold Gains.I translate; dsimp; ring
  have hD : G.D (translate P G old x) (r+old) = G.D x r := by
    unfold Gains.D translate; dsimp; ring
  refine ⟨hI,hD,?_⟩
  unfold Gains.U
  rw [hI,hD]
  dsimp [translate,storedBias]
  ring

theorem translate_tick (P : Optimal.Model) (G : Gains) (old r : ℝ) (x : State) :
    G.tick P (r+old) (translate P G old x) = translate P G old (G.tick P r x) := by
  obtain ⟨hI,hD,hU⟩ := translated_branches P G old r x
  simp only [Gains.tick]
  rw [hU,hI,hD]
  dsimp only [translate]
  congr 1
  nlinarith only [equilibrium_identity P old]

def absoluteRun (P : Optimal.Model) (G : Gains) (old new : ℝ) : ℕ → State
  | 0 => translate P G old rest
  | k+1 => G.tick P new (absoluteRun P G old new k)

theorem translate_run (P : Optimal.Model) (G : Gains) (old new : ℝ) (k : ℕ) :
    absoluteRun P G old new k = translate P G old (G.run P (new-old) k) := by
  induction k with
  | zero => rfl
  | succ k ih =>
    simp only [absoluteRun, Gains.run, ih]
    simpa using translate_tick P G old (new-old) (G.run P (new-old) k)

theorem equilibrium_initialized (P : Optimal.Model) (G : Gains) (r : ℝ) :
    G.tick P r (translate P G r rest) = translate P G r rest ∧
    G.U (translate P G r rest) r = equilibriumInput P r := by
  have h := translate_tick P G r 0 rest
  have hu := (translated_branches P G r 0 rest).2.2
  have hz : G.tick P 0 rest = rest := by
    simp [Gains.tick,Gains.U,Gains.I,Gains.D,rest]
  have huz : G.U rest 0 = 0 := by simp [rest,Gains.U,Gains.I,Gains.D]
  exact ⟨by simpa only [zero_add,hz] using h, by simpa only [zero_add,huz] using hu⟩

def absoluteY (P : Optimal.Model) (G : Gains) (old new : ℝ) (k : ℕ) :=
  (absoluteRun P G old new k).y
def absoluteU (P : Optimal.Model) (G : Gains) (old new : ℝ) (k : ℕ) :=
  G.U (absoluteRun P G old new k) new

theorem absolute_signals (P : Optimal.Model) (G : Gains) (old new : ℝ) (k : ℕ) :
    absoluteY P G old new k = G.y P (new-old) k + old ∧
    absoluteU P G old new k = G.u P (new-old) k + equilibriumInput P old := by
  unfold absoluteY absoluteU
  rw [translate_run]
  exact ⟨rfl, by simpa [Gains.u] using
    (translated_branches P G old (new-old) (G.run P (new-old) k)).2.2⟩

theorem cost_signals (P : Optimal.Model) (G : Gains) (old new : ℝ) :
    actualError new (absoluteY P G old new) = actualError (new-old) (G.y P (new-old)) ∧
    actualExcess P new (absoluteU P G old new) = actualExcess P (new-old) (G.u P (new-old)) := by
  constructor <;> funext k
  · unfold actualError
    rw [(absolute_signals P G old new (k+1)).1]
    ring
  · unfold actualExcess
    rw [(absolute_signals P G old new k).2]
    unfold equilibriumInput
    ring

/-- Delay with the actual old equilibrium command before time zero. -/
def previous (oldInput : ℝ) (u : Signal) : Signal
  | 0 => oldInput
  | k+1 => u k

theorem translated_competitor (P : Optimal.Model) (old new : ℝ) (y u : Signal)
    (h0 : y 0=old)
    (hd : ∀ k, y (k+1) = P.a*y k + P.b*u k + P.c*previous (equilibriumInput P old) u k) :
    let y' := fun k => y k-old
    let u' := fun k => u k-equilibriumInput P old
    y' 0=0 ∧ (∀ k, y' (k+1) = P.a*y' k + P.b*u' k + P.c*lag u' k) ∧
      actualError (new-old) y' = actualError new y ∧
      actualExcess P (new-old) u' = actualExcess P new u := by
  dsimp only
  have hprev k : lag (fun j => u j-equilibriumInput P old) k =
      previous (equilibriumInput P old) u k - equilibriumInput P old := by
    cases k <;> simp [previous,lag]
  refine ⟨by rw [h0,sub_self],?_,?_,?_⟩
  · intro k; rw [hd,hprev]; nlinarith only [equilibrium_identity P old]
  · funext k; unfold actualError; ring
  · funext k; unfold actualExcess equilibriumInput; ring

/-- A single choice of positive physical gains attains the exact global minimum
for every pair of equilibrium references. The competitor is an arbitrary raw
plant trajectory in the original, unshifted coordinates. -/
theorem globally_optimal_between_equilibria (P : Optimal.Model) {h μ : ℝ}
    (hh : 0 < h) (hμ : 0 < μ) (hpos : max 0 (P.c^2-P.b^2) < P.l)
    (htune : P.l=P.b*μ*(1-P.a)/P.s) (hmono : P.b*P.c ≤ P.a*P.l) :
    ∃ G : Gains, 0 < G.K ∧ 0 < G.κ ∧ 0 < G.d ∧ G.g ∈ Set.Icc 0 1 ∧
      G.b ∈ Set.Icc 0 1 ∧ G.c ∈ Set.Icc 0 1 ∧ -1 < G.α ∧ G.α < 1 ∧
      (∃ Ti Td Tf : ℝ, 0<Ti ∧ 0<Td ∧ 0<Tf ∧
        G.K*h/Ti=G.κ ∧ 1-h/Tf=G.α ∧ G.K*Td/Tf=G.d) ∧
      ∀ old new : ℝ,
        Optimal.Model.cost h μ (actualError new (absoluteY P G old new))
           (actualExcess P new (absoluteU P G old new)) =
            P.barrier h (new-old) / Real.sqrt ((1-P.a)^2+P.s^2/μ) ∧
        ∀ y u : Signal, y 0=old →
          (∀ k, y (k+1)=P.a*y k+P.b*u k+P.c*previous (equilibriumInput P old) u k) →
          Optimal.Model.extendedCost h μ (actualError new (absoluteY P G old new))
            (actualExcess P new (absoluteU P G old new)) ≤
          Optimal.Model.extendedCost h μ (actualError new y) (actualExcess P new u) := by
  obtain ⟨G,kp,ki,kd,gi,b,c,al,au,time,allSteps⟩ :=
    exists_realized_optimum P hh hμ hpos htune hmono
  refine ⟨G,kp,ki,kd,gi,b,c,al,au,time,?_⟩
  intro old new
  have tot := allSteps (new-old)
  obtain ⟨he,hu⟩ := cost_signals P G old new
  rw [he,hu]
  refine ⟨tot.1, ?_⟩
  intro y u h0 hd
  obtain ⟨hinit,hplant,err,eff⟩ := translated_competitor P old new y u h0 hd
  rw [← err,← eff]
  exact tot.2 _ _ hinit hplant


/-- Physical sample formulas from Theorem 8.4 in absolute coordinates.
The monotone-zone and infinite-horizon tuning hypotheses are unnecessary here. -/
theorem physical_step_signals (P : Optimal.Model) (G : Gains) (old new : ℝ)
    (ha : G.α ≠ 1)
    (hpole : G.α= -Predictive.zeta P.b P.c P.l*P.c)
    (hfit : Matching.channels G.α (Matching.realization G.K G.κ G.d G.g G.b G.c) =
      Matching.target G.α P.a (Predictive.fy P.a P.b P.l)
        (Predictive.zeta P.b P.c P.l) (Predictive.eta P.a P.b P.c P.l)) :
    actualError new (absoluteY P G old new) = P.err (new-old) ∧
    actualExcess P new (absoluteU P G old new) = P.cmd (new-old) := by
  obtain ⟨he,hu⟩ := cost_signals P G old new
  rw [he,hu]
  have ht := (Predictive.equilibrium_gains P.a P.b P.c P.l P.hb P.hc P.hl).2
  have hsum : Predictive.memoryGain P.b P.c P.l+Predictive.zeta P.b P.c P.l*(P.b+P.c)=1 := by
    rw [ht]; field_simp [ne_of_gt (add_pos P.hb P.hc)]
  exact applied_signals P (new-old) _ _ rfl (G.plant_eq P (new-old))
    (G.first_move P (new-old) ha hpole hsum hfit)

end MPCPID.EquilibriumShift
