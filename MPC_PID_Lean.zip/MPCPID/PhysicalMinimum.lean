import MPCPID.NominalRigidity
import MPCPID.NominalIntegral
import MPCPID.TargetDelay
import MPCPID.GainGraph
import MPCPID.UpdateOpt

/-! Global necessity over all positive integer periods for nominal matching
of the one-step MIACE target. No finite schedule library is assumed. -/
namespace MPCPID.PhysicalMinimum
open Periodic NominalProbe TargetProbe Predictive
noncomputable section

theorem nominal_miace_forces_base_rate {mP mI mD φP φI φD : ℕ}
    (hp : φP<mP) (hi : φI<mI) (hd : φD<mD)
    (q : GainGraph.Physical) (adm : GainGraph.Admissible q) {h a b₀ b₁ l : ℝ}
    (hh : 0<h) (ha : 0≤a) (ha1 : a<1) (hb : 0<b₀) (hc : 0<b₁)
    (hl : max 0 (b₁^2-b₀^2)<l) :
    let g := GainGraph.rational ((mI:ℝ)*h) ((mD:ℝ)*h) q
    NominalMatch (atPhase mP φP) (atPhase mI φI) (atPhase mD φD)
      g.K g.i0 g.i1 g.α g.β g.b g.c a b₀ b₁ (eta a b₀ b₁ l) (fy a b₀ l) (memoryGain b₀ b₁ l) →
    mP=1 ∧ mI=1 ∧ mD=1 := by
  let TI := (mI:ℝ)*h
  let TD := (mD:ℝ)*h
  let g := GainGraph.rational TI TD q
  let e := eta a b₀ b₁ l
  let π := pole a b₀ b₁ l
  dsimp only
  intro hm
  obtain ⟨hη,hθ,hθlt,bal,hπ,ht⟩ := parameters ha ha1 hb hc hl
  have hprobe := match_probe (atPhase mP φP) (atPhase mI φI) (atPhase mD φD)
    g.K g.i0 g.i1 g.α g.β g.b g.c a b₀ b₁ e (fy a b₀ l) (memoryGain b₀ b₁ l) π hπ ht hm
  obtain ⟨hk,hti,htd,htf,hγi,hγd,_,_⟩ := adm
  have hTI : 0<TI := mul_pos (by exact_mod_cast (show 0<mI by omega)) hh
  have hTD : 0<TD := mul_pos (by exact_mod_cast (show 0<mD by omega)) hh
  have den := add_pos_of_pos_of_nonneg htf (mul_nonneg hγd.1 hTD.le)
  have betaPos : 0<g.β := div_pos (mul_pos hk htd) den
  have alphaNe : g.α ≠ 1 := by
    change 1 - TD/(q.Tf+q.γD*TD) ≠ 1
    linarith [div_pos hTD den]
  have gainPos := div_pos (mul_pos hk hTI) hti
  have i0 : 0≤g.i0 := mul_nonneg gainPos.le hγi.1
  have i1 : 0≤g.i1 := mul_nonneg gainPos.le (sub_nonneg.mpr hγi.2)
  have gi : 0<g.i0+g.i1 := by
    change 0 < q.K*TI/q.Ti*q.γI + q.K*TI/q.Ti*(1-q.γI)
    convert gainPos using 1
    ring
  have unitI := integral_clock_is_one hp hi hd g.K g.i0 g.i1 g.α g.β g.b g.c π
    (e*b₀) (e*b₁) e a alphaNe gi hθlt hprobe
  have allI (k : ℕ) : atPhase mI φI k := by
    simp [atPhase,unitI,show φI=0 by omega,Nat.mod_one]
  obtain ⟨unitP,unitD⟩ := NominalRigidity.probe_pd_clocks hp hd allI hk betaPos i0 i1 gi
    (mul_pos hη hb) hθ hη ha bal hprobe
  exact ⟨unitP,unitI,unitD⟩

/-- Equality of the physical command with the prescribed first move on all
references, starting once from the ordinary zero history at phase zero. -/
def originMatch (P I D : ℕ → Prop) (K i0 i1 α β b c a b₀ b₁ η f t : ℝ) :=
  ∀ (r : ℕ → ℝ) k, let z := traj a b₀ b₁ η f t r
    let x := stores P I D K i0 i1 α β b c r (fun j => (z j).1) 0 (k+1)
    x.p+x.i+x.d=(z (k+1)).2

/-- Update rates of all integer clocks and all positive physical controllers
matching the prescribed MIACE first move, with any additional requirement
such as the interval gain reserve. The additional requirement may depend on
the complete schedule and the fixed physical parameter vector. -/
def costs (a b₀ b₁ l h : ℝ)
    (admitGain : (n : ℕ) → PhysicalSchedule.Clocks n → GainGraph.Physical → Prop) : Set ℝ :=
  {v | ∃ (n : ℕ) (s : PhysicalSchedule.Clocks n) (q : GainGraph.Physical),
    GainGraph.Admissible q ∧ admitGain n s q ∧
    (let g := GainGraph.rational (s.TI h) (s.TD h) q
     originMatch (atPhase s.mP s.φP) (atPhase s.mI s.φI) (atPhase s.mD s.φD)
       g.K g.i0 g.i1 g.α g.β g.b g.c a b₀ b₁ (eta a b₀ b₁ l) (fy a b₀ l) (memoryGain b₀ b₁ l)) ∧
    v=UpdateOpt.rate h s}

/-- Over unbounded integer periods, nonemptiness is exactly the criterion
for the minimum to be 3/h; every admissible witness attains it. -/
theorem nominal_global_minimum {h a b₀ b₁ l : ℝ}
    (hh : 0<h) (ha : 0≤a) (ha1 : a<1) (hb : 0<b₀) (hc : 0<b₁)
    (hl : max 0 (b₁^2-b₀^2)<l)
    (admitGain : (n : ℕ) → PhysicalSchedule.Clocks n → GainGraph.Physical → Prop) :
    (costs a b₀ b₁ l h admitGain).Nonempty ↔
      IsLeast (costs a b₀ b₁ l h admitGain) (3/h) := by
  have only {v} (hv : v ∈ costs a b₀ b₁ l h admitGain) : v=3/h := by
    obtain ⟨n,s,q,adm,_,hm,rfl⟩ := hv
    obtain ⟨p,i,d⟩ := nominal_miace_forces_base_rate s.phaseP s.phaseI s.phaseD
      q adm hh ha ha1 hb hc hl (phase_zero_suffices _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ hm)
    rw [UpdateOpt.update_rate s hh,p,i,d]
    norm_num
  constructor
  · rintro ⟨v,hv⟩
    exact ⟨only hv ▸ hv,fun w hw => (only hw).ge⟩
  · intro H
    exact ⟨_,H.1⟩

end
end MPCPID.PhysicalMinimum
