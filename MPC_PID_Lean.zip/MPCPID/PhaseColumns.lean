import MPCPID.PhaseSplit
import MPCPID.PhaseCorrection

/-! The rank and one-coordinate solutions applied to observations of actual
physical resets in the paired PID–target state space. -/
namespace MPCPID.PhaseColumns
open MPCPID.PhysicalLift MPCPID.Periodic MPCPID.PhaseSplit MPCPID.PhaseCorrection
noncomputable section

private theorem rows_smul {n t : ℕ} (c : ℝ) (B : Mat n 1) (T : Mat t 1) :
    c • rows B T = rows (c • B) (c • T) := by
  ext k j
  change c * Matrix.fromRows B T (finSumFinEquiv.symm k) j =
    Matrix.fromRows (c • B) (c • T) (finSumFinEquiv.symm k) j
  cases finSumFinEquiv.symm k <;> rfl

/-- The post-event state increments in the paired physical loops, with the
target sign in the observation matrix. -/
def post {n t : ℕ} (B : Mat n 1) (T : Mat t 1) (a b : ℝ) : Mat (n+5+t) 1 :=
  pairStack (rows B (column ![0,a,b,0,0])) T

private theorem post_affine {n t : ℕ} (B : Mat n 1) (T : Mat t 1) (a b : ℝ) :
    post B T a b = post B T 0 0 + a • post (0 : Mat n 1) (0 : Mat t 1) 1 0 +
      b • post (0 : Mat n 1) (0 : Mat t 1) 0 1 := by
  change rows (rows B _) T = rows (rows B _) T + a • rows (rows 0 _) 0 +
    b • rows (rows 0 _) 0
  simp only [rows_smul,rows_add,smul_zero,add_zero]
  apply congrArg (fun m : Mat 5 1 => rows (rows B m) T)
  ext i j
  fin_cases i <;> simp [column,Matrix.add_apply,Matrix.smul_apply]

def observe {ι : Type*} {n t : ℕ} (O : ι → Mat 1 (n+5+t)) (B : Mat n 1)
    (T : Mat t 1) (a b : ℝ) (j : ι) : ℝ :=
  (O j * post B T a b) 0 0

/-- Each observation of the actual physical pulse is affine in the two memory
coefficients. In particular the coefficients at a given phase are unaffected
by the choices at every other phase. -/
theorem observe_affine {ι : Type*} {n t : ℕ} (O : ι → Mat 1 (n+5+t))
    (B : Mat n 1) (T : Mat t 1) (a b : ℝ) (j : ι) :
    observe O B T a b j = observe O B T 0 0 j +
      a*observe O 0 0 1 0 j + b*observe O 0 0 0 1 j := by
  unfold observe
  rw [post_affine B T a b]
  simp [Matrix.mul_add,Matrix.mul_smul,Matrix.add_apply,Matrix.smul_apply]

theorem supported_columns {ι : Type*} {n t : ℕ} (s : Flags)
    (O : ι → Mat 1 (n+5+t)) (B : Mat n 1) (T : Mat t 1) :
    (∃ a b : ℝ, (s.i = false → a = 0) ∧ (s.d = false → b = 0) ∧
      ∀ j, observe O B T a b j = 0) ↔
    -observe O B T 0 0 ∈ Submodule.span ℝ
      {enabled s.i (observe O 0 0 1 0), enabled s.d (observe O 0 0 0 1)} := by
  rw [← free_iff_span]
  apply exists_congr
  intro a
  apply exists_congr
  intro b
  unfold FreeFits
  apply and_congr_right
  intro _
  apply and_congr_right
  intro _
  apply forall_congr'
  intro j
  rw [observe_affine O B T a b j]

/-- Instantiate the finite post-event observation with exactly the rotated
powers and phase rows of the checked periodic discrepancy criterion. -/
theorem signature_is_observation {n t L : ℕ} (B : Mat n 1) (T : Mat t 1)
    (A : ℕ → Mat (n+5+t) (n+5+t)) (C : ℕ → Mat 1 (n+5+t)) (s : ℕ)
    (a b : ℝ) (j : Fin (n+5+t)) (k : Fin L) :
    (signature A C s (post B T a b) j k) 0 0 =
    observe (fun (q : Fin (n+5+t) × Fin L) =>
      C (s+1+q.2) * trans A (s+1) q.2 * (trans A (s+1) L)^q.1.val)
      B T a b (j,k) := rfl

def observationRows {n t L : ℕ} (S : Loop (n+5)) (T : Loop t) (s : ℕ)
    (q : Fin (n+5+t) × Fin L) : Mat 1 (n+5+t) :=
  let A := fun k => pairDynamics (S.A k) (T.A k)
  let C := fun k => differenceReadout (S.C k) (T.C k)
  C (s+1+q.2) * trans A (s+1) q.2 * (trans A (s+1) L)^q.1.val

/-- The physical PID, prescribed target and matched initial conditions give a
complete test on the three observed impulse columns. Clocks, corrections, and
the target's state, readout and injection matrices repeat with the frame.
No future nonlinear trajectory or nominal PID reset response is assumed. -/
theorem physical_projected_iff_columns {n t L : ℕ} (hL : 0 < L)
    (p : Plant ℝ n) (g : GainGraph.Coeff ℝ) (flags : ℕ → Flags)
    (i d r : ℕ → ℝ) (T : Loop t) (x : Mat (n+5) 1) (y : Mat t 1)
    (h0 : ∀ k, (physicalLoop p g flags i d r).freeRaw x 0 k = T.freeRaw y 0 k)
    (hf : ∀ k, flags (k+L)=flags k) (hi : ∀ k, i (k+L)=i k) (hd : ∀ k, d (k+L)=d k)
    (hA : ∀ k, T.A (k+L)=T.A k) (hC : ∀ k, T.C (k+L)=T.C k)
    (hE : ∀ k, T.E (k+L)=T.E k) :
    let S := physicalLoop p g flags i d r
    (∀ (lo hi : ℕ → ℝ), (∀ k, lo k ≤ hi k) →
      let act := fun k => Conditioned.clip (lo k) (hi k)
      ∀ k, S.closedRaw x act k = T.closedRaw y act k ∧
        act k (S.closedRaw x act k) = act k (T.closedRaw y act k)) ↔
    ∀ (s : Fin L) (q : Fin (n+5+t) × Fin L),
      let O := observationRows S T s
      observe O p.B (T.E s) 0 0 q + i s * observe O 0 0 1 0 q +
        d s * observe O 0 0 0 1 q = 0 := by
  let S := physicalLoop p g flags i d r
  apply (projected_iff_phase_signatures hL S T x y h0
    (fun k => by simp [S,physicalLoop,hf,hA])
    (fun k => by simp [S,physicalLoop,hf,hC])
    (fun k => by simp [S,physicalLoop,hi,hd,hE])).trans
  have obs (s : Fin L) (j : Fin (n+5+t)) (k : Fin L) :
      (signature (fun h => pairDynamics (S.A h) (T.A h))
        (fun h => differenceReadout (S.C h) (T.C h)) s (pairStack (S.E s) (T.E s)) j k) 0 0 =
      observe (observationRows S T s) p.B (T.E s) 0 0 (j,k) +
        i s * observe (observationRows S T s) 0 0 1 0 (j,k) +
        d s * observe (observationRows S T s) 0 0 0 1 (j,k) :=
    observe_affine (observationRows S T s) p.B (T.E s) (i s) (d s) (j,k)
  constructor
  · rintro h s ⟨j,k⟩
    dsimp only
    rw [← obs s j k, h s j k]
    rfl
  · intro h s j k
    ext a b
    obtain rfl : a=0 := Subsingleton.elim _ _
    obtain rfl : b=0 := Subsingleton.elim _ _
    exact (obs s j k).trans (h s (j,k))

end
end MPCPID.PhaseColumns
