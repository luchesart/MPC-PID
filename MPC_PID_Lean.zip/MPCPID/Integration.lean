import MPCPID.Matching
import MPCPID.Predictive
import MPCPID.Conditioned

/-! Compositions between the coefficient construction, the physical PID memories
and scalar constrained predictive control. -/
namespace MPCPID.Integration
open Conditioned
noncomputable section

/-- The coefficient equality returned by Theorem 3.1 / 4.2 implies exactly the
two time-domain numerator identities required by the physical implementation. -/
theorem numerator_taps {α a f ζ η K κ d g b c : ℝ}
    (hfit : Matching.channels α (Matching.realization K κ d g b c) =
      Matching.target α a f ζ η) (r y : Signal) (j : ℕ) :
    tap (K*b+κ*g+d*c) (-(1+α)*K*b+κ*(1-g)-α*(κ*g)-2*d*c)
      (α*K*b-α*(κ*(1-g))+d*c) r j = η*r j ∧
    tap (K+κ*g+d) (-(1+α)*K+κ*(1-g)-α*(κ*g)-2*d)
      (α*K-α*(κ*(1-g))+d) y j = (f+ζ)*y j-a*ζ*lag y j := by
  have r₀ := congrArg (fun v : Matching.Channels => v.r.c0) hfit
  have r₁ := congrArg (fun v : Matching.Channels => v.r.c1) hfit
  have r₂ := congrArg (fun v : Matching.Channels => v.r.c2) hfit
  have y₀ := congrArg (fun v : Matching.Channels => v.y.c0) hfit
  have y₁ := congrArg (fun v : Matching.Channels => v.y.c1) hfit
  have y₂ := congrArg (fun v : Matching.Channels => v.y.c2) hfit
  dsimp [Matching.channels, Matching.realization, Matching.target] at r₀ r₁ r₂ y₀ y₁ y₂
  unfold tap
  constructor
  · linear_combination r j*r₀ + lag r j*r₁ + lag (lag r) j*r₂
  · linear_combination y j*y₀ + lag y j*y₁ + lag (lag y) j*y₂

/-- Exact raw and applied moves derive from the actual branch updates and the
fitted coefficient equality. No matching of the output trajectory is assumed.
The bounds may be values measured along an evolving nonlinear actuator rule. -/
theorem physical_projected_mpc {a b₀ b₁ η f t ζ α K κ d g b c : ℝ}
    (ha : α ≠ 1) (hpole : α = -ζ*b₁) (ht : t+ζ*(b₀+b₁)=1)
    (hfit : Matching.channels α (Matching.realization K κ d g b c) =
      Matching.target α a f ζ η)
    (r y u raw i df δ L H : Signal)
    (hplant : ∀ k, y k = a*lag y k+b₀*lag u k+b₁*lag (lag u) k)
    (hu : ∀ k, u k = K*(b*r k-y k)+i k+df k)
    (hi : ∀ k, i k = lag i k + κ*g*(r k-y k) + κ*(1-g)*(lag r k-lag y k)
        + δ k/(1-α))
    (hd : ∀ k, df k = α*lag df k + d*(c*r k-y k-c*lag r k+lag y k)
        - α*δ k/(1-α))
    (hδ : ∀ k, δ k = u k-raw k)
    (act : ∀ k, u k = clip (L k) (H k) (raw k)) :
    (∀ k, raw k = η*r k-f*y k+t*lag u k) ∧
    ∀ k, u k = clip (L k) (H k) (η*r k-f*y k+t*lag u k) := by
  have tap₁ := fun k => (numerator_taps hfit r y k).1
  have tap₂ := fun k => (numerator_taps hfit r y k).2
  have hden := corrected_physical_den α K b c (κ*g) (κ*(1-g)) d η f ζ a ha
    r y u i df δ hu hi hd tap₁ tap₂
  have hraw := raw_of_forced_den a b₀ b₁ η f t ζ α hpole ht r y u raw δ hplant hden hδ
  exact ⟨hraw, projected_eq _ _ _ _ _ hraw act⟩

/-- With no actuator intervention the same fitted coefficients yield the
prescribed nominal command, directly from the physical branch recurrences. -/
theorem nominal_physical_mpc {a b₀ b₁ η f t ζ α K κ d g b c : ℝ}
    (ha : α ≠ 1) (hpole : α = -ζ*b₁) (ht : t+ζ*(b₀+b₁)=1)
    (hfit : Matching.channels α (Matching.realization K κ d g b c) =
      Matching.target α a f ζ η)
    (r y u i df : Signal)
    (hplant : ∀ k, y k = a*lag y k+b₀*lag u k+b₁*lag (lag u) k)
    (hu : ∀ k, u k = K*(b*r k-y k)+i k+df k)
    (hi : ∀ k, i k = lag i k + κ*g*(r k-y k) + κ*(1-g)*(lag r k-lag y k))
    (hd : ∀ k, df k = α*lag df k + d*(c*r k-y k-c*lag r k+lag y k)) :
    ∀ k, u k = η*r k-f*y k+t*lag u k := by
  have hc := corrected_physical_den α K b c (κ*g) (κ*(1-g)) d η f ζ a ha
    r y u i df (fun _ => 0) hu (by simpa using hi) (by simpa using hd)
    (fun k => (numerator_taps hfit r y k).1) (fun k => (numerator_taps hfit r y k).2)
  apply raw_of_forced_den a b₀ b₁ η f t ζ α hpole ht r y u u (fun _ => 0) hplant hc
  simp

/-- The viable projection has exactly the correct state-horizon feasible set,
and strictly improves on every other viable first move. -/
theorem unique_viable_minimizer (m : Box) {y v l s q : ℝ} (hs : m.safe y v)
    (hl : 0 < l) (u : ℝ) (hnext : m.safe (m.next y v u) u)
    (hne : u ≠ clip 0 (m.upper y v) (Predictive.minimizer m.b₀ l s q)) :
    Predictive.objective m.b₀ l s q
      (clip 0 (m.upper y v) (Predictive.minimizer m.b₀ l s q)) <
      Predictive.objective m.b₀ l s q u := by
  have h0 := ((m.admissible_iff y v 0 hs).mp (m.zero_successor y v hs)).2
  have hfeas := (m.admissible_iff _ _ _ hs).mp hnext
  exact Predictive.projected_unique _ _ _ _ _ _ _ hl h0 hfeas.1 hfeas.2 hne

end
end MPCPID.Integration
