import MPCPID.Periodic
import Mathlib.Tactic.FinCases

/-! The physical parameter domain and the rational-to-polynomial graph
for a fixed pair of integral and filtered-derivative update periods. -/
namespace MPCPID.GainGraph
noncomputable section

structure Physical where
  K : ℝ
  Ti : ℝ
  Td : ℝ
  Tf : ℝ
  γI : ℝ
  γD : ℝ
  b : ℝ
  c : ℝ

def Admissible (p : Physical) :=
  0 < p.K ∧ 0 < p.Ti ∧ 0 < p.Td ∧ 0 < p.Tf ∧
    p.γI ∈ Set.Icc 0 1 ∧ p.γD ∈ Set.Icc 0 1 ∧
    p.b ∈ Set.Icc 0 1 ∧ p.c ∈ Set.Icc 0 1

@[ext] structure Coeff (R : Type*) where
  K : R
  i0 : R
  i1 : R
  α : R
  β : R
  b : R
  c : R

def Coeff.map {R S : Type*} [Semiring R] [Semiring S] (e : R →+* S) (g : Coeff R) : Coeff S :=
  ⟨e g.K, e g.i0, e g.i1, e g.α, e g.β, e g.b, e g.c⟩

def rational (TI TD : ℝ) (p : Physical) : Coeff ℝ :=
  ⟨p.K, p.K*TI/p.Ti*p.γI, p.K*TI/p.Ti*(1-p.γI),
    1-TD/(p.Tf+p.γD*TD), p.K*p.Td/(p.Tf+p.γD*TD), p.b, p.c⟩

abbrev Poly := MvPolynomial (Fin 18) ℝ

private def X (i : Fin 18) : Poly := MvPolynomial.X i
private def C (r : ℝ) : Poly := MvPolynomial.C r

/-- Coordinates 0–7 store the physical parameters; 8–9 store the two
reciprocals. Coordinates 10–17 witness both bounds on each gain weight. -/
def symbolic (TI TD : ℝ) : Coeff Poly :=
  ⟨X 0,X 0*C TI*X 8*X 4,X 0*C TI*X 8*(1-X 4),1-C TD*X 9,X 0*X 2*X 9,X 6,X 7⟩

def pos : Fin 4 → Poly := ![X 0,X 1,X 2,X 3]

def eqs (TD : ℝ) : Fin 10 → Poly :=
  ![X 1*X 8-1, (X 3+X 5*C TD)*X 9-1,
    X 4-X 10^2,1-X 4-X 11^2,X 5-X 12^2,1-X 5-X 13^2,
    X 6-X 14^2,1-X 6-X 15^2,X 7-X 16^2,1-X 7-X 17^2]

def decode (x : Fin 18 → ℝ) : Physical :=
  ⟨x 0,x 1,x 2,x 3,x 4,x 5,x 6,x 7⟩

private def encode (TD : ℝ) (p : Physical) : Fin 18 → ℝ :=
  ![p.K,p.Ti,p.Td,p.Tf,p.γI,p.γD,p.b,p.c,p.Ti⁻¹,(p.Tf+p.γD*TD)⁻¹,
    Real.sqrt p.γI,Real.sqrt (1-p.γI),Real.sqrt p.γD,Real.sqrt (1-p.γD),
    Real.sqrt p.b,Real.sqrt (1-p.b),Real.sqrt p.c,Real.sqrt (1-p.c)]

private theorem equations_iff (TD : ℝ) (x : Fin 18 → ℝ) :
    (∀ i, MvPolynomial.eval x (eqs TD i) = 0) ↔
    x 1*x 8 = 1 ∧ (x 3+x 5*TD)*x 9 = 1 ∧
    x 4 = (x 10)^2 ∧ 1-x 4 = (x 11)^2 ∧ x 5 = (x 12)^2 ∧ 1-x 5 = (x 13)^2 ∧
    x 6 = (x 14)^2 ∧ 1-x 6 = (x 15)^2 ∧ x 7 = (x 16)^2 ∧ 1-x 7 = (x 17)^2 := by
  simp [eqs, X, C, Fin.forall_fin_succ, sub_eq_zero]

private theorem positive_iff (x : Fin 18 → ℝ) :
    (∀ i, 0 < MvPolynomial.eval x (pos i)) ↔
      0 < x 0 ∧ 0 < x 1 ∧ 0 < x 2 ∧ 0 < x 3 := by
  simp [pos, X, Fin.forall_fin_succ]

private theorem encode_graph (TI TD : ℝ) (hTD : 0 ≤ TD) (p : Physical) (h : Admissible p) :
    let x := encode TD p
    (∀ i, MvPolynomial.eval x (eqs TD i)=0) ∧ (∀ i, 0 < MvPolynomial.eval x (pos i)) ∧
    Coeff.map (MvPolynomial.eval x) (symbolic TI TD) = rational TI TD p := by
  rcases h with ⟨hK,hTi,hTd,hTf,hI,hD,hb,hc⟩
  have hden : 0 < p.Tf+p.γD*TD := add_pos_of_pos_of_nonneg hTf (mul_nonneg hD.1 hTD)
  dsimp only
  refine ⟨(equations_iff _ _).2 ?_,(positive_iff _).2 ?_,?_⟩
  · simp [encode, hTi.ne', hden.ne', Real.sq_sqrt hI.1, Real.sq_sqrt (sub_nonneg.mpr hI.2),
      Real.sq_sqrt hD.1, Real.sq_sqrt (sub_nonneg.mpr hD.2),
      Real.sq_sqrt hb.1, Real.sq_sqrt (sub_nonneg.mpr hb.2),
      Real.sq_sqrt hc.1, Real.sq_sqrt (sub_nonneg.mpr hc.2)]
  · exact ⟨hK,hTi,hTd,hTf⟩
  · ext <;> simp [Coeff.map,symbolic,rational,encode,X,C,div_eq_mul_inv]

private theorem decode_graph (TI TD : ℝ) (x : Fin 18 → ℝ)
    (he : ∀ i, MvPolynomial.eval x (eqs TD i)=0)
    (hi : ∀ i, 0 < MvPolynomial.eval x (pos i)) :
    Admissible (decode x) ∧ Coeff.map (MvPolynomial.eval x) (symbolic TI TD) =
      rational TI TD (decode x) := by
  rcases (equations_iff _ _).1 he with ⟨qi,qd,l₀,h₀,l₁,h₁,l₂,h₂,l₃,h₃⟩
  obtain ⟨kp,ti,td,tf⟩ := (positive_iff _).1 hi
  have bound {v low high : ℝ} (hl : v=low^2) (hh : 1-v=high^2) : v ∈ Set.Icc 0 1 :=
    ⟨hl ▸ sq_nonneg _,by linarith only [hh,sq_nonneg high]⟩
  have invI : x 8 = (x 1)⁻¹ := by
    field_simp [ti.ne']
    linarith [mul_comm (x 8) (x 1)]
  have nonD : x 3+x 5*TD ≠ 0 := by
    intro hz
    rw [hz,zero_mul] at qd
    exact zero_ne_one qd
  have invD : x 9 = (x 3+x 5*TD)⁻¹ := by
    field_simp [nonD]
    linarith [mul_comm (x 9) (x 3+x 5*TD)]
  refine ⟨⟨kp,ti,td,tf,bound l₀ h₀,bound l₁ h₁,bound l₂ h₂,bound l₃ h₃⟩,?_⟩
  ext <;> simp [Coeff.map,symbolic,rational,decode,X,C,div_eq_mul_inv,invI,invD]

/-- A polynomial feasibility problem with 18 unknowns, ten equalities and
four strict inequalities, exactly equivalent to quantification over the
eight admissible physical gains for any test of the seven branch coefficients. -/
theorem gain_feasibility (TI TD : ℝ) (hTD : 0 ≤ TD) (P : Coeff ℝ → Prop) :
    (∃ g : Physical, Admissible g ∧ P (rational TI TD g)) ↔
    (∃ x : Fin 18 → ℝ, (∀ i, MvPolynomial.eval x (eqs TD i)=0) ∧
      (∀ i, 0 < MvPolynomial.eval x (pos i)) ∧
      P (Coeff.map (MvPolynomial.eval x) (symbolic TI TD))) := by
  constructor
  · rintro ⟨g,hg,hP⟩
    obtain ⟨he,hi,hc⟩ := encode_graph TI TD hTD g hg
    exact ⟨encode TD g,he,hi,hc.symm ▸ hP⟩
  · rintro ⟨x,he,hi,hP⟩
    obtain ⟨hg,hc⟩ := decode_graph TI TD x he hi
    exact ⟨decode x,hg,hc ▸ hP⟩

end
end MPCPID.GainGraph
