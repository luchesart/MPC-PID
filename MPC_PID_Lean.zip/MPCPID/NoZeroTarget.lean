import MPCPID.PhysicalSchedule
import MPCPID.OperatorPhase

/-! A positive integrating PID with Schur-stable closed-loop monodromy
cannot have an identically zero unit-step output. -/
namespace MPCPID.NoZeroTarget
open PhysicalLift PhysicalSchedule Periodic
noncomputable section

/-- The corrected integral storage cancels the previously sampled error. -/
def storage {n : ℕ} (b : ℝ) : Mat (n+5) 1 →ₗ[ℝ] ℝ where
  toFun x := x (finSumFinEquiv (Sum.inr (1 : Fin 5))) 0 +
    b * x (finSumFinEquiv (Sum.inr (3 : Fin 5))) 0
  map_add' := by intro x y; simp [Matrix.add_apply]; ring
  map_smul' := by intro c x; simp [Matrix.smul_apply]; ring

theorem storage_rows {n : ℕ} (b : ℝ) (x : Mat n 1) (ξ : Fin 5 → ℝ) :
    storage b (rows x (column ξ)) = ξ 1 + b * ξ 3 := by
  simp [storage,rows,column,Matrix.submatrix_apply]

private theorem first_rows (x y : Mat 1 1) : rows x y 0 0 = x 0 0 := by rfl

private theorem splits {n : ℕ} (X : Mat (n+5) 1) :
    ∃ (x : Mat n 1) (ξ : Fin 5 → ℝ), rows x (column ξ) = X := by
  let x : Mat n 1 := fun i j => X (finSumFinEquiv (Sum.inl i)) j
  let ξ : Fin 5 → ℝ := fun i => X (finSumFinEquiv (Sum.inr i)) 0
  refine ⟨x,ξ,?_⟩
  ext i j
  obtain ⟨v, rfl⟩ := finSumFinEquiv.surjective i
  fin_cases j
  cases v <;> simp [x,ξ,rows,column,Matrix.submatrix_apply]

theorem phase_balance {n : ℕ} (p : Plant ℝ n) (g : GainGraph.Coeff ℝ)
    (f : Flags) (X : Mat (n+5) 1) :
    let ph := physicalPhase p g f
    let Y := (ph.C*X+ph.D*scalar (1 : ℝ)) 0 0
    storage g.i1 (ph.A*X+ph.B*scalar (1 : ℝ)) - storage g.i1 X =
      (if f.i then g.i0+g.i1 else 0)*(1-Y) := by
  obtain ⟨x,ξ,rfl⟩ := splits X
  let y := (p.C*x) 0 0
  have hy : scalar y = p.C*x := by ext i j; fin_cases i; fin_cases j; rfl
  have hb := nextBranches g f ξ 1 y
  rw [hy] at hb
  have hp := physicalPhase_action p g f x (column ξ) (scalar (1 : ℝ))
  dsimp only at hp ⊢
  rw [← hb] at hp
  rw [hp.1,hp.2,first_rows,storage_rows,storage_rows]
  change _ = _ * (1-y)
  obtain ⟨fp,fi,fd⟩ := f
  cases fi
  · simp [drivenBranches,bit,Matrix.cons_val_three]
  · simp [drivenBranches,bit,Matrix.cons_val_three]
    ring

def ones (L : ℕ) : Mat L 1 := fun _ _ => 1

private theorem unit_selector {L : ℕ} (k : Fin L) : (selector₁ L k : Mat 1 L) * ones L = scalar (1 : ℝ) := by
  ext i j
  rw [Matrix.mul_apply, Finset.sum_eq_single k]
  · simp [selector₁,ones,scalar]
  · intro a _ h
    simp [selector₁,show a.val ≠ k.val from fun e => h (Fin.ext e)]
  · simp

def number (s : ℕ → Flags) (k : ℕ) : ℝ :=
  ∑ j ∈ Finset.range k, (if (s j).i then (1 : ℝ) else 0)

theorem number_pos {L : ℕ} (s : Clocks L) : 0 < number s.flags L := by
  have hp : s.φI < L := s.phaseI.trans_le (Nat.le_of_dvd s.frame_pos s.i_dvd)
  have hflag : (s.flags s.φI).i = true := by
    simp [Clocks.flags,Nat.mod_eq_of_lt s.phaseI]
  apply Finset.sum_pos' (fun _ _ => by split <;> norm_num)
  exact ⟨s.φI, Finset.mem_range.mpr hp, by simp [hflag]⟩

/-- On a frame with zero output and unit reference, its positive integral
increment is independent of all initial registers and plant states. -/
theorem frame_balance {n L : ℕ} (p : Plant ℝ n) (g : GainGraph.Coeff ℝ)
    (s : ℕ → Flags) (X : Mat (n+5) 1) :
    let F := physicalFrame p g s L
    (∀ k : Fin L, (F.C*X + F.D*ones L) (finProdFinEquiv (k,0)) 0 = 0) →
    storage g.i1 (F.A*X+F.B*ones L)-storage g.i1 X = (g.i0+g.i1)*number s L := by
  let t := fun k => physicalPhase p g (s k)
  let x := frameState (fun k => (t k).A) (fun k => (t k).B)
    (fun k => selector₁ L k * ones L) X
  dsimp only
  intro ho
  have partialSum (k : ℕ) (hk : k ≤ L) :
      storage g.i1 (x k)-storage g.i1 X=(g.i0+g.i1)*number s k := by
    induction k with
    | zero => simp [x,frameState,number]
    | succ k ih =>
      have hk' : k<L := by omega
      have hu := unit_selector (⟨k,hk'⟩ : Fin L)
      have hs : x (k+1)=(t k).A*x k+(t k).B*scalar (1 : ℝ) := by
        change _ + _*(selector₁ L k * ones L) = _
        rw [hu]
      have hy := frameWith_output t (selector₁ L) L X (ones L) (⟨k,hk'⟩ : Fin L)
      have eq := congrArg (fun m : Mat 2 1 => m 0 0) hy
      change _ = ((t k).C*x k + (t k).D*((selector₁ L k : Mat 1 L)*ones L)) 0 0 at eq
      rw [hu] at eq
      have hzero := (ho (⟨k,hk'⟩ : Fin L))
      have hY : ((t k).C*x k+(t k).D*scalar (1 : ℝ)) 0 0 = 0 := eq.symm.trans hzero
      have hh := phase_balance p g (s k) (x k)
      change storage _ ((t k).A*x k+(t k).B*scalar (1 : ℝ))- _ =
        _*(1-((t k).C*x k+(t k).D*scalar (1 : ℝ)) 0 0) at hh
      rw [hY] at hh
      rw [hs]
      have ih' := ih hk'.le
      unfold number
      rw [Finset.sum_range_succ]
      unfold number at ih'
      cases hfi : (s k).i <;> simp [hfi] at hh ih' ⊢ <;> linarith
  have last := partialSum L le_rfl
  have hf := frameWith_state t (selector₁ L) L X (ones L)
  change x L = _ at hf
  rw [hf] at last
  exact last

/-- Applying Cayley--Hamilton to a constant nonzero observation of the
homogeneous orbit forces a unit characteristic root. -/
theorem constant_observation {n : ℕ} (A : Mat n n) (Z : Mat n 1)
    (f : Mat n 1 →ₗ[ℝ] ℝ) {c : ℝ} (hc : c ≠ 0)
    (h : ∀ j : ℕ, f (A^j*Z) = c) : ¬ ScheduleCertificate.Stable A := by
  classical
  have hA := A.aeval_self_charpoly
  rw [Polynomial.aeval_eq_sum_range' (Nat.lt_succ_self _) A] at hA
  have hsum := congrArg (fun U : Mat n n => f (U*Z)) hA
  simp only [Matrix.sum_mul, Matrix.smul_mul, map_sum, map_smul, smul_eq_mul, h,
    Matrix.zero_mul,map_zero] at hsum
  rw [← Finset.sum_mul] at hsum
  have hr : A.charpoly.IsRoot 1 := by
    unfold Polynomial.IsRoot
    rw [Polynomial.eval_eq_sum_range]
    simpa using (mul_eq_zero.mp hsum).resolve_right hc
  have hcroot := hr.map (f:=Complex.ofRealHom)
  rw [← Matrix.charpoly_map] at hcroot
  intro stable
  simpa using stable _ hcroot

/-- The unit-step experiment at block boundaries. -/
def blocksAt {n m o : ℕ} (F : System ℝ n m o) (w : Mat m 1) : ℕ → Mat n 1
  | 0 => 0
  | k+1 => F.A*blocksAt F w k + F.B*w

theorem step_output_nonzero {n L : ℕ} (p : Plant ℝ n)
    (g : GainGraph.Coeff ℝ) (hg : 0 < g.i0+g.i1) (s : Clocks L)
    (stable : ScheduleCertificate.Stable (physicalFrame p g s.flags L).A) :
    let F := physicalFrame p g s.flags L
    ∃ (q : ℕ) (k : Fin L),
      (F.C*blocksAt F (ones L) q + F.D*ones L) (finProdFinEquiv (k,0)) 0 ≠ 0 := by
  let F := physicalFrame p g s.flags L
  let x := blocksAt F (ones L)
  let z := fun q => x (q+1)-x q
  dsimp only
  by_contra hn
  push_neg at hn
  have evo (q : ℕ) : z (q+1) = F.A * z q := by
    change (F.A*x (q+1)+F.B*ones L)-(F.A*x q+F.B*ones L)=F.A*(x (q+1)-x q)
    rw [Matrix.mul_sub]
    abel
  have hz (q : ℕ) : F.A^q*z 0=z q := by
    induction q with
    | zero => simp
    | succ q ih => rw [pow_succ',Matrix.mul_assoc,ih,evo]
  have hobs (q : ℕ) : storage g.i1 (F.A^q*z 0)=(g.i0+g.i1)*number s.flags L := by
    rw [hz]
    change storage _ (x (q+1)-x q) = _
    rw [map_sub]
    exact frame_balance p g s.flags (x q) (hn q)
  exact constant_observation _ _ _ (mul_pos hg (number_pos s)).ne' hobs stable

theorem physical_step_output_nonzero {n L : ℕ} (p : Plant ℝ n)
    (g : GainGraph.Physical) (adm : GainGraph.Admissible g) (s : Clocks L)
    {h : ℝ} (hh : 0<h)
    (stable : ScheduleCertificate.Stable
      (physicalFrame p (GainGraph.rational (s.TI h) (s.TD h) g) s.flags L).A) :
    let F := physicalFrame p (GainGraph.rational (s.TI h) (s.TD h) g) s.flags L
    ∃ (q : ℕ) (k : Fin L),
      (F.C*blocksAt F (ones L) q + F.D*ones L) (finProdFinEquiv (k,0)) 0 ≠ 0 := by
  apply step_output_nonzero _ _ _ _ stable
  change 0 < g.K*s.TI h/g.Ti*g.γI + g.K*s.TI h/g.Ti*(1-g.γI)
  rw [← mul_add]
  have hpos : 0 < s.TI h := mul_pos (by exact_mod_cast Nat.zero_lt_of_lt s.phaseI) hh
  simpa using div_pos (mul_pos adm.1 hpos) adm.2.1

theorem blocksAt_advance {n m o : ℕ} (F : System ℝ n m o) (w : Mat m 1) (q : ℕ) :
    blocksAt F w q = advance F.A F.B 0 (List.replicate q w) := by
  induction q with
  | zero => rfl
  | succ q ih => rw [blocksAt,List.replicate_succ,advance,ih]

/-- Full nominal zero-state matching passes this witness to the target. -/
theorem matched_step_output_nonzero {n L t : ℕ} (p : Plant ℝ n)
    (g : GainGraph.Physical) (adm : GainGraph.Admissible g) (s : Clocks L)
    {h : ℝ} (hh : 0<h) (T : System ℝ t L (L*2)) :
    let F := physicalFrame p (GainGraph.rational (s.TI h) (s.TD h) g) s.flags L
    ScheduleCertificate.Stable F.A → MatchSys F T →
    ∃ (q : ℕ) (k : Fin L),
      (T.C*blocksAt T (ones L) q + T.D*ones L) (finProdFinEquiv (k,0)) 0 ≠ 0 := by
  dsimp only
  intro stable hm
  obtain ⟨q,k,hk⟩ := physical_step_output_nonzero p g adm s hh stable
  have eq := hm (ones L) (List.replicate q (ones L))
  rw [←blocksAt_advance,←blocksAt_advance] at eq
  exact ⟨q,k,by rwa [←eq]⟩

end
end MPCPID.NoZeroTarget
