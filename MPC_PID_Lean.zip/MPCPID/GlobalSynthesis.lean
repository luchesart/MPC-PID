import MPCPID.NominalBound
import MPCPID.NominalLiftBridge
import MPCPID.ClockCatalogue

/-! Exact search over *all* integer periods for a nonzero nominal LTI output
response. Both the all-sample match and the whole gain interval are tested. -/
namespace MPCPID.GlobalSynthesis
open PhysicalLift GainGraph GainReserve NominalLiftBridge NominalExecution ClockCatalogue
noncomputable section

/-- The first-lag case admits the tighter four-period cutoff. -/
def Bound (d : ℕ) := if d=1 then 4 else 2*(max d 3)^2

def PhysicalDesign {n t : ℕ} (P : Plant ℝ n) (X : System ℝ t 1 2) (h R : ℝ)
    (s : Pattern) (p : Physical) :=
  PhysicalAt P h R (clocks s) (targetLift X (frameLength s)) p

def Test {n t : ℕ} (P : Plant ℝ n) (X : System ℝ t 1 2) (h R : ℝ) (s : Pattern) :=
  PolynomialFeasible P h R (clocks s) (targetLift X (frameLength s))

theorem fixed_test {n t : ℕ} (P : Plant ℝ n) (X : System ℝ t 1 2) {h R : ℝ}
    (hh : 0<h) (hR : 1≤R) (s : Pattern) :
    (∃ p, PhysicalDesign P X h R s p) ↔ Test P X h R s :=
  reserve_feasibility P hh hR (clocks s) (targetLift X (frameLength s))

/-- Every actual feasible design occurs in the explicit finite catalogue.
The first output is necessarily zero on the strictly proper physical plant.
A single later nonzero target output coefficient suffices. -/
theorem design_cutoff {n t d : ℕ} (P : Plant ℝ n) (X : System ℝ t 1 2) {h R : ℝ}
    (hh : 0<h) (hd : 0<d) (hy : impulseOutput X d 0 0 ≠ 0)
    (s : Pattern) (p : Physical) (ok : PhysicalDesign P X h R s p) :
    ∀ j, period s j ≤ Bound d := by
  obtain ⟨ad,mat,_⟩ := ok
  let g := rational ((clocks s).TI h) ((clocks s).TD h) p
  have hm := matches_impulse (clocks s) P g X mat
  have hzero := (hm 0 0).1.symm
  have hy0 : impulseOutput X 0 0 0=0 := by simpa [closedRun,NominalExecution.measure] using hzero
  have bd : ∀ j, NominalBound.periods (clocks s) j ≤ Bound d := by
    by_cases one : d=1
    · subst d
      simp only [Bound,if_pos rfl]
      exact NominalBound.physical_first_sample_bound (clocks s) p h hh ad
        (fun k => impulseOutput X k 0 0) (fun k => impulseOutput X k 1 0)
        hy0 hy (actual_impulses (clocks s) P g hm)
    · simp only [Bound,if_neg one]
      exact NominalBound.physical_period_bound (clocks s) p h hh ad
        (fun k => impulseOutput X k 0 0) (fun k => impulseOutput X k 1 0)
        hd hy0 hy (actual_impulses (clocks s) P g hm)
  intro j
  fin_cases j
  · exact bd 0
  · exact bd 1
  · exact bd 2

/-- All optimal schedules and all continuous parameters attaining the optimum,
without an a priori bound on any of the three positive integer periods. -/
theorem all_global_minimizers {n t d : ℕ} (P : Plant ℝ n) (X : System ℝ t 1 2)
    {h R : ℝ} (hh : 0<h) (hR : 1≤R) (hd : 0<d) (hy : impulseOutput X d 0 0 ≠ 0)
    (s : Pattern) (p : Physical) :
    UpdateOpt.Optimal clocks h (PhysicalDesign P X h R) s p ↔
    PhysicalDesign P X h R s p ∧
      ∀ c : Key (Bound d), UpdateOpt.cheaper (clocks (forget c)) (clocks s) →
        ¬ Test P X h R (forget c) :=
  rate_optimal_iff hh _ _ (fixed_test P X hh hR) (design_cutoff P X hh hd hy) s p

/-- An exact alternative: the bounded real-polynomial tests find at least one
feasible key iff a globally optimal physical realization exists over all periods. -/
theorem global_search {n t d : ℕ} (P : Plant ℝ n) (X : System ℝ t 1 2)
    {h R : ℝ} (hh : 0<h) (hR : 1≤R) (hd : 0<d) (hy : impulseOutput X d 0 0 ≠ 0) :
    (∃ c : Key (Bound d), Test P X h R (forget c)) ↔
      ∃ s p, UpdateOpt.Optimal clocks h (PhysicalDesign P X h R) s p :=
  globally_attained_iff h _ _ (fixed_test P X hh hR) (design_cutoff P X hh hd hy)

end
end MPCPID.GlobalSynthesis
