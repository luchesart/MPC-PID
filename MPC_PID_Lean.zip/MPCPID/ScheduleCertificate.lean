import MPCPID.Periodic

/-! A zero-history comparison of two independently evolving lifted systems,
including the stability test for a separate physical closed-loop monodromy. -/
namespace MPCPID.ScheduleCertificate
open Periodic Matrix
noncomputable section

abbrev M (R : Type*) (n m : ℕ) := Matrix (Fin n) (Fin m) R
abbrev Poly (d : ℕ) := MvPolynomial (Fin d) ℝ

def Same {n t m o : ℕ} (A : Mat n n) (B : Mat n m) (C : Mat o n) (D : Mat o m)
    (T : Mat t t) (U : Mat t m) (V : Mat o t) (W : Mat o m) : Prop :=
  ∀ (v : Mat m 1) (hist : List (Mat m 1)),
    C * advance A B 0 hist + D*v = V * advance T U 0 hist + W*v

def Stable {a : ℕ} (Φ : Mat a a) : Prop :=
  ∀ z, (Φ.map Complex.ofRealHom).charpoly.IsRoot z → ‖z‖ < 1

private theorem pairPow_apply {n t m : ℕ}
    (A : Mat n n) (T : Mat t t) (B : Mat n m) (U : Mat t m) (k : ℕ) :
    (pairDynamics A T)^k * pairStack B U = pairStack (A^k * B) (T^k * U) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [pow_succ',Matrix.mul_assoc,ih,pow_succ',pow_succ',Matrix.mul_assoc,Matrix.mul_assoc]
    simp [pairDynamics,pairStack,Matrix.submatrix_mul_equiv,Matrix.fromBlocks_mul_fromRows]

theorem match_iff {n t m o : ℕ} (A : Mat n n) (B : Mat n m) (C : Mat o n) (D : Mat o m)
    (T : Mat t t) (U : Mat t m) (V : Mat o t) (W : Mat o m) :
    Same A B C D T U V W ↔ D=W ∧ ∀ j < n+t, C*A^j*B=V*T^j*U := by
  have step (j : ℕ) : differenceReadout C V * (pairDynamics A T)^j * pairStack B U =
      C*A^j*B - V*T^j*U := by
    rw [Matrix.mul_assoc,pairPow_apply]
    simp [differenceReadout,pairStack,Matrix.submatrix_mul_equiv,
      Matrix.fromCols_mul_fromRows,Matrix.neg_mul,sub_eq_add_neg,Matrix.mul_assoc]
  have zeroStack : pairStack (0 : Mat n 1) (0 : Mat t 1) = 0 := by
    funext i j
    change Matrix.fromRows (0 : Mat n 1) (0 : Mat t 1) (finSumFinEquiv.symm i) j = 0
    cases finSumFinEquiv.symm i <;> rfl
  have h := twoLiftEquality A T B U C V D W (0 : Mat n 1) (0 : Mat t 1)
  simpa [Same,step,zeroStack,sub_eq_zero] using h

/-- All scalar components on the right are evaluations of polynomials in
the finite real coordinate vectors x and u. The target blocks may be constant. -/
def AtPoint {d n t m o a : ℕ} (x : Fin d → ℝ)
    (A : M (Poly d) n n) (B : M (Poly d) n m) (C : M (Poly d) o n) (D : M (Poly d) o m)
    (T : M (Poly d) t t) (U : M (Poly d) t m) (V : M (Poly d) o t) (W : M (Poly d) o m)
    (Φ : M (Poly d) a a) : Prop :=
  let e := MvPolynomial.eval x
  (D.map e = W.map e) ∧
  (∀ j < n+t, (C*A^j*B).map e = (V*T^j*U).map e) ∧
  ∃ u : Fin a × Bool → ℝ,
    (∀ j ≤ a, e (Φ.charpoly.coeff j) =
      MvPolynomial.eval u (realImag ((rootPolynomial a).coeff j)).1 ∧
      0 = MvPolynomial.eval u (realImag ((rootPolynomial a).coeff j)).2) ∧
    ∀ i, (u (i,false))^2+(u (i,true))^2 < 1

theorem polynomial_match_stable {d n t m o a : ℕ} (x : Fin d → ℝ)
    (A : M (Poly d) n n) (B : M (Poly d) n m) (C : M (Poly d) o n) (D : M (Poly d) o m)
    (T : M (Poly d) t t) (U : M (Poly d) t m) (V : M (Poly d) o t) (W : M (Poly d) o m)
    (Φ : M (Poly d) a a) :
    let e := MvPolynomial.eval x
    (Same (A.map e) (B.map e) (C.map e) (D.map e) (T.map e) (U.map e) (V.map e) (W.map e)
      ∧ Stable (Φ.map e)) ↔ AtPoint x A B C D T U V W Φ := by
  dsimp only [AtPoint,Stable]
  rw [match_iff,and_assoc]
  have hφ := (polynomialSchur x Φ).trans
    (realRootWitness (fun j => MvPolynomial.eval x (Φ.charpoly.coeff j)))
  simp only [Matrix.map_map] at *
  simpa only [evaluateMarkov, RingHom.comp_apply] using
    (and_congr Iff.rfl (and_congr Iff.rfl hφ))
end
end MPCPID.ScheduleCertificate
