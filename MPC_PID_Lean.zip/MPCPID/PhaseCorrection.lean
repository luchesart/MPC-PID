import MPCPID.PhysicalLift
import MPCPID.Conditioned

/-! Periodic observability of a residual injected after evaluation of the raw command. -/
namespace MPCPID.PhaseCorrection
open Periodic PhysicalLift
noncomputable section

def trans {n : ℕ} (A : ℕ → Mat n n) (t : ℕ) : ℕ → Mat n n
  | 0 => 1
  | k+1 => A (t+k) * trans A t k

theorem trans_append {n : ℕ} (A : ℕ → Mat n n) (t a b : ℕ) :
    trans A t (a+b) = trans A (t+a) b * trans A t a := by
  induction b with
  | zero => simp [trans]
  | succ b ih =>
    change A (t+(a+b)) * trans A t (a+b) = (A ((t+a)+b) * trans A (t+a) b) * trans A t a
    rw [ih,Nat.add_assoc,Matrix.mul_assoc]

theorem period_shift {X : Type*} {a : ℕ → X} {L : ℕ}
    (h : ∀ k, a (k+L) = a k) (t q : ℕ) : a (t+q*L) = a t := by
  induction q with
  | zero => simp
  | succ q ih => rw [Nat.succ_mul,←Nat.add_assoc,h,ih]

theorem trans_shift {n L : ℕ} {A : ℕ → Mat n n}
    (h : ∀ k, A (k+L) = A k) (t q k : ℕ) :
    trans A (t+q*L) k = trans A t k := by
  induction k with
  | zero => rfl
  | succ k ih =>
    simp only [trans,ih,show t+q*L+k = (t+k)+q*L by omega,period_shift h]

theorem trans_frames {n L : ℕ} {A : ℕ → Mat n n}
    (h : ∀ k, A (k+L) = A k) (t q : ℕ) :
    trans A t (q*L) = (trans A t L)^q := by
  induction q with
  | zero => simp [trans]
  | succ q ih => rw [Nat.succ_mul,trans_append,trans_shift h,ih,pow_succ']

/-- Post-event signature over all phases and n powers of the rotated monodromy. -/
def signature {n o L : ℕ} (A : ℕ → Mat n n) (C : ℕ → Mat o n) (s : ℕ)
    (b : Mat n 1) (j : Fin n) (k : Fin L) : Mat o 1 :=
  C (s+1+k) * trans A (s+1) k * (trans A (s+1) L)^j.val * b

theorem signature_zero_iff {n o L : ℕ} (hL : 0 < L)
    {A : ℕ → Mat n n} {C : ℕ → Mat o n}
    (hA : ∀ k, A (k+L)=A k) (hC : ∀ k, C (k+L)=C k) (s : ℕ) (b : Mat n 1) :
    (∀ (j : Fin n) (k : Fin L), signature A C s b j k = 0) ↔
    ∀ l, C (s+1+l) * trans A (s+1) l * b = 0 := by
  have split (q k : ℕ) :
      C (s+1+(q*L+k)) * trans A (s+1) (q*L+k) * b =
        C (s+1+k) * trans A (s+1) k * (trans A (s+1) L)^q * b := by
    rw [show s+1+(q*L+k) = (s+1+k)+q*L by omega,period_shift hC,
      trans_append,trans_shift hA,trans_frames hA]
    simp only [Matrix.mul_assoc]
  constructor
  · intro h l
    let k : Fin L := ⟨l%L,Nat.mod_lt _ hL⟩
    have cut : l/L*L+k = l := by simpa [k,Nat.mul_comm,Nat.add_comm] using Nat.mod_add_div l L
    rw [←cut,split]
    exact finiteMarkov _ _ _ (fun j hj => h ⟨j,hj⟩ k) _
  · intro h j k
    exact (split j k).symm.trans (h _)

def response {n : ℕ} (A : ℕ → Mat n n) (b : ℕ → Mat n 1) (δ : ℕ → ℝ) :
    ℕ → Mat n 1
  | 0 => 0
  | k+1 => A k * response A b δ k + δ k • b k

private theorem propagate_response {n o : ℕ} (A : ℕ → Mat n n) (b : ℕ → Mat n 1)
    (C : ℕ → Mat o n) (δ : ℕ → ℝ)
    (hp : ∀ s k, C (s+1+k) * trans A (s+1) k * b s = 0) (s k : ℕ) :
    C (s+k) * trans A s k * response A b δ s = 0 := by
  induction s generalizing k with
  | zero => simp [response]
  | succ s ih =>
    have one : trans A s 1 = A s := by simp [trans]
    have link : trans A s (k+1) = trans A (s+1) k * A s := by
      rw [Nat.add_comm k 1,trans_append,one]
    change C (s+1+k) * trans A (s+1) k *
      (A s * response A b δ s + δ s • b s) = 0
    rw [Matrix.mul_add,Matrix.mul_smul,hp,smul_zero,add_zero,←Matrix.mul_assoc,
      Matrix.mul_assoc (C _) _ (A s),←link,show s+1+k=s+(k+1) by omega,ih]

private theorem step_impulse {n : ℕ} (A : ℕ → Mat n n) (b : ℕ → Mat n 1) (s k : ℕ) :
    response A b (fun j => if j=s then 1 else 0) (s+1+k) = trans A (s+1) k * b s := by
  have before (t : ℕ) (ht : t ≤ s) :
      response A b (fun j => if j=s then 1 else 0) t = 0 := by
    induction t with
    | zero => rfl
    | succ t ih => simp [response,ih (by omega),show t≠s by omega]
  induction k with
  | zero => simp [response,before s le_rfl,trans]
  | succ k ih =>
    rw [Nat.add_succ,response,ih,trans,Matrix.mul_assoc]
    simp [show s+1+k≠s by omega]

/-- Necessary and sufficient for zero raw discrepancy on arbitrary external
actuator defects, starting from phase zero. Each phase is tested separately. -/
theorem residual_finite_iff {n o L : ℕ} (hL : 0 < L)
    {A : ℕ → Mat n n} {C : ℕ → Mat o n} {b : ℕ → Mat n 1}
    (hA : ∀ k, A (k+L)=A k) (hC : ∀ k, C (k+L)=C k)
    (hb : ∀ k, b (k+L)=b k) :
    (∀ (s : Fin L) (j : Fin n) (k : Fin L), signature A C s (b s) j k = 0) ↔
    ∀ (δ : ℕ → ℝ) (k : ℕ), C k * response A b δ k = 0 := by
  constructor
  · intro hs δ k
    have all (s l : ℕ) : C (s+1+l) * trans A (s+1) l * b s = 0 := by
      let r : Fin L := ⟨s%L,Nat.mod_lt _ hL⟩
      have h := (signature_zero_iff hL hA hC r (b r)).1 (hs r) l
      have eqs : (r : ℕ) + s/L*L = s := by simpa [r,Nat.mul_comm] using Nat.mod_add_div s L
      rw [←eqs,show (r:ℕ)+s/L*L+1+l = ((r:ℕ)+1+l)+s/L*L by omega,
        show (r:ℕ)+s/L*L+1 = ((r:ℕ)+1)+s/L*L by omega,period_shift hC,
        trans_shift hA,period_shift hb]
      exact h
    simpa [trans] using propagate_response A b C δ all k 0
  · intro h s
    apply (signature_zero_iff hL hA hC s (b s)).2
    intro l
    have hp := h (fun j => if j=s.val then 1 else 0) (s.val+1+l)
    rw [step_impulse] at hp
    simpa [Matrix.mul_assoc] using hp


/-- A linear loop with an additional actuator-residual input. The raw
command is evaluated before the same-sample residual is applied. -/
structure Loop (n : ℕ) where
  A : ℕ → Mat n n
  C : ℕ → Mat 1 n
  E : ℕ → Mat n 1
  drive : ℕ → Mat n 1
  direct : ℕ → ℝ

def Loop.rawAt {n : ℕ} (S : Loop n) (k : ℕ) (x : Mat n 1) : ℝ :=
  (S.C k * x) 0 0 + S.direct k

def Loop.free {n : ℕ} (S : Loop n) (x : Mat n 1) (δ : ℕ → ℝ) : ℕ → Mat n 1
  | 0 => x
  | k+1 => S.A k * S.free x δ k + S.drive k + δ k • S.E k

def Loop.freeRaw {n : ℕ} (S : Loop n) (x : Mat n 1) (δ : ℕ → ℝ) (k : ℕ) :=
  S.rawAt k (S.free x δ k)

theorem Loop.superposition {n : ℕ} (S : Loop n) (x : Mat n 1) (δ : ℕ → ℝ) (k : ℕ) :
    S.free x δ k = S.free x 0 k + response S.A S.E δ k := by
  induction k with
  | zero => simp [free,response]
  | succ k ih =>
    simp only [free,response,ih,Pi.zero_apply,zero_smul,add_zero,Matrix.mul_add]
    abel

theorem Loop.raw_superposition {n : ℕ} (S : Loop n) (x : Mat n 1) (δ : ℕ → ℝ) (k : ℕ) :
    S.freeRaw x δ k = S.freeRaw x 0 k + (S.C k * response S.A S.E δ k) 0 0 := by
  unfold freeRaw rawAt
  rw [S.superposition x δ,Matrix.mul_add]
  simp [Matrix.add_apply,add_right_comm]

def Loop.closed {n : ℕ} (S : Loop n) (x : Mat n 1) (act : ℕ → ℝ → ℝ) : ℕ → Mat n 1
  | 0 => x
  | k+1 =>
    let z := S.closed x act k
    let v := S.rawAt k z
    S.A k*z + S.drive k + (act k v-v) • S.E k

def Loop.closedRaw {n : ℕ} (S : Loop n) (x : Mat n 1) (act : ℕ → ℝ → ℝ) (k : ℕ) :=
  S.rawAt k (S.closed x act k)

private theorem close_free {n : ℕ} (S : Loop n) (x : Mat n 1) (δ : ℕ → ℝ) (act : ℕ → ℝ → ℝ)
    (h : ∀ k, act k (S.freeRaw x δ k) - S.freeRaw x δ k = δ k) (k : ℕ) :
    S.closed x act k = S.free x δ k := by
  induction k with
  | zero => rfl
  | succ k ih =>
    simp only [Loop.closed,Loop.free,ih]
    have H := h k
    unfold Loop.freeRaw at H
    rw [H]

private theorem open_closed {n : ℕ} (S : Loop n) (x : Mat n 1) (δ : ℕ → ℝ) (act : ℕ → ℝ → ℝ)
    (h : ∀ k, act k (S.closedRaw x act k) - S.closedRaw x act k = δ k) (k : ℕ) :
    S.free x δ k = S.closed x act k := by
  induction k with
  | zero => rfl
  | succ k ih =>
    simp only [Loop.closed,Loop.free,ih]
    have H := h k
    unfold Loop.closedRaw at H
    rw [H]

/-- Independently forcing the actuator defect is equivalent to matching raw
and applied signals for every sequence of nonempty projection intervals. -/
theorem free_iff_all_intervals {n m : ℕ} (S : Loop n) (T : Loop m) (x : Mat n 1) (y : Mat m 1) :
    (∀ δ k, S.freeRaw x δ k = T.freeRaw y δ k) ↔
    ∀ (lo hi : ℕ → ℝ), (∀ k, lo k ≤ hi k) →
      let act := fun k => Conditioned.clip (lo k) (hi k)
      ∀ k, S.closedRaw x act k = T.closedRaw y act k ∧
        act k (S.closedRaw x act k) = act k (T.closedRaw y act k) := by
  constructor
  · intro h lo hi _ act
    let δ := fun k => act k (S.closedRaw x act k) - S.closedRaw x act k
    have hs (k : ℕ) : S.freeRaw x δ k = S.closedRaw x act k :=
      congrArg (S.rawAt k) (open_closed S x δ act (fun _ => rfl) k)
    have ht (k : ℕ) : T.closedRaw y act k = T.freeRaw y δ k := by
      apply congrArg (T.rawAt k) (close_free T y δ act _ k)
      intro j
      rw [←h δ,hs]
    intro k
    have eq := (hs k).symm.trans ((h δ k).trans (ht k).symm)
    exact ⟨eq,congrArg (act k) eq⟩
  · intro h δ
    let u := fun k => S.freeRaw x δ k + δ k
    let act := fun k => Conditioned.clip (u k) (u k)
    have fixed (k : ℕ) (v : ℝ) : act k v = u k := by simp [act,Conditioned.clip]
    have hs (k : ℕ) : S.closedRaw x act k = S.freeRaw x δ k := by
      apply congrArg (S.rawAt k) (close_free S x δ act _ k)
      intro j
      rw [fixed]
      exact add_sub_cancel_left _ _
    have eq (k : ℕ) : S.closedRaw x act k = T.closedRaw y act k := (h u u (fun _ => le_rfl) k).1
    have ht (k : ℕ) : T.freeRaw y δ k = T.closedRaw y act k := by
      apply congrArg (T.rawAt k) (open_closed T y δ act _ k)
      intro j
      rw [fixed,←eq,hs]
      exact add_sub_cancel_left _ _
    exact fun k => (hs k).symm.trans ((eq k).trans (ht k).symm)

private theorem pair_action {n m : ℕ} (A : Mat n n) (B : Mat m m) (x : Mat n 1) (y : Mat m 1) :
    pairDynamics A B * pairStack x y = pairStack (A*x) (B*y) := by
  simp [pairDynamics,pairStack,Matrix.submatrix_mul_equiv,Matrix.fromBlocks_mul_fromRows]

private theorem pair_response {n m : ℕ} (S : Loop n) (T : Loop m) (δ : ℕ → ℝ) (k : ℕ) :
    response (fun j => pairDynamics (S.A j) (T.A j)) (fun j => pairStack (S.E j) (T.E j)) δ k =
      pairStack (response S.A S.E δ k) (response T.A T.E δ k) := by
  induction k with
  | zero =>
    ext i j
    change 0 = Matrix.fromRows (0 : Mat n 1) (0 : Mat m 1) (finSumFinEquiv.symm i) j
    cases finSumFinEquiv.symm i <;> rfl
  | succ k ih =>
    simp only [response,ih,pair_action]
    ext i j
    change Matrix.fromRows _ _ (finSumFinEquiv.symm i) j + δ k * Matrix.fromRows _ _ (finSumFinEquiv.symm i) j =
      Matrix.fromRows _ _ (finSumFinEquiv.symm i) j
    cases finSumFinEquiv.symm i <;> rfl

private theorem raw_difference {n m : ℕ} (S : Loop n) (T : Loop m) (δ : ℕ → ℝ) (k : ℕ) :
    differenceReadout (S.C k) (T.C k) * response (fun j => pairDynamics (S.A j) (T.A j))
      (fun j => pairStack (S.E j) (T.E j)) δ k =
    S.C k * response S.A S.E δ k - T.C k * response T.A T.E δ k := by
  rw [pair_response]
  simp [differenceReadout,pairStack,Matrix.submatrix_mul_equiv,Matrix.fromCols_mul_fromRows,
    Matrix.neg_mul,sub_eq_add_neg]

/-- End-to-end criterion at matched nominal histories, expressed as finite
phase-local equations on only the reset column used at that phase. -/
theorem projected_iff_phase_signatures {n m L : ℕ} (hL : 0 < L)
    (S : Loop n) (T : Loop m) (x : Mat n 1) (y : Mat m 1)
    (h0 : ∀ k, S.freeRaw x 0 k = T.freeRaw y 0 k)
    (hA : ∀ k, pairDynamics (S.A (k+L)) (T.A (k+L)) = pairDynamics (S.A k) (T.A k))
    (hC : ∀ k, differenceReadout (S.C (k+L)) (T.C (k+L)) = differenceReadout (S.C k) (T.C k))
    (hb : ∀ k, pairStack (S.E (k+L)) (T.E (k+L)) = pairStack (S.E k) (T.E k)) :
    (∀ (lo hi : ℕ → ℝ), (∀ k, lo k ≤ hi k) →
      let act := fun k => Conditioned.clip (lo k) (hi k)
      ∀ k, S.closedRaw x act k = T.closedRaw y act k ∧
        act k (S.closedRaw x act k) = act k (T.closedRaw y act k)) ↔
    ∀ (s : Fin L) (j : Fin (n+m)) (k : Fin L),
      signature (fun h => pairDynamics (S.A h) (T.A h))
        (fun h => differenceReadout (S.C h) (T.C h)) s (pairStack (S.E s) (T.E s)) j k = 0 := by
  rw [←free_iff_all_intervals, residual_finite_iff (A := fun k => pairDynamics (S.A k) (T.A k))
    (C := fun k => differenceReadout (S.C k) (T.C k))
    (b := fun k => pairStack (S.E k) (T.E k)) hL hA hC hb]
  constructor
  · intro h δ k
    rw [raw_difference,sub_eq_zero]
    have H := h δ k
    rw [S.raw_superposition x δ,T.raw_superposition y δ,h0] at H
    ext i j
    obtain rfl : i = 0 := Subsingleton.elim _ _
    obtain rfl : j = 0 := Subsingleton.elim _ _
    exact add_left_cancel H
  · intro h δ k
    have H := h δ k
    rw [raw_difference,sub_eq_zero] at H
    rw [S.raw_superposition x δ,T.raw_superposition y δ,h0,H]

/-- Add only to the two dynamic output memories. -/
def resetColumn (i d : ℝ) : Mat 5 1 := column ![0,i,d,0,0]

def commandRow {n : ℕ} (X : Mat 2 n) : Mat 1 n := X.submatrix (fun _ => 1) id

/-- The strictly proper plant reacts to the full applied increment. Its
input column has coefficient one regardless of how the memory is split. -/
def physicalLoop {n : ℕ} (p : Plant ℝ n) (g : GainGraph.Coeff ℝ) (flags : ℕ → Flags)
    (i d r : ℕ → ℝ) : Loop (n+5) where
  A := fun k => (physicalPhase p g (flags k)).A
  C := fun k => commandRow (physicalPhase p g (flags k)).C
  E := fun k => rows p.B (resetColumn (i k) (d k))
  drive := fun k => (physicalPhase p g (flags k)).B * scalar (r k)
  direct := fun k => ((physicalPhase p g (flags k)).D * scalar (r k)) 1 0

theorem scalar_product (x y : ℝ) : scalar x * scalar y = scalar (x*y) := by
  ext i j
  simp [scalar,Matrix.mul_apply]

private theorem scalar_smul {n : ℕ} (E : Mat n 1) (d : ℝ) : d • E = E * scalar d := by
  ext i j
  obtain rfl : j = 0 := Subsingleton.elim _ _
  simp [Matrix.mul_apply,scalar,mul_comm]

/-- Interpretation of one complete forced tick, including the raw readout,
applied plant input and both corrected physical branch memories. -/
theorem physical_forced_step {n : ℕ} (p : Plant ℝ n) (g : GainGraph.Coeff ℝ)
    (flags : ℕ → Flags) (i d r : ℕ → ℝ) (k : ℕ) (x : Mat n 1) (ξ : Mat 5 1) (δ : ℝ) :
    let S := physicalLoop p g flags i d r
    let y := p.C*x
    let ξnext := F g (flags k)*ξ + Gy g (flags k)*y + Gr g (flags k)*scalar (r k)
    let v := readBranches ℝ * ξnext
    S.rawAt k (rows x ξ) = v 0 0 ∧
      S.A k * rows x ξ + S.drive k + δ • S.E k =
      rows (p.A*x + p.B*(v+scalar δ)) (ξnext + δ • resetColumn (i k) (d k)) := by
  dsimp only
  obtain ⟨state,out⟩ := physicalPhase_action p g (flags k) x ξ (scalar (r k))
  constructor
  · exact congrArg (fun z : Mat 2 1 => z 1 0) out
  · change (physicalPhase p g (flags k)).A * rows x ξ +
      (physicalPhase p g (flags k)).B * scalar (r k) + δ • rows p.B (resetColumn (i k) (d k)) = _
    rw [state,scalar_smul,rows_mul,rows_add,scalar_smul]
    simp only [Matrix.mul_add,add_assoc]

theorem reset_readback (i d : ℝ) : readBranches ℝ * resetColumn i d = scalar (i+d) := by
  ext k j
  simp [readBranches,resetColumn,column,scalar,Matrix.mul_apply,Fin.sum_univ_succ]

/-- Arbitrary strictly proper plant with last-applied-command target memory. -/
def predictiveLoop {n : ℕ} (p : Plant ℝ n) (η f t : ℝ) (r : ℕ → ℝ) : Loop (n+1) :=
  let E := rows p.B (1 : Mat 1 1)
  let C := cols (-f • p.C) (scalar t)
  ⟨fun _ => blocks p.A 0 0 0 + E*C, fun _ => C, fun _ => E,
    fun k => (η*r k) • E, fun k => η*r k⟩

/-- Minimal target for y' = a y + β₀ u + β₁ u_prev. Its second coordinate
is exactly the applied command. -/
def oneLagPredictive (a β₀ β₁ η f t : ℝ) (r : ℕ → ℝ) : Loop 2 where
  A := fun _ => !![a-β₀*f, β₁+β₀*t; -f,t]
  C := fun _ => fun _ => ![-f,t]
  E := fun _ => column ![β₀,1]
  drive := fun k => column ![β₀*η*r k, η*r k]
  direct := fun k => η*r k

theorem oneLag_forced_step (a β₀ β₁ η f t : ℝ) (r : ℕ → ℝ) (k : ℕ) (y prev δ : ℝ) :
    let T := oneLagPredictive a β₀ β₁ η f t r
    let z := column ![y,prev]
    let v := η*r k-f*y+t*prev
    T.rawAt k z = v ∧
      T.A k*z + T.drive k + δ • T.E k = column ![a*y+β₀*(v+δ)+β₁*prev,v+δ] := by
  constructor
  · simp [Loop.rawAt,oneLagPredictive,column,Matrix.mul_apply,Fin.sum_univ_two]
    ring
  · ext i j
    fin_cases i <;> simp [oneLagPredictive,column,Matrix.mul_apply,Matrix.vecMul,dotProduct,Fin.sum_univ_two] <;> ring

end
end MPCPID.PhaseCorrection
