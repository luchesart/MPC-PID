import MPCPID.Periodic
import MPCPID.GainGraph

/-! Phase and lifted matrices assembled from a strictly proper plant and the
five physical branch states. All coefficient constructions commute with ring
homomorphisms, in particular with real evaluation of polynomial parameters. -/
namespace MPCPID.PhysicalLift
open MPCPID.Periodic
open MPCPID.GainGraph (Coeff)

abbrev M (R : Type*) (i j : ℕ) := Matrix (Fin i) (Fin j) R

structure Plant (R : Type*) (n : ℕ) where
  A : M R n n
  B : M R n 1
  C : M R 1 n

def Plant.map {R S : Type*} [Semiring R] [Semiring S] {n} (p : Plant R n) (e : R →+* S) :
    Plant S n := ⟨p.A.map e,p.B.map e,p.C.map e⟩

structure System (R : Type*) (n m o : ℕ) where
  A : M R n n
  B : M R n m
  C : M R o n
  D : M R o m

def System.map {R S : Type*} [Semiring R] [Semiring S] {n m o} (t : System R n m o)
    (e : R →+* S) : System S n m o := ⟨t.A.map e,t.B.map e,t.C.map e,t.D.map e⟩

structure Flags where
  p : Bool
  i : Bool
  d : Bool

def bit {R : Type*} [Zero R] [One R] (b : Bool) : R := if b then 1 else 0

/-- Finite-coordinate block matrices retain chronological and branch order. -/
def blocks {R : Type*} {i j k l : ℕ} (a : M R i k) (b : M R i l) (c : M R j k) (d : M R j l) :
    M R (i+j) (k+l) := (Matrix.fromBlocks a b c d).submatrix finSumFinEquiv.symm finSumFinEquiv.symm

def rows {R : Type*} {i j k : ℕ} (a : M R i k) (b : M R j k) : M R (i+j) k :=
  (Matrix.fromRows a b).submatrix finSumFinEquiv.symm id

def cols {R : Type*} {i j k : ℕ} (a : M R i j) (b : M R i k) : M R i (j+k) :=
  (Matrix.fromCols a b).submatrix id finSumFinEquiv.symm

def column {R : Type*} {n : ℕ} (x : Fin n → R) : M R n 1 := fun i _ => x i

def scalar {R : Type*} (x : R) : M R 1 1 := fun _ _ => x

def readBranches (R : Type*) [One R] [Zero R] : M R 1 5 :=
  fun _ => ![1,1,1,0,0]

def F {R : Type*} [Ring R] (g : Coeff R) (s : Flags) : M R 5 5 :=
  phaseF (bit s.p) (bit s.i) (bit s.d) g.i1 g.α g.β

def Gy {R : Type*} [Ring R] (g : Coeff R) (s : Flags) : M R 5 1 :=
  column (phaseGy (bit s.p) (bit s.i) (bit s.d) g.K g.i0 g.β)

def Gr {R : Type*} [Ring R] (g : Coeff R) (s : Flags) : M R 5 1 :=
  column (phaseGr (bit s.p) (bit s.i) (bit s.d) g.K g.i0 g.β g.b g.c)

def physicalPhase {R : Type*} [Ring R] {n : ℕ} (p : Plant R n) (g : Coeff R) (s : Flags) :
    System R (n+5) 1 2 :=
  let h := readBranches R * F g s
  let jy := readBranches R * Gy g s
  let jr := readBranches R * Gr g s
  ⟨blocks (p.A+p.B*jy*p.C) (p.B*h) (Gy g s*p.C) (F g s),
   rows (p.B*jr) (Gr g s), blocks p.C 0 (jy*p.C) h, rows 0 jr⟩

def operatorPhase {R : Type*} [Ring R] (g : Coeff R) (s : Flags) : System R 5 2 1 :=
  let b := cols (Gr g s) (Gy g s)
  ⟨F g s,b,readBranches R * F g s,readBranches R * b⟩

@[simp] theorem map_blocks {R S : Type*} [Semiring R] [Semiring S] (e : R →+* S)
    {i j k l : ℕ} (a : M R i k) (b : M R i l) (c : M R j k) (d : M R j l) :
    (blocks a b c d).map e = blocks (a.map e) (b.map e) (c.map e) (d.map e) := by
  ext u v
  change e (Matrix.fromBlocks a b c d (finSumFinEquiv.symm u) (finSumFinEquiv.symm v)) = _
  cases hu : finSumFinEquiv.symm u <;> cases hv : finSumFinEquiv.symm v <;>
    simp [blocks, Matrix.submatrix_apply, hu,hv]

@[simp] theorem map_rows {R S : Type*} [Semiring R] [Semiring S] (e : R →+* S)
    {i j k : ℕ} (a : M R i k) (b : M R j k) :
    (rows a b).map e = rows (a.map e) (b.map e) := by
  ext u v
  cases hu : finSumFinEquiv.symm u <;> simp [rows, Matrix.submatrix_apply, hu, Matrix.map_apply]

@[simp] theorem map_cols {R S : Type*} [Semiring R] [Semiring S] (e : R →+* S)
    {i j k : ℕ} (a : M R i j) (b : M R i k) :
    (cols a b).map e = cols (a.map e) (b.map e) := by
  ext u v
  cases hv : finSumFinEquiv.symm v <;> simp [cols, Matrix.submatrix_apply, hv, Matrix.map_apply]

@[simp] theorem map_bit {R S : Type*} [Semiring R] [Semiring S] (e : R →+* S) (b : Bool) :
    e (bit b) = bit b := by cases b <;> simp [bit]

@[simp] theorem map_read {R S : Type*} [Ring R] [Ring S] (e : R →+* S) :
    (readBranches R).map e = readBranches S := by
  ext i j
  fin_cases j <;> simp [readBranches,Matrix.map_apply]

@[simp] theorem map_F {R S : Type*} [Ring R] [Ring S] (e : R →+* S) (g : Coeff R) (s : Flags) :
    (F g s).map e = F (Coeff.map e g) s := by
  ext i j
  fin_cases i <;> fin_cases j <;> simp [F,phaseF,Matrix.map_apply,Coeff.map]

@[simp] theorem map_Gy {R S : Type*} [Ring R] [Ring S] (e : R →+* S) (g : Coeff R) (s : Flags) :
    (Gy g s).map e = Gy (Coeff.map e g) s := by
  ext i j
  fin_cases i <;> simp [Gy,column,phaseGy,Matrix.map_apply,Coeff.map]

@[simp] theorem map_Gr {R S : Type*} [Ring R] [Ring S] (e : R →+* S) (g : Coeff R) (s : Flags) :
    (Gr g s).map e = Gr (Coeff.map e g) s := by
  ext i j
  fin_cases i <;> simp [Gr,column,phaseGr,Matrix.map_apply,Coeff.map]

@[simp] theorem map_physicalPhase {R S : Type*} [Ring R] [Ring S] {n} (e : R →+* S)
    (p : Plant R n) (g : Coeff R) (s : Flags) :
    (physicalPhase p g s).map e = physicalPhase (p.map e) (Coeff.map e g) s := by
  simp [physicalPhase,System.map,Plant.map,Matrix.map_mul,Matrix.map_add,
    map_blocks (i := 1) (j := 1) e, map_rows (i := 1) (j := 1) e]

@[simp] theorem map_operatorPhase {R S : Type*} [Ring R] [Ring S] (e : R →+* S)
    (g : Coeff R) (s : Flags) :
    (operatorPhase g s).map e = operatorPhase (Coeff.map e g) s := by
  simp [operatorPhase,System.map,Matrix.map_mul,map_cols (j := 1) (k := 1) e]

def selector {R : Type*} [One R] [Zero R] (L m k : ℕ) : M R m (L*m) :=
  fun i j => if (finProdFinEquiv.symm j : Fin L × Fin m).1.val = k ∧
                (finProdFinEquiv.symm j : Fin L × Fin m).2 = i then 1 else 0

def selector₁ {R : Type*} [One R] [Zero R] (L k : ℕ) : M R 1 L :=
  fun _ j => if j.val=k then 1 else 0

def frameWith {R : Type*} [Ring R] {n m o w : ℕ} (t : ℕ → System R n m o)
    (sel : ℕ → M R m w) (L : ℕ) : System R n w (L*o) :=
  let phi := liftedPhi (fun k => (t k).A)
  let beta := liftedB (fun k => (t k).A) (fun k => (t k).B) sel
  ⟨phi L,beta L,
    fun i j => let q : Fin L × Fin o := finProdFinEquiv.symm i
               ((t q.1).C * phi q.1) q.2 j,
    fun i j => let q : Fin L × Fin o := finProdFinEquiv.symm i
               ((t q.1).C * beta q.1 + (t q.1).D * sel q.1) q.2 j⟩

def frame {R : Type*} [Ring R] {n m o : ℕ} (t : ℕ → System R n m o)
    (L : ℕ) : System R n (L*m) (L*o) := frameWith t (selector L m) L

def physicalFrame {R : Type*} [Ring R] {n : ℕ} (p : Plant R n) (g : Coeff R)
    (flags : ℕ → Flags) (L : ℕ) : System R (n+5) L (L*2) :=
  frameWith (fun k => physicalPhase p g (flags k)) (selector₁ L) L

def operatorFrame {R : Type*} [Ring R] (g : Coeff R) (flags : ℕ → Flags) (L : ℕ) :
    System R 5 (L*2) (L*1) :=
  frame (fun k => operatorPhase g (flags k)) L

@[simp] theorem map_selector {R S : Type*} [Ring R] [Ring S] (e : R →+* S) (L m k : ℕ) :
    (selector L m k).map e = selector L m k := by
  ext i j; simp [selector,Matrix.map_apply]

@[simp] theorem map_selector₁ {R S : Type*} [Ring R] [Ring S] (e : R →+* S) (L k : ℕ) :
    (selector₁ L k).map e = selector₁ L k := by
  ext i j; simp [selector₁,Matrix.map_apply]

theorem map_frameWith {R S : Type*} [Ring R] [Ring S] (e : R →+* S) {n m o w : ℕ}
    (t : ℕ → System R n m o) (sel : ℕ → M R m w) (L : ℕ) :
    (frameWith t sel L).map e =
      frameWith (fun k => (t k).map e) (fun k => (sel k).map e) L := by
  unfold frameWith System.map
  dsimp only
  congr 1
  · exact map_liftedPhi e _ _
  · exact map_liftedB e _ _ _ _
  · ext i j
    let q : Fin L × Fin o := finProdFinEquiv.symm i
    change (((t q.1).C * liftedPhi (fun k => (t k).A) q.1).map e) q.2 j = _
    rw [Matrix.map_mul, map_liftedPhi]
  · ext i j
    let q : Fin L × Fin o := finProdFinEquiv.symm i
    change (((t q.1).C * liftedB (fun k => (t k).A) (fun k => (t k).B) sel q.1 +
      (t q.1).D * sel q.1).map e) q.2 j = _
    rw [Matrix.map_add,Matrix.map_mul,Matrix.map_mul,map_liftedB]
    exact e.map_add

theorem map_physicalFrame {R S : Type*} [Ring R] [Ring S] {n : ℕ} (e : R →+* S)
    (p : Plant R n) (g : Coeff R) (flags : ℕ → Flags) (L : ℕ) :
    (physicalFrame p g flags L).map e = physicalFrame (p.map e) (Coeff.map e g) flags L := by
  simp [physicalFrame,map_frameWith]

theorem map_operatorFrame {R S : Type*} [Ring R] [Ring S] (e : R →+* S)
    (g : Coeff R) (flags : ℕ → Flags) (L : ℕ) :
    (operatorFrame g flags L).map e = operatorFrame (Coeff.map e g) flags L := by
  simp [operatorFrame,frame,map_frameWith]

theorem blocks_mul_rows {R : Type*} [Ring R] {i j k l w : ℕ}
    (a : M R i k) (b : M R i l) (c : M R j k) (d : M R j l)
    (x : M R k w) (y : M R l w) :
    blocks a b c d * rows x y = rows (a*x+b*y) (c*x+d*y) := by
  simp [blocks,rows,Matrix.submatrix_mul_equiv, Matrix.fromBlocks_mul_fromRows]

theorem rows_mul {R : Type*} [Ring R] {i j k w : ℕ}
    (a : M R i k) (b : M R j k) (x : M R k w) :
    rows a b * x = rows (a*x) (b*x) := by
  unfold rows
  rw [← Matrix.fromRows_mul, Matrix.submatrix_mul _ _ _ id id Function.bijective_id]
  rfl

theorem rows_add {R : Type*} [Ring R] {i j k : ℕ}
    (a c : M R i k) (b d : M R j k) :
    rows a b+rows c d = rows (a+c) (b+d) := by
  ext u v
  change Matrix.fromRows a b (finSumFinEquiv.symm u) v +
      Matrix.fromRows c d (finSumFinEquiv.symm u) v =
      Matrix.fromRows (a+c) (b+d) (finSumFinEquiv.symm u) v
  cases finSumFinEquiv.symm u <;> rfl

/-- The phase realization acts on actual plant and branch states. The output
is the current measured y followed by the sum of the updated P/I/D branches. -/
theorem physicalPhase_action {R : Type*} [Ring R] {n : ℕ} (p : Plant R n)
    (g : Coeff R) (s : Flags) (x : M R n 1) (ξ : M R 5 1) (r : M R 1 1) :
    let y := p.C*x
    let ξnext := F g s*ξ + Gy g s*y + Gr g s*r
    let u := readBranches R * ξnext
    let ph := physicalPhase p g s
    (ph.A * rows x ξ + ph.B * r = rows (p.A*x + p.B*u) ξnext) ∧
      (ph.C * rows x ξ + ph.D*r = rows y u) := by
  dsimp only [physicalPhase]
  constructor <;> rw [blocks_mul_rows, rows_mul, rows_add] <;>
    simp [Matrix.mul_assoc,Matrix.mul_add,Matrix.add_mul,add_assoc,add_left_comm,add_comm]

/-- The five-dimensional phase part is the actual scalar update (2), even
before imposing the algebraic constraints that relate its gains to physical
time constants. -/
theorem nextBranches (g : Coeff ℝ) (s : Flags) (x : Fin 5 → ℝ) (r y : ℝ) :
    column (drivenBranches (bit s.p) (bit s.i) (bit s.d)
        g.K g.i0 g.i1 g.α g.β g.b g.c r y x) =
      F g s * column x + Gy g s * scalar y
        + Gr g s * scalar r := by
  rw [physicalPhaseMatrices]
  ext i j
  simp [F, Gy, Gr, column, scalar, Matrix.mul_apply, Matrix.mulVec, dotProduct, mul_comm]

/-- Final state of the one-period numerical phase recursion, for any grouping
of the exogenous inputs supported by the chosen selectors. -/
theorem frameWith_state {n m o w : ℕ} (t : ℕ → System ℝ n m o)
    (sel : ℕ → M ℝ m w) (L : ℕ) (x : M ℝ n 1) (v : M ℝ w 1) :
    frameState (fun k => (t k).A) (fun k => (t k).B) (fun k => sel k*v) x L =
    (frameWith t sel L).A*x + (frameWith t sel L).B*v :=
  frameState_lift _ _ _ _ _ _

/-- Every selected output in a frame is the actual output of its own phase.
This records the feedthrough from the current input and the within-frame past. -/
theorem frameWith_output {n m o w : ℕ} (t : ℕ → System ℝ n m o)
    (sel : ℕ → M ℝ m w) (L : ℕ) (x : M ℝ n 1) (v : M ℝ w 1) (k : Fin L) :
    ((frameWith t sel L).C*x + (frameWith t sel L).D*v).submatrix
        (fun i => finProdFinEquiv (k,i)) id =
    (t k).C * frameState (fun j => (t j).A) (fun j => (t j).B) (fun j => sel j*v) x k +
        (t k).D * (sel k*v) := by
  rw [withinFrameOutput (fun j => (t j).A) (fun j => (t j).B)
       (fun j => (t j).C) (fun j => (t j).D) sel v x k]
  ext i j
  simp only [Matrix.submatrix_apply, Matrix.add_apply, Matrix.mul_apply,frameWith,
    Equiv.symm_apply_apply,id_eq]

end MPCPID.PhysicalLift
