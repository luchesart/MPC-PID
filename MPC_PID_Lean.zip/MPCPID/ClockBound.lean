import Mathlib.Data.Fin.Tuple.Sort
import Mathlib.Data.Nat.ModEq
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-! A uniform period bound for three periodic clocks with incomparable
distinct firing patterns. No a priori maximum candidate period is assumed. -/
namespace MPCPID.ClockBound
open scoped BigOperators

abbrev Triple := Fin 3 → ℕ

def Fires (m φ : Triple) (i : Fin 3) (k : ℕ) : Prop := k % m i = φ i

def Rigid (m φ : Triple) : Prop :=
  ∀ k l : ℕ, (∀ i, Fires m φ i k → Fires m φ i l) →
    ∀ i, Fires m φ i l → Fires m φ i k

/-- Nested masks may be compared whenever every clock of period at most
d has the same status. This admits dynamic observation with a finite lag. -/
def RestrictedRigid (d : ℕ) (m φ : Triple) : Prop :=
  ∀ k l : ℕ, (∀ i, m i ≤ d → (Fires m φ i k ↔ Fires m φ i l)) →
    (∀ i, Fires m φ i k → Fires m φ i l) →
    ∀ i, Fires m φ i l → Fires m φ i k

def support (m φ : Triple) (k : ℕ) : Finset (Fin 3) :=
  Finset.univ.filter (fun i => k % m i = φ i)

@[simp] theorem mem_support (m φ : Triple) (k : ℕ) (i : Fin 3) :
    i ∈ support m φ k ↔ Fires m φ i k := by simp [support,Fires]

/-- If each nonempty subset has a nonzero weight sum, constant total
feedthrough rules out strictly nested distinct firing patterns. -/
theorem rigid_of_constant_sum {G : Type*} [AddCommGroup G]
    (m φ : Triple) (w : Fin 3 → G)
    (nonzero : ∀ S : Finset (Fin 3), S.Nonempty → ∑ i ∈ S, w i ≠ 0)
    (hc : ∀ k l, ∑ i ∈ support m φ k, w i = ∑ i ∈ support m φ l, w i) :
    Rigid m φ := by
  classical
  intro k l h i hi
  have sub : support m φ k ⊆ support m φ l := fun j hj =>
    (mem_support _ _ _ _).2 (h j ((mem_support _ _ _ _).1 hj))
  by_contra hn
  have ne : (support m φ l \ support m φ k).Nonempty :=
    ⟨i,Finset.mem_sdiff.mpr ⟨(mem_support _ _ _ _).2 hi,
       fun hh => hn ((mem_support _ _ _ _).1 hh)⟩⟩
  apply nonzero _ ne
  rw [Finset.sum_sdiff_eq_sub sub, hc k l, sub_self]

private theorem coverage (m φ : Triple) (bounds : ∀ i, φ i < m i) (rigid : Rigid m φ) (k : ℕ) :
    Fires m φ 0 k ∨ Fires m φ 1 k ∨ Fires m φ 2 k := by
  by_contra! hn
  have none (i : Fin 3) : ¬ Fires m φ i k := by fin_cases i <;> tauto
  have at0 : Fires m φ 0 (φ 0) := Nat.mod_eq_of_lt (bounds 0)
  exact none 0 (rigid k (φ 0) (fun i hi => False.elim (none i hi)) 0 at0)

private theorem gap_dvd {m φ k d : ℕ} (a : k % m = φ) (b : (k+d) % m = φ) :
    m ∣ d := by
  have he : k ≡ k+d [MOD m] := a.trans b.symm
  simpa using (Nat.modEq_iff_dvd' (Nat.le_add_right k d)).mp he

private theorem repeats {m k d : ℕ} (hd : m ∣ d) : (k+d) % m = k % m := by
  simp [Nat.add_mod k d m, Nat.mod_eq_zero_of_dvd hd]

private theorem ordered_bounds (d : ℕ) (m φ : Triple) (bounds : ∀ i, φ i < m i)
    (rigid : RestrictedRigid d m φ) (h01 : m 0 ≤ m 1) (h12 : m 1 ≤ m 2) :
    m 0 ≤ max d 3 ∧ m 1 ≤ max d (2*m 0) ∧ (m 2 ≤ d ∨ m 2 ∣ m 0*m 1) := by
  have pos (i : Fin 3) : 0 < m i := Nat.zero_lt_of_lt (bounds i)
  have first : m 0 ≤ max d 3 := by
    apply Nat.le_of_not_gt
    intro h
    have D0 : d < m 0 := (le_max_left _ _).trans_lt h
    have nod (i : Fin 3) : ¬ m i ≤ d := by
      fin_cases i
      · exact not_le_of_gt D0
      · exact not_le_of_gt (D0.trans_le h01)
      · exact not_le_of_gt ((D0.trans_le h01).trans_le h12)
    have allRigid : Rigid m φ := fun k l => rigid k l (fun i hi => (nod i hi).elim)
    have cv (k : ℕ) (hk : k ≤ 3) : k = φ 0 ∨ k = φ 1 ∨ k = φ 2 := by
      have h0 : k < m 0 := by omega
      have h1 : k < m 1 := by omega
      have h2 : k < m 2 := by omega
      simpa only [Fires,Nat.mod_eq_of_lt h0,Nat.mod_eq_of_lt h1,Nat.mod_eq_of_lt h2] using
        coverage m φ bounds allRigid k
    have A := cv 0 (by decide)
    have B := cv 1 (by decide)
    have C := cv 2 (by decide)
    have D := cv 3 (by decide)
    omega
  have second : m 1 ≤ max d (2*m 0) := by
    apply Nat.le_of_not_gt
    intro h
    have D1 : d < m 1 := (le_max_left _ _).trans_lt h
    have D2 : 2*m 0 < m 1 := (le_max_right _ _).trans_lt h
    have pair (k : ℕ) (hbase : k % m 0 = φ 1 % m 0) :
        Fires m φ 1 k ∨ Fires m φ 2 k := by
      by_contra hn
      have n1 : ¬ Fires m φ 1 k := fun hh => hn (Or.inl hh)
      have n2 : ¬ Fires m φ 2 k := fun hh => hn (Or.inr hh)
      have hs (i : Fin 3) : Fires m φ i k → Fires m φ i (φ 1) := by
        fin_cases i
        · exact fun hh => hbase.symm.trans hh
        · exact fun hi => False.elim (n1 hi)
        · exact fun hi => False.elim (n2 hi)
      have heq (i : Fin 3) (hi : m i ≤ d) : Fires m φ i k ↔ Fires m φ i (φ 1) := by
        fin_cases i
        · exact ⟨fun ha => hbase.symm.trans ha,fun ha => hbase.trans ha⟩
        · exact False.elim ((not_le_of_gt D1) hi)
        · exact False.elim ((not_le_of_gt (D1.trans_le h12)) hi)
      exact n1 (rigid k (φ 1) heq hs 1 (Nat.mod_eq_of_lt (bounds 1)))
    have orig : φ 1 % m 1 = φ 1 := Nat.mod_eq_of_lt (bounds 1)
    have singled (e : ℕ) (he : 0 < e) (hb : e ≤ 2*m 0) :
        ¬ Fires m φ 1 (φ 1 + e) := by
      intro hh
      have hl := Nat.le_of_dvd he (gap_dvd orig hh)
      omega
    have hp := pos 0
    have p := pair (φ 1 + m 0) (repeats (dvd_refl _))
    have q := pair (φ 1 + 2*m 0) (repeats (dvd_mul_left _ 2))
    have pf := p.resolve_left (singled _ hp (by omega))
    have qf := q.resolve_left (singled _ (by omega) (by omega))
    have next : (φ 1 + m 0 + m 0) % m 2 = φ 2 := by
      simpa only [Fires,two_mul,Nat.add_assoc] using qf
    have hl := Nat.le_of_dvd hp (gap_dvd pf next)
    omega
  refine ⟨first,second,?_⟩
  by_cases small : m 2 ≤ d
  · exact Or.inl small
  right
  let e := m 0 * m 1
  have r0 := repeats (k := φ 2) (dvd_mul_right (m 0) (m 1))
  have r1 := repeats (k := φ 2) (dvd_mul_left (m 1) (m 0))
  have at2 : Fires m φ 2 (φ 2) := Nat.mod_eq_of_lt (bounds 2)
  have sub (i : Fin 3) : Fires m φ i (φ 2+e) → Fires m φ i (φ 2) := by
    fin_cases i
    · exact fun hh => r0.symm.trans hh
    · exact fun hh => r1.symm.trans hh
    · exact fun _ => at2
  have heq (i : Fin 3) (hi : m i ≤ d) : Fires m φ i (φ 2+e) ↔ Fires m φ i (φ 2) := by
    fin_cases i
    · exact ⟨fun hh => r0.symm.trans hh,fun hh => r0.trans hh⟩
    · exact ⟨fun hh => r1.symm.trans hh,fun hh => r1.trans hh⟩
    · exact False.elim (small hi)
  exact gap_dvd at2 (rigid _ _ heq sub 2 at2)

/-- A uniform cutoff for the physical period enumeration from a lag-d
response. The supplied triple need not be sorted. -/
theorem periods_le_lag_bound {d : ℕ} (m φ : Triple) (bounds : ∀ i, φ i < m i)
    (rigid : RestrictedRigid d m φ) : ∀ i, m i ≤ 2*(max d 3)^2 := by
  let e := Tuple.sort m
  have hr : RestrictedRigid d (m ∘ e) (φ ∘ e) := by
    intro k l hs H i hi
    apply rigid k l _ _ (e i) hi
    · intro j hj
      simpa [Fires] using hs (e.symm j) (by simpa using hj)
    · intro j
      simpa [Fires] using H (e.symm j)
  have hm := Tuple.monotone_sort m
  obtain ⟨a,b,c⟩ := ordered_bounds d (m ∘ e) (φ ∘ e) (fun i => bounds (e i)) hr
    (hm (by decide : (0 : Fin 3) ≤ 1)) (hm (by decide : (1 : Fin 3) ≤ 2))
  have posprod : 0 < (m ∘ e) 0 * (m ∘ e) 1 :=
    Nat.mul_pos (Nat.zero_lt_of_lt (bounds _)) (Nat.zero_lt_of_lt (bounds _))
  have hd : d ≤ max d 3 := le_max_left _ _
  have gpos : 0 < max d 3 := by omega
  have mid : (m ∘ e) 1 ≤ 2*max d 3 := by omega
  have hp := Nat.mul_le_mul a mid
  have last : (m ∘ e) 2 ≤ 2*(max d 3)^2 := by
    rcases c with c|c
    · nlinarith [Nat.one_le_iff_ne_zero.mpr (Nat.ne_of_gt gpos)]
    · have le := Nat.le_of_dvd posprod c
      calc
        _ ≤ _ := le
        _ ≤ _ := hp
        _ = _ := by ring
  intro i
  have ht := hm (Fin.le_last (e.symm i))
  change m (e (e.symm i)) ≤ (m ∘ e) 2 at ht
  rw [Equiv.apply_symm_apply] at ht
  exact ht.trans last

/-- Without exempt clocks the lag bound gives 18. -/
theorem periods_le_eighteen (m φ : Triple) (bounds : ∀ i, φ i < m i) (rigid : Rigid m φ) :
    ∀ i, m i ≤ 18 := by
  exact periods_le_lag_bound (d := 0) m φ bounds (fun k l _ => rigid k l)

/- After the analytic reduction only ten ordered triples with largest
period above four survive the arithmetic constraints. Each of their phase
choices misses a base tick in the first 18 samples. Lean kernel reduction
checks this closed finite statement. -/
set_option synthInstance.maxSize 1500 in
set_option maxHeartbeats 16000000 in
set_option maxRecDepth 10000 in
private theorem finite_obstruction :
   ∀ a : Fin 4, ∀ b : Fin 7, ∀ c : Fin 19,
     0 < a.val ∧ a.val ≤ b.val ∧ b.val ≤ c.val ∧
     b.val ≤ 2*a.val ∧ c.val ∣ a.val*b.val ∧ 4 < c.val →
     ∀ u : Fin a.val, ∀ v : Fin b.val, ∀ w : Fin c.val,
     ∃ j : Fin 18, j.val % a.val ≠ u.val ∧ j.val % b.val ≠ v.val ∧ j.val % c.val ≠ w.val := by decide

/-- In the rigid case the uniform bound improves to four. A schedule with
periods (2,4,4) and phases (0,1,3) partitions time into three residue classes. -/
theorem periods_le_four (m φ : Triple) (bounds : ∀ i, φ i < m i) (rigid : Rigid m φ) :
    ∀ i, m i ≤ 4 := by
  let e := Tuple.sort m
  let M := m ∘ e
  let F := φ ∘ e
  have hr : Rigid M F := by
    intro k l sub i hi
    apply rigid k l _ (e i) hi
    intro j
    simpa [M,F,Fires] using sub (e.symm j)
  have B (i : Fin 3) : F i < M i := bounds (e i)
  have h01 : M 0 ≤ M 1 := Tuple.monotone_sort m (by decide : (0 : Fin 3) ≤ 1)
  have h12 : M 1 ≤ M 2 := Tuple.monotone_sort m (by decide : (1 : Fin 3) ≤ 2)
  have h18 := periods_le_eighteen M F B hr 2
  obtain ⟨a,b,c⟩ := ordered_bounds 0 M F B (fun k l _ => hr k l) h01 h12
  have ha : M 0 ≤ 3 := a
  have hb : M 1 ≤ 2*M 0 := by simpa using b
  have hpos (i : Fin 3) : 0 < M i := Nat.zero_lt_of_lt (B i)
  have hc := c.resolve_left (not_le_of_gt (hpos 2))
  have short : M 2 ≤ 4 := by
    apply Nat.le_of_not_gt
    intro h
    obtain ⟨j, h0,h1,h2⟩ := finite_obstruction
      ⟨M 0,by omega⟩ ⟨M 1,by omega⟩ ⟨M 2,by omega⟩
      ⟨hpos 0,h01,h12,hb,hc,h⟩ ⟨F 0,B 0⟩ ⟨F 1,B 1⟩ ⟨F 2,B 2⟩
    exact (coverage M F B hr j).elim h0 (fun hh => hh.elim h1 h2)
  intro i
  have ht := Tuple.monotone_sort m (Fin.le_last (e.symm i))
  change m (e (e.symm i)) ≤ M 2 at ht
  rw [Equiv.apply_symm_apply] at ht
  exact ht.trans short

/-- A period-one clock is constant, so the period-four cutoff also applies
to the positive-lag signature criterion when d = 1. -/
theorem periods_le_four_of_lag_one (m φ : Triple) (bounds : ∀ i, φ i < m i)
    (rigid : RestrictedRigid 1 m φ) : ∀ i, m i ≤ 4 := by
  apply periods_le_four m φ bounds
  intro k l
  apply rigid k l
  intro i h
  have hi := bounds i
  have hm : m i = 1 := by omega
  simp only [Fires,hm,Nat.mod_one]

end MPCPID.ClockBound
