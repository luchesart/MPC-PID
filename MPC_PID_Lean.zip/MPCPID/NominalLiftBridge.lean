import MPCPID.NominalExecution
import MPCPID.PhaseCorrection

/-! The complete nominal Markov test on lifted systems implies agreement of
the actual plant/PID from every start phase with a base-rate LTI impulse. -/
namespace MPCPID.NominalLiftBridge
open PhysicalLift PhysicalSchedule GainGraph Periodic
open NominalExecution (MatchesImpulse closedRun measure)
open NominalColumns (pulse)
open OperatorPhase (V tick command)
noncomputable section

def liftScalar {n o : ℕ} (T : ℕ → System ℝ n 1 o) (L : ℕ) :=
  frameWith T (selector₁ L) L

def targetLift {t : ℕ} (X : System ℝ t 1 2) (L : ℕ) := liftScalar (fun _ => X) L

def state {n o : ℕ} (T : ℕ → System ℝ n 1 o) (u : ℕ → ℝ) (k : ℕ) : Mat n 1 :=
  frameState (fun k => (T k).A) (fun k => (T k).B) (fun k => scalar (u k)) 0 k

def outputAt {n o : ℕ} (T : ℕ → System ℝ n 1 o) (u : ℕ → ℝ) (k : ℕ) : Mat o 1 :=
  (T k).C * state T u k + (T k).D * scalar (u k)

def impulseOutput {t : ℕ} (X : System ℝ t 1 2) (k : ℕ) : Mat 2 1 :=
  outputAt (fun _ => X) pulse k

theorem impulseOutput_zero {t : ℕ} (X : System ℝ t 1 2) : impulseOutput X 0 = X.D := by
  have one : scalar (pulse 0) = (1 : Mat 1 1) := by
    ext i j
    fin_cases i; fin_cases j; simp [scalar,pulse]
  simp [impulseOutput,outputAt,state,frameState,one]

theorem impulseOutput_succ {t : ℕ} (X : System ℝ t 1 2) (k : ℕ) :
    impulseOutput X (k+1) = X.C * X.A^k * X.B := by
  have one : scalar (pulse 0) = (1 : Mat 1 1) := by
    ext i j
    fin_cases i; fin_cases j; simp [scalar,pulse]
  have zero (j : ℕ) : scalar (pulse (j+1)) = (0 : Mat 1 1) := by ext i v; simp [scalar,pulse]
  have st (j : ℕ) : state (fun _ => X) pulse (j+1) = X.A^j * X.B := by
    induction j with
    | zero => simp [state,frameState,one]
    | succ j ih =>
      change X.A*state (fun _ => X) pulse (j+1) + X.B*scalar (pulse (j+1)) = _
      rw [ih,zero,pow_succ',Matrix.mul_zero,add_zero,Matrix.mul_assoc]
  simp only [impulseOutput,outputAt,st,zero,Matrix.mul_zero,add_zero,Matrix.mul_assoc]

def block (L q : ℕ) (u : ℕ → ℝ) : Mat L 1 := PhysicalLift.column (fun j => u (q*L+j))

def history (L : ℕ) (u : ℕ → ℝ) : ℕ → List (Mat L 1)
  | 0 => []
  | q+1 => block L q u :: history L u q

private theorem within_state {n o L : ℕ} {T : ℕ → System ℝ n 1 o}
    (hT : ∀ k, T (k+L)=T k) (u : ℕ → ℝ) (q j : ℕ) (hj : j ≤ L) :
    state T u (q*L+j) = frameState (fun k => (T k).A) (fun k => (T k).B)
      (fun k => selector₁ L k * block L q u) (state T u (q*L)) j := by
  induction j with
  | zero => rfl
  | succ j ih =>
    have h := OperatorPhase.selector_one_reads (⟨j,hj⟩ : Fin L) (fun i => u (q*L+i))
    have hb : selector₁ L j * block L q u = scalar (u (q*L+j)) := h
    have ht : T (q*L+j) = T j := by simpa only [Nat.add_comm (q*L)] using PhaseCorrection.period_shift hT j q
    change (T (q*L+j)).A * state T u (q*L+j) + (T (q*L+j)).B * scalar (u (q*L+j)) = _
    rw [ht,ih (by omega),frameState,hb]

private theorem boundary {n o L : ℕ} {T : ℕ → System ℝ n 1 o}
    (hT : ∀ k, T (k+L)=T k) (u : ℕ → ℝ) (q : ℕ) :
    state T u (q*L) = advance (liftScalar T L).A (liftScalar T L).B 0 (history L u q) := by
  induction q with
  | zero => simp [state,history,advance,frameState]
  | succ q ih =>
    rw [Nat.succ_mul,within_state hT u q L le_rfl,frameWith_state,ih]
    rfl

theorem output_from_lift {n o L : ℕ} {T : ℕ → System ℝ n 1 o}
    (hT : ∀ k, T (k+L)=T k) (u : ℕ → ℝ) (q : ℕ) (j : Fin L) :
    outputAt T u (q*L+j) = ((liftScalar T L).C *
      advance (liftScalar T L).A (liftScalar T L).B 0 (history L u q)
      + (liftScalar T L).D * block L q u).submatrix (fun i => finProdFinEquiv (j,i)) id := by
  rw [←boundary hT]
  unfold liftScalar
  rw [frameWith_output T (selector₁ L) L (state T u (q*L)) (block L q u) j]
  have h := OperatorPhase.selector_one_reads j (fun i => u (q*L+i))
  have hb : selector₁ L j * block L q u = scalar (u (q*L+j)) := h
  have ht : T (q*L+j) = T j := by simpa only [Nat.add_comm (q*L)] using PhaseCorrection.period_shift hT (j:ℕ) q
  rw [←within_state hT u q j j.isLt.le,hb]
  simp [outputAt,ht]

/-- Equality of full chronological lifted outputs for all block experiments
implies equality at every base tick, for any input sequence. -/
theorem all_base_outputs {n t o L : ℕ} (hL : 0 < L) {T : ℕ → System ℝ n 1 o}
    {Q : ℕ → System ℝ t 1 o} (hT : ∀ k, T (k+L)=T k) (hQ : ∀ k, Q (k+L)=Q k)
    (hm : MatchSys (liftScalar T L) (liftScalar Q L)) (u : ℕ → ℝ) (k : ℕ) :
    outputAt T u k = outputAt Q u k := by
  let j : Fin L := ⟨k%L,Nat.mod_lt _ hL⟩
  have hj : k/L*L+j = k := by simpa [j,Nat.mul_comm,Nat.add_comm] using Nat.mod_add_div k L
  have h := hm (block L (k/L) u) (history L u (k/L))
  calc
    outputAt T u k = outputAt T u (k/L*L+j) := congrArg (outputAt T u) hj.symm
    _ = _ := (output_from_lift hT u (k/L) j).trans ((congrArg (fun M => Matrix.submatrix M
          (fun i => finProdFinEquiv (j,i)) id) h).trans (output_from_lift hQ u (k/L) j).symm)
    _ = outputAt Q u k := congrArg (outputAt Q u) hj

def delayed (s k : ℕ) : ℝ := if k=s then 1 else 0

private theorem delayed_shift (s k : ℕ) : delayed s (s+k) = pulse k := by
  simp [delayed,pulse]

private theorem starts_zero {n o : ℕ} (T : ℕ → System ℝ n 1 o) (s k : ℕ) (hk : k ≤ s) :
    state T (delayed s) k = 0 := by
  induction k with
  | zero => rfl
  | succ k ih =>
    change (T k).A * state T (delayed s) k + (T k).B * scalar (delayed s k) = 0
    rw [ih (by omega),show scalar (delayed s k) = 0 by simp [delayed,show k ≠ s by omega,scalar]; rfl]
    simp

private theorem shift_state {n o : ℕ} (T : ℕ → System ℝ n 1 o) (s k : ℕ) :
    state T (delayed s) (s+k) = state (fun j => T (s+j)) pulse k := by
  induction k with
  | zero => exact starts_zero T s s le_rfl
  | succ k ih =>
    change (T (s+k)).A * state T (delayed s) (s+k) + (T (s+k)).B * scalar (delayed s (s+k)) = _
    rw [ih,delayed_shift]
    rfl

theorem shift_output {n o : ℕ} (T : ℕ → System ℝ n 1 o) (s k : ℕ) :
    outputAt T (delayed s) (s+k) = outputAt (fun j => T (s+j)) pulse k := by
  simp only [outputAt,shift_state,delayed_shift]

private theorem col_mulVec {n m : ℕ} (A : Mat n m) (v : V m) :
    PhysicalLift.column (A.mulVec v) = A * PhysicalLift.column v := rfl

private theorem yc {n : ℕ} (P : Plant ℝ n) (x : V n) :
    P.C * PhysicalLift.column x = scalar (measure P x) := by
  ext i j
  obtain rfl : i=0 := Subsingleton.elim _ _
  rfl

private theorem uc (ξ : V 5) : readBranches ℝ * PhysicalLift.column ξ = scalar (command ξ) := by
  ext i j
  obtain rfl : i=0 := Subsingleton.elim _ _
  exact OperatorPhase.read_updates ξ

private theorem plantVec {n : ℕ} (P : Plant ℝ n) (x : V n) (u : ℝ) :
    PhysicalLift.column (P.A.mulVec x + u • (fun j => P.B j 0)) =
    P.A * PhysicalLift.column x + P.B * scalar u := by
  ext i j
  simp [PhysicalLift.column,Matrix.mul_apply,Matrix.mulVec,dotProduct,scalar,mul_comm]

private def aug {n : ℕ} (z : V n × V 5) := rows (PhysicalLift.column z.1) (PhysicalLift.column z.2)

private theorem tick_matrices (g : Coeff ℝ) (f : Flags) (r y : ℝ) (z : V 5) :
    PhysicalLift.column (tick g f ![r,y] z) = F g f * PhysicalLift.column z +
      Gy g f * scalar y + Gr g f * scalar r := nextBranches g f z r y

private theorem physical_state {L n : ℕ} (s : Clocks L) (P : Plant ℝ n) (g : Coeff ℝ) (start k : ℕ) :
    state (fun j => physicalPhase P g (s.flags (start+j))) pulse k =
      aug (closedRun s P g start k) := by
  induction k with
  | zero =>
    ext i j
    change 0 = Matrix.fromRows (0 : Mat n 1) (0 : Mat 5 1) (finSumFinEquiv.symm i) j
    cases finSumFinEquiv.symm i <;> rfl
  | succ k ih =>
    let z := closedRun s P g start k
    let f := s.flags (start+k)
    let r := pulse k
    let b := tick g f ![r,measure P z.1] z.2
    have tickM := tick_matrices g f r (measure P z.1) z.2
    change (physicalPhase P g f).A * state _ pulse k + (physicalPhase P g f).B * scalar r = _
    rw [ih]
    change (physicalPhase P g f).A * rows (PhysicalLift.column z.1) (PhysicalLift.column z.2) +
      (physicalPhase P g f).B * scalar r = rows
      (PhysicalLift.column (P.A.mulVec z.1 + command b • fun j => P.B j 0)) (PhysicalLift.column b)
    rw [(physicalPhase_action P g f _ _ _).1, yc,←tickM,uc,plantVec]

theorem physical_output {L n : ℕ} (s : Clocks L) (P : Plant ℝ n) (g : Coeff ℝ) (start k : ℕ) :
    outputAt (fun j => physicalPhase P g (s.flags (start+j))) pulse k =
      rows (scalar (measure P (closedRun s P g start k).1))
           (scalar (command (closedRun s P g start (k+1)).2)) := by
  rw [outputAt,physical_state]
  let z := closedRun s P g start k
  let f := s.flags (start+k)
  change (physicalPhase P g f).C * rows (PhysicalLift.column z.1) (PhysicalLift.column z.2) +
    (physicalPhase P g f).D * scalar (pulse k) = _
  rw [(physicalPhase_action P g f _ _ _).2,yc,←tick_matrices,uc]
  rfl

theorem matches_impulse {L n t : ℕ} (s : Clocks L) (P : Plant ℝ n) (g : Coeff ℝ)
    (X : System ℝ t 1 2)
    (matchLift : MatchSys (physicalFrame P g s.flags L) (targetLift X L)) :
    MatchesImpulse s P g (fun k => impulseOutput X k 0 0) (fun k => impulseOutput X k 1 0) := by
  intro start k
  let T := fun j => physicalPhase P g (s.flags j)
  have hT (j : ℕ) : T (j+L)=T j := congrArg (physicalPhase P g) (s.flags_periodic j)
  have h := all_base_outputs s.frame_pos hT (fun _ => rfl) matchLift (delayed start) (start+k)
  rw [shift_output,shift_output] at h
  change outputAt (fun j => physicalPhase P g (s.flags (start+j))) pulse k = impulseOutput X k at h
  rw [physical_output] at h
  exact ⟨congrArg (fun z : Mat 2 1 => z 0 0) h,congrArg (fun z : Mat 2 1 => z 1 0) h⟩

end
end MPCPID.NominalLiftBridge
