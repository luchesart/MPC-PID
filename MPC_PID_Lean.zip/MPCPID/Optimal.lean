import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.Normed.Group.InfiniteSum
import Mathlib.Topology.Algebra.InfiniteSum.Ring
import Mathlib.Data.Real.Sqrt
import Mathlib.Tactic.ByContra
import Mathlib.Tactic.SplitIfs
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum.RealSqrt
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
# Steps from equilibrium and realized infinite-horizon MIACE

The error sequence is indexed at the *next* output; the control sequence is
indexed at the current input. The predecessor input, measured relative to
the new equilibrium, is consequently included exactly once.
-/
noncomputable section
set_option maxHeartbeats 1000000
namespace MPCPID.Optimal

structure Model where
  a : ℝ
  b : ℝ
  c : ℝ
  l : ℝ
  ha : 0 ≤ a
  ha1 : a < 1
  hb : 0 < b
  hc : 0 < c
  hl : 0 < l

namespace Model

variable (P : Model)

def s := P.b + P.c
def den := P.b ^ 2 + P.l
def pole := (P.a * P.l - P.b * P.c) / P.den
def amp := (P.a * P.b + P.c) / (P.s * P.den)
def before (δ : ℝ) := -(1 - P.a) * δ / P.s

theorem s_pos : 0 < P.s := add_pos P.hb P.hc
theorem den_pos : 0 < P.den := add_pos_of_nonneg_of_pos (sq_nonneg _) P.hl
theorem amp_pos : 0 < P.amp :=
  div_pos (add_pos_of_nonneg_of_pos (mul_nonneg P.ha P.hb.le) P.hc)
    (mul_pos P.s_pos P.den_pos)

theorem pole_nonneg_iff : 0 ≤ P.pole ↔ P.b * P.c ≤ P.a * P.l := by
  unfold pole
  constructor
  · intro H
    have := (le_div_iff₀ P.den_pos).mp H
    linarith
  · intro H
    apply (le_div_iff₀ P.den_pos).mpr
    linarith

theorem pole_lt_one : P.pole < 1 := by
  apply (div_lt_iff₀ P.den_pos).2
  dsimp [den]
  nlinarith [mul_pos (sub_pos.mpr P.ha1) P.hl, mul_pos P.hb P.hc,
    sq_nonneg P.b]

theorem first_fraction_lt_one : P.l * P.amp < 1 := by
  unfold amp
  rw [← mul_div_assoc]
  apply (div_lt_iff₀ (mul_pos P.s_pos P.den_pos)).2
  dsimp [s, den]
  nlinarith [mul_pos P.s_pos (sq_pos_of_pos P.hb),
    mul_pos (mul_pos P.hl P.hb) (sub_pos.mpr P.ha1),
    mul_pos (add_pos P.hb P.hc) (sq_pos_of_pos P.hb)]

/-- Deviations are (current tracking error, previous applied input excess). -/
def advance (x : ℝ × ℝ) : ℝ × ℝ :=
  (P.l * (P.a * x.1 - P.c * x.2) / P.den,
   P.b * (P.a * x.1 - P.c * x.2) / P.den)

/-- Restoring absolute coordinates reproduces the first-move law (62). -/
theorem advance_first_move (r y uPrev : ℝ) :
    let us := (1-P.a)*r/P.s
    us + (P.advance (r-y, uPrev-us)).2 =
      ((P.b + P.l*(1-P.a)/P.s)/P.den)*r -
      (P.a*P.b/P.den)*y - (P.b*P.c/P.den)*uPrev := by
  dsimp only [advance]
  field_simp [ne_of_gt P.s_pos, ne_of_gt P.den_pos]
  simp only [s, den]
  ring

/-- Completion of the square for the one-step objective in input deviations. -/
theorem advance_cost (x : ℝ × ℝ) (v : ℝ) :
    (P.a*x.1 - P.c*x.2 - P.b*v)^2 + P.l*v^2 =
      ((P.advance x).1)^2 + P.l*((P.advance x).2)^2 +
        P.den*(v-(P.advance x).2)^2 := by
  have hD := ne_of_gt P.den_pos
  dsimp only [advance]
  field_simp [hD]
  unfold den
  ring

theorem advance_minimizer (x : ℝ × ℝ) (v : ℝ) :
    ((P.advance x).1)^2 + P.l*((P.advance x).2)^2 ≤
      (P.a*x.1-P.c*x.2-P.b*v)^2+P.l*v^2 := by
  rw [P.advance_cost x v]
  linarith [mul_nonneg P.den_pos.le (sq_nonneg (v-(P.advance x).2))]

theorem advance_unique (x : ℝ × ℝ) (v : ℝ) :
    (P.a*x.1-P.c*x.2-P.b*v)^2+P.l*v^2 =
      ((P.advance x).1)^2+P.l*((P.advance x).2)^2 ↔ v = (P.advance x).2 := by
  rw [P.advance_cost x v]
  constructor
  · intro hx
    by_contra hv
    have ht := mul_pos P.den_pos (sq_pos_of_ne_zero (sub_ne_zero.mpr hv))
    linarith
  · rintro rfl
    ring

theorem advance_plant (x : ℝ × ℝ) :
    (P.advance x).1 = P.a*x.1 - P.b*(P.advance x).2 - P.c*x.2 := by
  dsimp only [advance]
  field_simp [ne_of_gt P.den_pos]
  unfold den
  ring

def trajectory (δ : ℝ) : ℕ → ℝ × ℝ
  | 0 => P.advance (δ, P.before δ)
  | n+1 => P.advance (trajectory δ n)

def err (δ : ℝ) (n : ℕ) := δ * P.l * P.amp * P.pole ^ n
def cmd (δ : ℝ) (n : ℕ) := δ * P.b * P.amp * P.pole ^ n

theorem trajectory_eq (δ : ℝ) (n : ℕ) :
    P.trajectory δ n = (P.err δ n, P.cmd δ n) := by
  induction n with
  | zero =>
    apply Prod.ext <;>
      dsimp [trajectory, advance, err, cmd, amp, before] <;>
      field_simp [ne_of_gt P.s_pos, ne_of_gt P.den_pos] <;>
      unfold s <;> ring
  | succ n ih =>
    rw [trajectory, ih]
    apply Prod.ext <;>
      dsimp only [advance, err, cmd, Prod.fst, Prod.snd] <;>
      rw [pow_succ] <;>
      unfold pole <;> ring

def prev (t : ℝ) (f : ℕ → ℝ) : ℕ → ℝ
  | 0 => t
  | n+1 => f n

/-- Error relative to step magnitude, including the sample at the old equilibrium. -/
def trackingFraction (n : ℕ) :=
  prev 1 (fun k => P.l * P.amp * P.pole^k) n

theorem trackingFraction_eq (δ : ℝ) (hδ : δ ≠ 0) (n : ℕ) :
    prev δ (fun k => (P.trajectory δ k).1) n / δ = P.trackingFraction n := by
  cases n with
  | zero => simp [prev, trackingFraction, hδ]
  | succ n =>
    simp only [prev, trackingFraction, trajectory_eq, err]
    field_simp [hδ]
    ring

theorem monotone_iff :
    (∀ n, 0 ≤ P.trackingFraction (n+1) ∧
      P.trackingFraction (n+1) ≤ P.trackingFraction n) ↔
      P.b * P.c ≤ P.a * P.l := by
  constructor
  · intro H
    have h := (H 1).1
    change 0 ≤ P.l * P.amp * P.pole ^ 1 at h
    rw [pow_one] at h
    exact P.pole_nonneg_iff.mp ((mul_nonneg_iff_of_pos_left (mul_pos P.hl P.amp_pos)).mp h)
  · intro h n
    have hp := P.pole_nonneg_iff.mpr h
    have hk := mul_nonneg P.hl.le P.amp_pos.le
    cases n with
    | zero =>
      simpa [trackingFraction, prev] using And.intro hk P.first_fraction_lt_one.le
    | succ n =>
      change 0 ≤ P.l*P.amp*P.pole^(n+1) ∧
        P.l*P.amp*P.pole^(n+1) ≤ P.l*P.amp*P.pole^n
      rw [pow_succ]
      constructor
      · positivity
      · simpa [mul_assoc] using
          (mul_le_mul_of_nonneg_left P.pole_lt_one.le
            (mul_nonneg hk (pow_nonneg hp n)))

theorem second_crosses_iff : P.trackingFraction 2 < 0 ↔ P.a*P.l < P.b*P.c := by
  change P.l * P.amp * P.pole^1 < 0 ↔ _
  rw [pow_one]
  apply lt_iff_lt_of_le_iff_le
  exact (mul_nonneg_iff_of_pos_left (mul_pos P.hl P.amp_pos)).trans P.pole_nonneg_iff

theorem deadbeat_from_second (hz : P.a*P.l = P.b*P.c) (δ : ℝ) (n : ℕ) :
    P.trajectory δ (n+1) = (0,0) := by
  have hp : P.pole = 0 := by simp [pole,hz]
  simp [trajectory_eq, err, cmd, hp]

def Plant (δ : ℝ) (e v : ℕ → ℝ) : Prop :=
  ∀ n, e n = P.a * prev δ e n - P.b * v n - P.c * prev (P.before δ) v n

theorem trajectory_plant (δ : ℝ) : P.Plant δ (P.err δ) (P.cmd δ) := by
  intro n
  cases n with
  | zero =>
    have h := P.advance_plant (δ, P.before δ)
    change (P.trajectory δ 0).1 = P.a*δ - P.b*(P.trajectory δ 0).2 -
      P.c*(P.before δ) at h
    simpa only [trajectory_eq, prev] using h
  | succ n =>
    have h := P.advance_plant (P.trajectory δ n)
    change (P.trajectory δ (n+1)).1 = P.a*(P.trajectory δ n).1 -
      P.b*(P.trajectory δ (n+1)).2 - P.c*(P.trajectory δ n).2 at h
    simpa only [trajectory_eq, prev] using h

def FiniteArea (e : ℕ → ℝ) := Summable (fun k => |e k|)
def area (h : ℝ) (e : ℕ → ℝ) := h * ∑' k, |e k|
def barrier (h δ : ℝ) := h * |δ| * ((P.a * P.b + P.c) / P.s)
def cost (h μ : ℝ) (e v : ℕ → ℝ) := Real.sqrt ((area h e)^2 + μ * (area h v)^2)

private theorem preceding_hasSum {f : ℕ → ℝ} {F : ℝ} (hf : HasSum f F) (t : ℝ) :
    HasSum (prev t f) (F + t) := by
  have hh : HasSum (fun n => prev t f (n+1)) F := hf
  simpa [prev] using ((hasSum_nat_add_iff (f := prev t f) 1).mp hh)

/-- Signed balance for the infinite sequence; no particular feedback is assumed. -/
theorem signed_balance {δ E V : ℝ} {e v : ℕ → ℝ} (hp : P.Plant δ e v)
    (he : HasSum e E) (hv : HasSum v V) :
    (1-P.a)*E + P.s*V = δ * ((P.a*P.b+P.c)/P.s) := by
  have h := (((preceding_hasSum he δ).mul_left P.a).sub (hv.mul_left P.b)).sub
    ((preceding_hasSum hv (P.before δ)).mul_left P.c)
  have hf : (fun n => P.a * prev δ e n - P.b*v n - P.c*prev (P.before δ) v n) = e :=
    funext fun n => (hp n).symm
  change HasSum (fun n => P.a * prev δ e n - P.b*v n - P.c*prev (P.before δ) v n)
      (P.a*(E+δ)-P.b*V-P.c*(V+P.before δ)) at h
  rw [hf] at h
  have heq := he.unique h
  unfold before at heq
  field_simp [ne_of_gt P.s_pos] at heq ⊢
  unfold s at heq ⊢
  linarith

private theorem abs_sum_le {f : ℕ → ℝ} (hf : FiniteArea f) :
    |∑' k, f k| ≤ ∑' k, |f k| := by
  have h : Summable (fun k => ‖f k‖) := by simpa [Real.norm_eq_abs] using hf
  simpa [Real.norm_eq_abs] using norm_tsum_le_tsum_norm h

private theorem sum_exists {f : ℕ → ℝ} (hf : FiniteArea f) : Summable f := by
  apply Summable.of_norm
  simpa [Real.norm_eq_abs] using hf

theorem area_lower_bound {δ h : ℝ} (hh : 0 ≤ h) {e v : ℕ → ℝ}
    (hp : P.Plant δ e v) (he : FiniteArea e) (hv : FiniteArea v) :
    P.barrier h δ ≤ (1-P.a)*area h e + P.s*area h v := by
  have hbal := P.signed_balance hp (sum_exists he).hasSum (sum_exists hv).hasSum
  have hq : 0 ≤ (P.a*P.b+P.c)/P.s :=
    div_nonneg (add_nonneg (mul_nonneg P.ha P.hb.le) P.hc.le) P.s_pos.le
  have hb : |δ| * ((P.a*P.b+P.c)/P.s) ≤
      (1-P.a)*(∑' n, |e n|) + P.s*(∑' n, |v n|) := calc
    _ = |δ * ((P.a*P.b+P.c)/P.s)| := by rw [abs_mul, abs_of_nonneg hq]
    _ = |(1-P.a)*(∑' n, e n) + P.s*(∑' n, v n)| := congrArg abs hbal.symm
    _ ≤ |(1-P.a)*(∑' n, e n)| + |P.s*(∑' n, v n)| := abs_add_le _ _
    _ ≤ _ := by
      rw [abs_mul, abs_mul, abs_of_nonneg (sub_nonneg.mpr P.ha1.le), abs_of_pos P.s_pos]
      exact add_le_add (mul_le_mul_of_nonneg_left (abs_sum_le he) (sub_nonneg.mpr P.ha1.le))
        (mul_le_mul_of_nonneg_left (abs_sum_le hv) P.s_pos.le)
  dsimp [barrier, area]
  linarith only [mul_le_mul_of_nonneg_left hb hh]

/-- The quantitative lower bound (including its square root) for any
evaluation weight, before selecting any one-step tuning parameter. -/
theorem universal_miace_bound {δ h μ : ℝ} (hh : 0 ≤ h) (hμ : 0 < μ)
    {e v : ℕ → ℝ} (hp : P.Plant δ e v) (he : FiniteArea e) (hv : FiniteArea v) :
    P.barrier h δ / Real.sqrt ((1-P.a)^2+P.s^2/μ) ≤ cost h μ e v := by
  let d := 1-P.a
  let A := area h e
  let B := area h v
  let G := d^2+P.s^2/μ
  let J := A^2+μ*B^2
  have hG : 0 < G := add_pos_of_nonneg_of_pos (sq_nonneg d) (div_pos (sq_pos_of_pos P.s_pos) hμ)
  have hJ : 0 ≤ J := add_nonneg (sq_nonneg A) (mul_nonneg hμ.le (sq_nonneg B))
  have hC : 0 ≤ P.barrier h δ := by
    unfold barrier
    exact mul_nonneg (mul_nonneg hh (abs_nonneg _))
      (div_nonneg (add_nonneg (mul_nonneg P.ha P.hb.le) P.hc.le) P.s_pos.le)
  have hlin : P.barrier h δ ≤ d*A+P.s*B := P.area_lower_bound hh hp he hv
  have hcs : μ * (J*G-(d*A+P.s*B)^2) = (P.s*A-μ*d*B)^2 := by
    dsimp only [G,J]
    field_simp [ne_of_gt hμ]
    ring
  have hsq : (d*A+P.s*B)^2 ≤ J*G := by
    apply sub_nonneg.mp
    apply (mul_nonneg_iff_of_pos_left hμ).mp
    rw [hcs]
    exact sq_nonneg _
  change P.barrier h δ / Real.sqrt G ≤ Real.sqrt J
  apply (div_le_iff₀ (Real.sqrt_pos.2 hG)).mpr
  apply (sq_le_sq₀ hC (mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _))).mp
  rw [mul_pow, Real.sq_sqrt hJ, Real.sq_sqrt hG.le]
  exact (sq_le_sq₀ hC (hC.trans hlin)).mpr hlin |>.trans hsq

/-- Divergent absolute-area sequences have infinite cost; this prevents the
default value of a nonsummable real `tsum` from being used as a cost. -/
def extendedCost (h μ : ℝ) (e v : ℕ → ℝ) : WithTop ℝ := by
  classical
  exact if FiniteArea e ∧ FiniteArea v then (cost h μ e v : WithTop ℝ) else ⊤

theorem all_sequences_bound {δ h μ : ℝ} (hh : 0 ≤ h) (hμ : 0 < μ)
    {e v : ℕ → ℝ} (hp : P.Plant δ e v) :
    ((P.barrier h δ / Real.sqrt ((1-P.a)^2+P.s^2/μ) : ℝ) : WithTop ℝ) ≤
      extendedCost h μ e v := by
  classical
  unfold extendedCost
  split_ifs with H
  · exact_mod_cast P.universal_miace_bound hh hμ hp H.1 H.2
  · exact le_top

private theorem geom_abs {p : ℝ} (hp : |p| < 1) (k : ℝ) :
    HasSum (fun n : ℕ => |k*p^n|) (|k|/(1-|p|)) := by
  simpa [abs_mul, abs_pow, div_eq_mul_inv] using
    (hasSum_geometric_of_lt_one (abs_nonneg p) hp).mul_left (|k|)

theorem geometric_areas {δ h : ℝ} (hp : |P.pole| < 1) :
    area h (P.err δ) = h * (|δ| * P.l * P.amp / (1-|P.pole|)) ∧
    area h (P.cmd δ) = h * (|δ| * P.b * P.amp / (1-|P.pole|)) := by
  constructor
  · simpa [area, err, abs_mul, abs_of_pos P.hl, abs_of_pos P.amp_pos] using
      congrArg (fun t : ℝ => h*t) (geom_abs hp (δ*P.l*P.amp)).tsum_eq
  · simpa [area, cmd, abs_mul, abs_of_pos P.hb, abs_of_pos P.amp_pos] using
      congrArg (fun t : ℝ => h*t) (geom_abs hp (δ*P.b*P.amp)).tsum_eq

theorem finite_geometric_areas {δ : ℝ} (hp : |P.pole| < 1) :
    FiniteArea (P.err δ) ∧ FiniteArea (P.cmd δ) :=
  ⟨(geom_abs hp (δ*P.l*P.amp)).summable, (geom_abs hp (δ*P.b*P.amp)).summable⟩

theorem equality_on_monotone_branch {δ h : ℝ} (hp : 0 ≤ P.pole) :
    (1-P.a)*area h (P.err δ) + P.s * area h (P.cmd δ) = P.barrier h δ := by
  have hstable : |P.pole| < 1 := by simpa [abs_of_nonneg hp] using P.pole_lt_one
  obtain ⟨hE,hV⟩ := P.geometric_areas (δ := δ) (h := h) hstable
  rw [hE, hV, abs_of_nonneg hp]
  have hd : P.den - (P.a * P.l - P.b * P.c) ≠ 0 := by
    have hlt := (div_lt_iff₀ P.den_pos).mp P.pole_lt_one
    exact ne_of_gt (by linarith)
  unfold amp barrier pole
  field_simp [ne_of_gt P.s_pos, ne_of_gt P.den_pos, hd]
  unfold s den
  ring

/-- All points attained without a change of sign are Pareto efficient over
arbitrary competitors, with the stage-endpoint convention of the manuscript. -/
theorem monotone_pareto {h δ : ℝ} (hh : 0 ≤ h) (hmono : 0 ≤ P.pole)
    {e v : ℕ → ℝ} (hp : P.Plant δ e v) (he : FiniteArea e) (hv : FiniteArea v)
    (he' : area h e ≤ area h (P.err δ)) (hv' : area h v ≤ area h (P.cmd δ)) :
    area h e = area h (P.err δ) ∧ area h v = area h (P.cmd δ) := by
  have h1 := P.area_lower_bound hh hp he hv
  rw [← P.equality_on_monotone_branch (h := h) (δ := δ) hmono] at h1
  constructor
  · by_contra! hn
    have hstrict := mul_lt_mul_of_pos_left (lt_of_le_of_ne he' hn) (sub_pos.mpr P.ha1)
    linarith [mul_le_mul_of_nonneg_left hv' P.s_pos.le]
  · by_contra! hn
    have hstrict := mul_lt_mul_of_pos_left (lt_of_le_of_ne hv' hn) P.s_pos
    linarith [mul_le_mul_of_nonneg_left he' (sub_nonneg.mpr P.ha1.le)]

/-- Supporting-hyperplane sufficiency for weighted Euclidean projection. -/
theorem supporting_minimum {x y A B d s μ : ℝ} (hs : 0 < s) (hμ : 0 ≤ μ)
    (hy : 0 ≤ y) (hbalance : d*x+s*y ≤ d*A+s*B) (hratio : s*x=μ*d*y) :
    x^2+μ*y^2 ≤ A^2+μ*B^2 := by
  have ht : s*(x*(A-x)+μ*y*(B-y)) = μ*y*((d*A+s*B)-(d*x+s*y)) := by
    linear_combination (A-x)*hratio
  have hr := mul_nonneg (mul_nonneg hμ hy) (sub_nonneg.mpr hbalance)
  have hx : 0 ≤ x*(A-x)+μ*y*(B-y) := by
    apply (mul_nonneg_iff_of_pos_left hs).mp
    linarith
  nlinarith [sq_nonneg (A-x), mul_nonneg hμ (sq_nonneg (B-y))]

/-- Quantification is over every finite-area control sequence satisfying the plant law. -/
theorem global_optimal {δ h μ : ℝ} (hh : 0 ≤ h) (hμ : 0 < μ)
    (htune : P.l = P.b*μ*(1-P.a)/P.s) (hmono : P.b*P.c ≤ P.a*P.l)
    {e v : ℕ → ℝ} (hp : P.Plant δ e v) (he : FiniteArea e) (hv : FiniteArea v) :
    cost h μ (P.err δ) (P.cmd δ) ≤ cost h μ e v := by
  have hpol := P.pole_nonneg_iff.mpr hmono
  have hstable : |P.pole| < 1 := by simpa [abs_of_nonneg hpol] using P.pole_lt_one
  obtain ⟨hE,hV⟩ := P.geometric_areas (δ := δ) (h := h) hstable
  have hr : P.s*area h (P.err δ) = μ*(1-P.a)*area h (P.cmd δ) := by
    rw [hE,hV]
    have ht := (eq_div_iff (ne_of_gt P.s_pos)).mp htune
    linear_combination (h * |δ| * P.amp / (1-|P.pole|)) * ht
  have hB : 0 ≤ area h (P.cmd δ) := mul_nonneg hh (tsum_nonneg fun _ => abs_nonneg _)
  apply Real.sqrt_le_sqrt
  apply supporting_minimum P.s_pos hμ.le hB _ hr
  rw [P.equality_on_monotone_branch hpol]
  exact P.area_lower_bound hh hp he hv

/-- End-to-end statement for the trajectory generated by the recursive
one-step controller, in lieu of its geometric closed form. -/
theorem trajectory_global_optimal {δ h μ : ℝ} (hh : 0 ≤ h) (hμ : 0 < μ)
    (htune : P.l = P.b*μ*(1-P.a)/P.s) (hmono : P.b*P.c ≤ P.a*P.l)
    {e v : ℕ → ℝ} (hp : P.Plant δ e v) (he : FiniteArea e) (hv : FiniteArea v) :
    cost h μ (fun k => (P.trajectory δ k).1) (fun k => (P.trajectory δ k).2) ≤
      cost h μ e v := by
  simpa only [trajectory_eq] using P.global_optimal hh hμ htune hmono hp he hv

theorem all_sequences_optimal {δ h μ : ℝ} (hh : 0 ≤ h) (hμ : 0 < μ)
    (htune : P.l = P.b*μ*(1-P.a)/P.s) (hmono : P.b*P.c ≤ P.a*P.l)
    {e v : ℕ → ℝ} (hp : P.Plant δ e v) :
    extendedCost h μ (P.err δ) (P.cmd δ) ≤ extendedCost h μ e v := by
  classical
  have hpol := P.pole_nonneg_iff.mpr hmono
  have hstable : |P.pole| < 1 := by simpa [abs_of_nonneg hpol] using P.pole_lt_one
  have hfin := P.finite_geometric_areas (δ := δ) hstable
  simp only [extendedCost, if_pos hfin]
  split_ifs with H
  · exact_mod_cast P.global_optimal hh hμ htune hmono hp H.1 H.2
  · exact le_top

/-- Exact squared value for the minimizer. This equality and `global_optimal`
express the lower bound with no division by a possibly vanishing area. -/
theorem attained_bound {δ h μ : ℝ} (hμ : 0 < μ)
    (htune : P.l = P.b*μ*(1-P.a)/P.s) (hmono : P.b*P.c ≤ P.a*P.l) :
    ((area h (P.err δ))^2+μ*(area h (P.cmd δ))^2) *
        ((1-P.a)^2+P.s^2/μ) = (P.barrier h δ)^2 := by
  have hpol := P.pole_nonneg_iff.mpr hmono
  have hstable : |P.pole| < 1 := by simpa [abs_of_nonneg hpol] using P.pole_lt_one
  obtain ⟨hE,hV⟩ := P.geometric_areas (δ := δ) (h := h) hstable
  have hr : P.s*area h (P.err δ) = μ*(1-P.a)*area h (P.cmd δ) := by
    rw [hE,hV]
    have ht := (eq_div_iff (ne_of_gt P.s_pos)).mp htune
    linear_combination (h * |δ| * P.amp / (1-|P.pole|)) * ht
  rw [← P.equality_on_monotone_branch (δ := δ) (h := h) hpol]
  field_simp [ne_of_gt hμ]
  linear_combination (P.s*area h (P.err δ) - μ*(1-P.a)*area h (P.cmd δ))*hr

theorem attained_miace {δ h μ : ℝ} (hh : 0 ≤ h) (hμ : 0 < μ)
    (htune : P.l = P.b*μ*(1-P.a)/P.s) (hmono : P.b*P.c ≤ P.a*P.l) :
    cost h μ (P.err δ) (P.cmd δ) =
      P.barrier h δ / Real.sqrt ((1-P.a)^2+P.s^2/μ) := by
  let G := (1-P.a)^2+P.s^2/μ
  have hG : 0 < G := add_pos_of_nonneg_of_pos (sq_nonneg _) (div_pos (sq_pos_of_pos P.s_pos) hμ)
  have hC : 0 ≤ P.barrier h δ := by
    unfold barrier
    exact mul_nonneg (mul_nonneg hh (abs_nonneg _))
      (div_nonneg (add_nonneg (mul_nonneg P.ha P.hb.le) P.hc.le) P.s_pos.le)
  let J := (area h (P.err δ))^2+μ*(area h (P.cmd δ))^2
  have hJ : 0 ≤ J := add_nonneg (sq_nonneg _) (mul_nonneg hμ.le (sq_nonneg _))
  have hsq : J*G = (P.barrier h δ)^2 := P.attained_bound hμ htune hmono
  change Real.sqrt J = P.barrier h δ / Real.sqrt G
  apply (eq_div_iff (ne_of_gt (Real.sqrt_pos.2 hG))).mpr
  have hn := mul_nonneg (Real.sqrt_nonneg J) (Real.sqrt_nonneg G)
  have hs : (Real.sqrt J * Real.sqrt G)^2 = (P.barrier h δ)^2 := by
    rw [mul_pow,Real.sq_sqrt hJ,Real.sq_sqrt hG.le]
    exact hsq
  exact le_antisymm ((sq_le_sq₀ hn hC).mp hs.le) ((sq_le_sq₀ hC hn).mp hs.ge)

def exampleModel : Model :=
  ⟨1/2, 1, 1/2, 1, by norm_num, by norm_num, by norm_num, by norm_num, by norm_num⟩

theorem example_areas :
    area 1 (exampleModel.err 1) = 1/3 ∧ area 1 (exampleModel.cmd 1) = 1/3 := by
  have hh : |exampleModel.pole| < 1 := by norm_num [pole, den, exampleModel]
  obtain ⟨ha,hb⟩ := exampleModel.geometric_areas (δ := 1) (h := 1) hh
  rw [ha,hb]
  norm_num [pole, den, amp, s, exampleModel]

theorem example_minimum {e v : ℕ → ℝ} (hp : exampleModel.Plant 1 e v)
    (he : FiniteArea e) (hv : FiniteArea v) : 2/3 ≤ cost 1 3 e v := by
  have H := exampleModel.global_optimal (δ := 1) (h := 1) (μ := 3)
    (by norm_num) (by norm_num) (by norm_num [s, exampleModel])
    (by norm_num [exampleModel]) hp he hv
  have h : cost 1 3 (exampleModel.err 1) (exampleModel.cmd 1) = 2/3 := by
    rw [cost, example_areas.1, example_areas.2]
    norm_num
  simpa only [h] using H

end Model
end MPCPID.Optimal
