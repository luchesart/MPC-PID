import MPCPID.PhysicalSchedule
import Mathlib.Algebra.MvPolynomial.Rename

/-! An exact real-algebraic gain reserve for a physical, periodically updated
PID. The same physical gains must match the target at nominal gain and
stabilize every fixed loop multiplier in the prescribed closed interval. -/
namespace MPCPID.GainReserve
open PhysicalLift PhysicalSchedule ScheduleCertificate
noncomputable section

/-- A fixed real gain multiplies the commanded input at the plant port. The
controller still has access to its own command, and its internal updates do
not change. -/
def scaleInput {R : Type*} [Mul R] {n : ℕ} (p : Plant R n) (r : R) : Plant R n :=
  {p with B := fun i j => r * p.B i j}

theorem scale_one {n : ℕ} (p : Plant ℝ n) : scaleInput p 1 = p := by
  cases p
  simp [scaleInput]

abbrev P19 := ScheduleCertificate.Poly 19

def jointPoint (x : Fin 18 → ℝ) (r : ℝ) : Fin 19 → ℝ := Fin.lastCases r x

def embedGain : P18 →+* P19 :=
  (MvPolynomial.rename (R := ℝ) (Fin.castSucc : Fin 18 → Fin 19)).toRingHom

theorem eval_embed (x : Fin 18 → ℝ) (r : ℝ) (v : P18) :
    MvPolynomial.eval (jointPoint x r) (embedGain v) = MvPolynomial.eval x v := by
  change MvPolynomial.eval _ (MvPolynomial.rename Fin.castSucc v) = _
  rw [MvPolynomial.eval_rename]
  have res : jointPoint x r ∘ Fin.castSucc = x := by
    funext i
    simp [Function.comp_apply,jointPoint]
  rw [res]

/-- The last indeterminate is the loop multiplier. -/
def reservePolys {L n : ℕ} (P : Plant ℝ n) (h : ℝ) (s : Clocks L) :=
  let polyPlant := P.map (MvPolynomial.C : ℝ →+* P19)
  (physicalFrame (scaleInput polyPlant (MvPolynomial.X (Fin.last 18)))
    (GainGraph.Coeff.map embedGain (GainGraph.symbolic (s.TI h) (s.TD h))) s.flags L).A

theorem eval_joint_plant {n : ℕ} (P : Plant ℝ n) (x : Fin 18 → ℝ) (r : ℝ) :
    (scaleInput (P.map (MvPolynomial.C : ℝ →+* P19)) (MvPolynomial.X (Fin.last 18))).map
      (MvPolynomial.eval (jointPoint x r)) = scaleInput P r := by
  cases P with
  | mk A B C =>
    have const {k l : ℕ} (U : PhysicalLift.M ℝ k l) :
        (U.map (MvPolynomial.C : ℝ →+* P19)).map (MvPolynomial.eval (jointPoint x r)) = U := by
      ext i j
      simp [Matrix.map_apply]
    simp only [Plant.map,scaleInput,const,Plant.mk.injEq,true_and,and_true]
    ext i j
    change MvPolynomial.eval (jointPoint x r)
      (MvPolynomial.X (Fin.last 18) * MvPolynomial.C (B i j)) = r * B i j
    rw [map_mul,MvPolynomial.eval_X,MvPolynomial.eval_C]
    rw [jointPoint,Fin.lastCases_last]

theorem eval_joint_coeff (g : GainGraph.Coeff P18) (x : Fin 18 → ℝ) (r : ℝ) :
    GainGraph.Coeff.map (MvPolynomial.eval (jointPoint x r)) (GainGraph.Coeff.map embedGain g)
      = GainGraph.Coeff.map (MvPolynomial.eval x) g := by
  ext <;> simp [GainGraph.Coeff.map,eval_embed]

theorem eval_reserve {L n : ℕ} (P : Plant ℝ n) (h : ℝ) (s : Clocks L)
    (x : Fin 18 → ℝ) (r : ℝ) :
    (reservePolys P h s).map (MvPolynomial.eval (jointPoint x r)) =
      (physicalFrame (scaleInput P r)
        (GainGraph.Coeff.map (MvPolynomial.eval x) (GainGraph.symbolic (s.TI h) (s.TD h)))
        s.flags L).A := by
  unfold reservePolys
  change ((physicalFrame _ _ _ _).map (MvPolynomial.eval (jointPoint x r))).A = _
  simp only [map_physicalFrame,eval_joint_plant,eval_joint_coeff]

/-- Finite real coefficient comparisons and strict inequalities for one
evaluated gain. The factorization witnesses may vary with r. -/
def DiskWitness {a : ℕ} (Φ : ScheduleCertificate.M P19 a a) (x : Fin 18 → ℝ) (r : ℝ) : Prop :=
  ∃ u : Fin a × Bool → ℝ,
    (∀ j ≤ a, MvPolynomial.eval (jointPoint x r) (Φ.charpoly.coeff j) =
      MvPolynomial.eval u (Periodic.realImag ((Periodic.rootPolynomial a).coeff j)).1 ∧
      0 = MvPolynomial.eval u (Periodic.realImag ((Periodic.rootPolynomial a).coeff j)).2) ∧
    ∀ i, (u (i,false))^2 + (u (i,true))^2 < 1

theorem disk_witness_iff {a : ℕ} (Φ : ScheduleCertificate.M P19 a a)
    (x : Fin 18 → ℝ) (r : ℝ) :
    Stable (Φ.map (MvPolynomial.eval (jointPoint x r))) ↔ DiskWitness Φ x r := by
  have H := (Periodic.polynomialSchur (jointPoint x r) Φ).trans
    (Periodic.realRootWitness (fun j => MvPolynomial.eval (jointPoint x r) (Φ.charpoly.coeff j)))
  simpa only [Stable,DiskWitness,Matrix.map_map,RingHom.comp_apply] using H

/-- Feasibility of this very physical parameter vector, including both
discretization weights. -/
def PhysicalAt {L n t : ℕ} (P : Plant ℝ n) (h reserve : ℝ) (s : Clocks L)
    (T : System ℝ t L (L*2)) (p : GainGraph.Physical) : Prop :=
  GainGraph.Admissible p ∧
    let g := GainGraph.rational (s.TI h) (s.TD h) p
    MatchSys (physicalFrame P g s.flags L) T ∧
      ∀ r ∈ Set.Icc 1 reserve, Stable (physicalFrame (scaleInput P r) g s.flags L).A

def PhysicalFeasible {L n t : ℕ} (P : Plant ℝ n) (h reserve : ℝ) (s : Clocks L)
    (T : System ℝ t L (L*2)) : Prop :=
  ∃ p, PhysicalAt P h reserve s T p

def PolynomialFeasible {L n t : ℕ} (P : Plant ℝ n) (h reserve : ℝ) (s : Clocks L)
    (T : System ℝ t L (L*2)) : Prop :=
  ∃ x : Fin 18 → ℝ, (∀ j, MvPolynomial.eval x (GainGraph.eqs (s.TD h) j) = 0) ∧
    (∀ j, 0 < MvPolynomial.eval x (GainGraph.pos j)) ∧
    Certificate x (closedPolys P h s) T (closedPolys P h s).A ∧
    ∀ r ∈ Set.Icc 1 reserve, DiskWitness (reservePolys P h s) x r

/-- End-to-end reduction with joint polynomials in the 18 gain coordinates
and the independent loop multiplier. It includes both endpoints and tests
the whole line segment, including the possibility of an interior instability. -/
theorem reserve_feasibility {L n t : ℕ} (P : Plant ℝ n) {h reserve : ℝ}
    (hh : 0 < h) (hr : 1 ≤ reserve) (s : Clocks L) (T : System ℝ t L (L*2)) :
    PhysicalFeasible P h reserve s T ↔ PolynomialFeasible P h reserve s T := by
  unfold PhysicalFeasible PhysicalAt PolynomialFeasible
  have hTD : 0 ≤ s.TD h := mul_nonneg (Nat.cast_nonneg _) hh.le
  apply (GainGraph.gain_feasibility (s.TI h) (s.TD h) hTD (fun g =>
    MatchSys (physicalFrame P g s.flags L) T ∧
      ∀ r ∈ Set.Icc 1 reserve, Stable (physicalFrame (scaleInput P r) g s.flags L).A)).trans
  apply exists_congr
  intro x
  apply and_congr_right
  intro _
  apply and_congr_right
  intro _
  let g := GainGraph.Coeff.map (MvPolynomial.eval x) (GainGraph.symbolic (s.TI h) (s.TD h))
  have Hnom := certify_evaluated_system x (closedPolys P h s) T (closedPolys P h s).A
  have Hframe := eval_closedPolys P h s x
  have Ha := congrArg System.A Hframe
  change (closedPolys P h s).A.map (MvPolynomial.eval x) = _ at Ha
  rw [Hframe,Ha] at Hnom
  have Hd (r : ℝ) : Stable (physicalFrame (scaleInput P r) g s.flags L).A ↔
      DiskWitness (reservePolys P h s) x r := by
    rw [← eval_reserve P h s x r]
    exact disk_witness_iff _ _ _
  constructor
  · rintro ⟨hm,hs⟩
    have hsone := hs 1 ⟨le_rfl,hr⟩
    rw [scale_one] at hsone
    exact ⟨Hnom.mp ⟨hm,hsone⟩,fun r hr' => (Hd r).mp (hs r hr')⟩
  · rintro ⟨hn,hs⟩
    exact ⟨(Hnom.mpr hn).1,fun r hr' => (Hd r).mpr (hs r hr')⟩

end
end MPCPID.GainReserve
