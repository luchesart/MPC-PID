import MPCPID.NominalColumns
import MPCPID.OperatorPhase

/-! Connect the impulse columns to an actual phase-shifted plant and PID run. -/
namespace MPCPID.NominalExecution
open PhysicalSchedule PhysicalLift GainGraph NominalColumns OperatorPhase
noncomputable section

private def pack (p i d : State) : V 5 := ![p.1,i.1,d.1,i.2,d.2]

private theorem pack_tick (g : Coeff ℝ) (f : Flags) (Y : ℕ → ℝ) (k : ℕ)
    (p i d : State) :
    tick g f ![pulse k,Y k] (pack p i d) =
      pack (if f.p then pStep g Y k p else p)
           (if f.i then iStep g Y k i else i)
           (if f.d then dStep g Y k d else d) := by
  cases f with
  | mk fp fi fd =>
    cases fp <;> cases fi <;> cases fd <;> funext j <;> fin_cases j <;>
      simp [tick,Periodic.drivenBranches,bit,pack,pStep,iStep,dStep,add_assoc]

theorem operator_run {L : ℕ} (s : Clocks L) (g : Coeff ℝ) (Y : ℕ → ℝ)
    (start k : ℕ) :
    run g (fun j => s.flags (start+j)) (fun j => ![pulse j,Y j]) 0 k =
      pack (state (pStep g Y) (drive s.mP s.φP start) k)
        (state (iStep g Y) (drive s.mI s.φI start) k)
        (state (dStep g Y) (drive s.mD s.φD start) k) := by
  induction k with
  | zero =>
    funext i
    fin_cases i <;> rfl
  | succ k ih => rw [run,ih,pack_tick]; rfl

def measure {n : ℕ} (P : Plant ℝ n) (x : V n) : ℝ := (P.C.mulVec x) 0

/-- Start the actual nominal closed loop at zero plant and controller states.
The phase is free, and the external reference is a single impulse at the start. -/
def closedRun {L n : ℕ} (s : Clocks L) (P : Plant ℝ n) (g : Coeff ℝ) (start : ℕ) :
    ℕ → V n × V 5
  | 0 => 0
  | k+1 =>
    let old := closedRun s P g start k
    let zj := tick g (s.flags (start+k)) ![pulse k,measure P old.1] old.2
    (P.A.mulVec old.1 + command zj • (fun i => P.B i 0),zj)

/-- The target output and command are reproduced at every phase by the physical
nominal plant/PID. No matching or equality of independent sensor inputs is needed. -/
def MatchesImpulse {L n : ℕ} (s : Clocks L) (P : Plant ℝ n) (g : Coeff ℝ)
    (Y U : ℕ → ℝ) : Prop :=
  ∀ start k,
    measure P (closedRun s P g start k).1 = Y k ∧
    command (closedRun s P g start (k+1)).2 = U k

theorem actual_impulses {L n : ℕ} (s : Clocks L) (P : Plant ℝ n) (g : Coeff ℝ)
    {Y U : ℕ → ℝ} (hm : MatchesImpulse s P g Y U) (start k : ℕ) :
    output s g Y start (k+1) = U k := by
  have loop (j : ℕ) :
      (closedRun s P g start j).2 =
        run g (fun i => s.flags (start+i)) (fun i => ![pulse i,Y i]) 0 j := by
    induction j with
    | zero => rfl
    | succ j ih =>
      change tick g _ ![pulse j,measure P (closedRun s P g start j).1]
          (closedRun s P g start j).2 = _
      rw [(hm start j).1,ih]
      rfl
  have phys := (hm start k).2
  rw [loop,operator_run] at phys
  exact phys

end
end MPCPID.NominalExecution
