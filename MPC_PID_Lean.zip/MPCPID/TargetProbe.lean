import MPCPID.NominalProbe
import MPCPID.Predictive

/-! The finite nominal experiment is an exact trajectory of the original
one-step MIACE law at every time, for a reference applied after synchronized rest. -/
namespace MPCPID.TargetProbe
open NominalProbe Predictive
noncomputable section

def prev (x : ℕ → ℝ) : ℕ → ℝ
  | 0 => 0
  | k+1 => x k

theorem parameters {a b c l : ℝ} (ha : 0 ≤ a) (ha1 : a < 1)
    (hb : 0 < b) (hc : 0 < c) (hl : max 0 (c^2-b^2) < l) :
    let e := eta a b c l
    let p := pole a b c l
    0 < e ∧ 0 < e*c ∧ e*c < 1 ∧ p+e*b+e*c=1 ∧
    p+fy a b l*b-memoryGain b c l=a ∧ fy a b l*c+a*memoryGain b c l=0 := by
  dsimp only
  have H := realization_hypotheses a b c l ha1 hb hc hl
  have lpos := (le_max_left _ _).trans_lt hl
  have den := add_pos_of_nonneg_of_pos (sq_nonneg b) lpos
  have S := add_pos hb hc
  have e_le : eta a b c l ≤ zeta b c l := by
    have z : zeta b c l = (b+l/(b+c))/(b^2+l) := by
      unfold zeta
      field_simp [den.ne',S.ne',mul_ne_zero den.ne' S.ne']; ring_nf; simp
    rw [eta,z,div_le_div_iff_of_pos_right den]
    apply add_le_add_left
    apply (div_le_div_iff_of_pos_right S).2
    nlinarith only [mul_nonneg lpos.le ha]
  refine ⟨H.1,mul_pos H.1 hc,(mul_le_mul_of_nonneg_right e_le hc.le).trans_lt H.2.2,?_,?_,?_⟩
  · unfold pole eta
    field_simp [den.ne',S.ne']; ring
  · unfold pole fy memoryGain
    field_simp [den.ne']; ring
  · unfold fy memoryGain
    ring

theorem sample_equations (a b c η f t p : ℝ)
    (hp : p+f*b-t=a) (ht : f*c+a*t=0) (k : ℕ) :
    let r := refProbe p
    let y := outProbe (η*b) (η*c)
    let u := cmdProbe η a
    y 0=0 ∧ y (k+1)=a*y k+b*u k+c*prev u k ∧ u k=η*r k-f*y k+t*prev u k := by
  dsimp only
  rcases k with _|k
  · simp [outProbe,cmdProbe,refProbe,pulse,prev]; ring
  rcases k with _|k
  · simp [outProbe,cmdProbe,refProbe,pulse,prev]
    constructor
    · ring
    · linear_combination η*hp
  rcases k with _|k
  · simp [outProbe,cmdProbe,refProbe,pulse,prev]
    constructor
    · ring
    · linear_combination η*ht
  simp [outProbe,cmdProbe,refProbe,pulse,prev]

def traj (a b c η f t : ℝ) (r : ℕ → ℝ) : ℕ → ℝ × ℝ
  | 0 => 0
  | k+1 =>
    let z := traj a b c η f t r k
    let u := η*r k - f*z.1 + t*z.2
    (a*z.1+b*u+c*z.2,u)

/-- Target state contains the current output and preceding actual input. -/
theorem probe_trajectory (a b c η f t p : ℝ) (hp : p+f*b-t=a)
    (ht : f*c+a*t=0) (k : ℕ) :
    traj a b c η f t (refProbe p) k =
      (outProbe (η*b) (η*c) k,prev (cmdProbe η a) k) := by
  induction k with
  | zero => simp [traj,outProbe,pulse,prev]
  | succ k ih =>
    have H := sample_equations a b c η f t p hp ht k
    dsimp only at H
    rw [traj,ih]
    simp only
    rw [← H.2.2, ← H.2.1]
    rfl

/-- Run the actual PID on any reference and nominal measurement, using only
the branch equations specified by its clocks. -/
def stores (P I D : ℕ → Prop) (K i0 i1 α β b c : ℝ)
    (r y : ℕ → ℝ) (s : ℕ) : ℕ → Periodic.Memory
  | 0 => Periodic.rest
  | k+1 => advance (P (s+k)) (I (s+k)) (D (s+k)) K i0 i1 α β
      (b*r k-y k) (r k-y k) (c*r k-y k) (stores P I D K i0 i1 α β b c r y s k)

/-- Nominal equality is tested on the measurements of the fixed strictly
proper target loop, at every reference and phase starting at rest. Causality
then reproduces both the actual command and the same plant trajectory. -/
def NominalMatch (P I D : ℕ → Prop) (K i0 i1 α β b c a b₀ b₁ η f t : ℝ) : Prop :=
  ∀ (r : ℕ → ℝ) s k, let z := traj a b₀ b₁ η f t r
    let x := stores P I D K i0 i1 α β b c r (fun j => (z j).1) s (k+1)
    x.p+x.i+x.d=(z (k+1)).2

theorem match_probe (P I D : ℕ → Prop) (K i0 i1 α β b c a b₀ b₁ η f t p : ℝ)
    (hp : p+f*b₀-t=a) (ht : f*b₁+a*t=0)
    (hm : NominalMatch P I D K i0 i1 α β b c a b₀ b₁ η f t) :
    Matches P I D K i0 i1 α β b c p (η*b₀) (η*b₁) η a := by
  intro s k
  have eq := hm (refProbe p) s k
  simp only [probe_trajectory a b₀ b₁ η f t p hp ht,prev] at eq
  have reg (n : ℕ) :
      stores P I D K i0 i1 α β b c (refProbe p) (outProbe (η*b₀) (η*b₁)) s n =
      regs P I D K i0 i1 α β b c p (η*b₀) (η*b₁) s n := by
    induction n with
    | zero => rfl
    | succ n ih => rw [stores,regs,ih]
  simpa only [reg] using eq

end
end MPCPID.TargetProbe
